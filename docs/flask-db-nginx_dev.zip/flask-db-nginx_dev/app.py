# app.py
import os
import re
import json
import datetime
import logging
from flask import Flask, jsonify, request, send_file, send_from_directory, render_template
import psycopg2
from psycopg2.extras import RealDictCursor
from config import Config

app = Flask(__name__,
    static_folder='public',
    static_url_path=''
)
app.config.from_object(Config)
DIR_KEYS = ['REPORTS_DIR', 'COGS_DIR', 'TILES_DIR', 'BASEMAPS_DIR']

# Iterate over the keys and create each directory
for key in DIR_KEYS:
    path = app.config.get(key)
    if path:  # Ensure the path exists before trying to create it
        os.makedirs(path, exist_ok=True)
        
def get_db():
    return psycopg2.connect(
        dsn=app.config['DB_URL'],
        cursor_factory=RealDictCursor
    )

# ==================== HIERARCHICAL DROPDOWN ENDPOINTS ====================
@app.route('/api/countries')
def get_countries():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT country_name 
                    FROM comprehensive_query 
                    WHERE country_name IS NOT NULL 
                    ORDER BY country_name
                """)
                countries = [row['country_name'] for row in cur.fetchall()]
                if not countries:
                    cur.execute("""
                        SELECT DISTINCT country_name 
                        FROM target 
                        WHERE country_name IS NOT NULL 
                        ORDER BY country_name
                    """)
                    countries = [row['country_name'] for row in cur.fetchall()]
        return jsonify(countries)
    except Exception as e:
        app.logger.error(f"Countries query failed: {e}")
        return jsonify([])

@app.route('/api/target-types/<country>')
def get_target_types(country):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.target_name 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name IS NOT NULL 
                    ORDER BY sq.target_name
                """, (country,))
                target_names = [row['target_name'] for row in cur.fetchall()]
        return jsonify(target_names)
    except Exception as e:
        app.logger.error(f"Target names query failed for {country}: {e}")
        return jsonify([])

@app.route('/api/image-ids/<country>/<target_name>')
def get_image_ids(country, target_name):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.image_id 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name = %s 
                    AND sq.image_id IS NOT NULL 
                    ORDER BY sq.image_id
                """, (country, target_name))
                image_ids = [row['image_id'] for row in cur.fetchall()]
        return jsonify(image_ids)
    except Exception as e:
        app.logger.error(f"Image IDs query failed for {country}/{target_name}: {e}")
        return jsonify([])

# ==================== UNIFIED DATA ENDPOINT ====================
@app.route('/api/unified-data/<image_id>')
def get_unified_data(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400

    target_names = request.args.getlist('target_name')
    target_classes = request.args.getlist('target_class')
    min_score = request.args.get('min_score', 0.0, type=float)
    max_score = request.args.get('max_score', 1.0, type=float)

    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # VECTOR DATA — join ONLY with `target` on `target_name`
                vector_query = """
                    SELECT 
                        sq.target_name,
                        sq.country_name,
                        sq.image_id, 
                        sq.image_date,
                        sq.target_class,
                        sq.score,
                        sq.st_x as centroid_lon,
                        sq.st_y as centroid_lat,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.image_id = %s
                """
                vector_params = [image_id]
                vector_conditions = []
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    vector_conditions.append(f"sq.target_name IN ({placeholders})")
                    vector_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    vector_conditions.append(f"sq.target_class IN ({placeholders})")
                    vector_params.extend(target_classes)
                if min_score > 0:
                    vector_conditions.append("sq.score >= %s")
                    vector_params.append(min_score)
                if max_score < 1.0:
                    vector_conditions.append("sq.score <= %s")
                    vector_params.append(max_score)
                if vector_conditions:
                    vector_query += " AND " + " AND ".join(vector_conditions)

                cur.execute(vector_query, vector_params)
                vector_rows = cur.fetchall()

                vector_features = []
                for row in vector_rows:
                    geometry_data = {
                        "type": "Polygon",
                        "coordinates": [[
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001]
                        ]]
                    }
                    vector_features.append({
                        "type": "Feature",
                        "geometry": geometry_data,
                        "properties": {
                            "id": f"{row['image_id']}_{row['target_class']}",
                            "target_class": row["target_class"],
                            "target_name": row["target_name"],
                            "target_type": row["target_type"],
                            "country_name": row["country_name"],
                            "score": float(row["score"]) if row["score"] is not None else None,
                            "centroid": [float(row["centroid_lon"]), float(row["centroid_lat"])]
                        }
                    })

                # CHART DATA — join ONLY with `target` on `target_name`
                chart_query = """
                    SELECT 
                        cq.target_name,
                        cq.target_class, 
                        cq.total_count,
                        cq.score as avg_score,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM comprehensive_query cq
                    LEFT JOIN target t ON cq.target_name = t.target_name
                    WHERE cq.image_id = %s
                """
                chart_params = [image_id]
                chart_conditions = []
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    chart_conditions.append(f"cq.target_name IN ({placeholders})")
                    chart_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    chart_conditions.append(f"cq.target_class IN ({placeholders})")
                    chart_params.extend(target_classes)
                if min_score > 0:
                    chart_conditions.append("cq.score >= %s")
                    chart_params.append(min_score)
                if max_score < 1.0:
                    chart_conditions.append("cq.score <= %s")
                    chart_params.append(max_score)
                if chart_conditions:
                    chart_query += " AND " + " AND ".join(chart_conditions)
                chart_query += " ORDER BY cq.total_count DESC"

                cur.execute(chart_query, chart_params)
                chart_rows = cur.fetchall()
                chart_data = [
                    {
                        'target_name': row['target_name'],
                        'target_class': row['target_class'],
                        'target_type': row['target_type'],
                        'total_count': row['total_count'],
                        'avg_score': float(row['avg_score']) if row['avg_score'] is not None else 0.0
                    }
                    for row in chart_rows
                ]

        return jsonify({
            "vector_data": {
                "type": "FeatureCollection", 
                "features": vector_features
            },
            "chart_data": chart_data
        })
    except Exception as e:
        app.logger.error(f"Unified data query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to retrieve unified data"}), 500

# ==================== FILTER OPTIONS ====================
@app.route('/api/filter-options/<image_id>')
def get_filter_options(image_id):
    country = request.args.get('country')
    target_name = request.args.get('target_name')
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_name
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                names_result = cur.fetchall()
                target_names = [row['target_name'] for row in names_result if row['target_name']]

                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                classes = [row['target_class'] for row in cur.fetchall()]

                if country and target_name:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                score_result = cur.fetchone()

        return jsonify({
            'target_names': target_names or [],
            'target_classes': classes or [],
            'score_range': {
                'min': float(score_result['min_score']) if score_result and score_result['min_score'] is not None else 0.0,
                'max': float(score_result['max_score']) if score_result and score_result['max_score'] is not None else 1.0
            }
        })
    except Exception as e:
        app.logger.error(f"Filter options query failed for {image_id}: {e}")
        return jsonify({
            'target_names': [],
            'target_classes': [],
            'score_range': {'min': 0.0, 'max': 1.0}
        })

# ==================== HISTORICAL DEPLOYMENT ENDPOINTS ====================
@app.route('/api/target-classes')
def get_target_classes():
    """Get distinct target classes available in the database"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT target_class 
                    FROM sql_scat_query2 
                    WHERE target_class IS NOT NULL 
                    ORDER BY target_class
                """)
                target_classes = [row['target_class'] for row in cur.fetchall()]
        return jsonify(target_classes)
    except Exception as e:
        app.logger.error(f"Target classes query failed: {e}")
        return jsonify([])

@app.route('/api/image-dates/<target_class>')
def get_image_dates(target_class):
    """Get distinct image dates for a specific target class"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT image_date::text
                    FROM sql_scat_query2 
                    WHERE target_class = %s 
                    AND image_date IS NOT NULL 
                    ORDER BY image_date DESC
                """, (target_class,))
                image_dates = [row['image_date'] for row in cur.fetchall()]
        return jsonify(image_dates)
    except Exception as e:
        app.logger.error(f"Image dates query failed for {target_class}: {e}")
        return jsonify([])
    
# ==================== HISTORICAL DEPLOYMENT ENDPOINTS ====================
@app.route('/api/historical-countries')
def get_historical_countries():
    """Get distinct countries for historical analysis"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT country_name 
                    FROM comprehensive_query 
                    WHERE country_name IS NOT NULL 
                    ORDER BY country_name
                """)
                countries = [row['country_name'] for row in cur.fetchall()]
        return jsonify(countries)
    except Exception as e:
        app.logger.error(f"Historical countries query failed: {e}")
        return jsonify([])

@app.route('/api/historical-targets/<country>')
def get_historical_targets(country):
    """Get distinct target names for a country"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT target_name 
                    FROM comprehensive_query 
                    WHERE country_name = %s 
                    AND target_name IS NOT NULL 
                    ORDER BY target_name
                """, (country,))
                targets = [row['target_name'] for row in cur.fetchall()]
        return jsonify(targets)
    except Exception as e:
        app.logger.error(f"Historical targets query failed for {country}: {e}")
        return jsonify([])

# ==================== HISTORICAL TIMELINE - PROPER comprehensive_query USAGE ====================
@app.route('/api/historical-timeline')
def get_historical_timeline():
    country = request.args.get('country')
    target_name = request.args.get('target_name')
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    
    if not country or not target_name:
        return jsonify({"error": "Country and target name are required"}), 400
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Use comprehensive_query as specified - it already has aggregated counts
                query = """
                    SELECT 
                        target_name,
                        image_date,
                        target_class,
                        total_count
                    FROM comprehensive_query
                    WHERE country_name = %s
                    AND target_name = %s
                """
                params = [country, target_name]
                
                # Add date filter if provided
                if from_date and to_date:
                    query += " AND image_date >= %s AND image_date <= %s"
                    params.extend([from_date, to_date])
                
                query += " ORDER BY image_date, target_class"
                
                cur.execute(query, params)
                rows = cur.fetchall()
                
                # Format data exactly as frontend expects
                timeline_data = {}
                for row in rows:
                    key = f"{row['target_name']}_{row['target_class']}"
                    if key not in timeline_data:
                        timeline_data[key] = {
                            'target_name': row['target_name'],
                            'target_class': row['target_class'], 
                            'data_points': []
                        }
                    timeline_data[key]['data_points'].append({
                        'date': row['image_date'].isoformat() if row['image_date'] else None,
                        'count': row['total_count']
                    })
                
                return jsonify(list(timeline_data.values()))
                
    except Exception as e:
        app.logger.error(f"Historical timeline query failed: {e}")
        return jsonify({"error": "Failed to retrieve historical data"}), 500
            

# ==================== EXISTING ENDPOINTS (UNCHANGED) ====================
@app.route('/api/data/<image_id>')
def get_geospatial_data(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        f.id,
                        f.target_class,
                        f.score,
                        ST_AsGeoJSON(f.target_geom) AS geometry,
                        ST_X(ST_Centroid(f.target_geom)) AS centroid_lon,
                        ST_Y(ST_Centroid(f.target_geom)) AS centroid_lat
                    FROM findings f
                    WHERE f.image_id = %s
                """, (image_id,))
                rows = cur.fetchall()
        features = []
        for row in rows:
            if row["geometry"]:
                geometry_data = json.loads(row["geometry"])
            else:
                geometry_data = {
                    "type": "Point", 
                    "coordinates": [
                        row["centroid_lon"] or 8.55, 
                        row["centroid_lat"] or 50.04
                    ]
                }
            features.append({
                "type": "Feature",
                "geometry": geometry_data,
                "properties": {
                    "id": row["id"],
                    "target_class": row["target_class"],
                    "score": float(row["score"]) if row["score"] is not None else None,
                    "centroid": [
                        float(row["centroid_lon"]) if row["centroid_lon"] is not None else 8.55,
                        float(row["centroid_lat"]) if row["centroid_lat"] is not None else 50.04
                    ]
                }
            })
        return jsonify({"type": "FeatureCollection", "features": features})
    except Exception as e:
        app.logger.error(f"Failed to fetch data for image_id={image_id}: {e}")
        return jsonify({"error": "Failed to retrieve geospatial data"}), 500

@app.route('/api/charts/<image_id>/target_class')
def get_target_class_counts(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT target_class, total_count
                    FROM comprehensive_query
                    WHERE image_id = %s
                """, (image_id,))
                rows = cur.fetchall()
        if not rows:
            with get_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        SELECT target_class, COUNT(*) as total_count
                        FROM findings 
                        WHERE image_id = %s
                        GROUP BY target_class
                    """, (image_id,))
                    rows = cur.fetchall()
        return jsonify([{"label": r["target_class"], "value": r["total_count"]} for r in rows])
    except Exception as e:
        app.logger.error(f"Chart query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to generate chart data"}), 500

@app.route('/reports')
def list_reports():
    try:
        files = [f for f in os.listdir(app.config['REPORTS_DIR']) if f.endswith('.txt')]
        return jsonify(sorted(files))
    except Exception as e:
        app.logger.error(f"Failed to list reports: {e}")
        return jsonify({"error": "Cannot list reports"}), 500

@app.route('/api/reports/<filename>')
def get_report(filename):
    if not filename.endswith('.txt'):
        return jsonify({"error": "Only .txt reports are allowed"}), 400
    try:
        return send_from_directory(app.config['REPORTS_DIR'], filename, mimetype='text/plain')
    except FileNotFoundError:
        return jsonify({"error": "Report not found"}), 404

# ==================== LOCAL BASEMAP ENDPOINTS ====================
@app.route('/api/local-basemap')
def get_local_basemap():
    basemap_dir = app.config['BASEMAPS_DIR']
    try:
        if not os.path.exists(basemap_dir):
            return get_dynamic_fallback_basemap()
        vector_files = []
        for file in os.listdir(basemap_dir):
            if file.endswith(('.shp', '.geojson', '.json', '.pbf')):
                vector_files.append(os.path.join(basemap_dir, file))
        if not vector_files:
            return get_dynamic_fallback_basemap()
        preferred_order = ['.geojson', '.json', '.shp', '.pbf']
        vector_files.sort(key=lambda x: next((i for i, ext in enumerate(preferred_order) if x.endswith(ext)), len(preferred_order)))
        found_vector_path = vector_files[0]
        if found_vector_path.endswith('.shp'):
            try:
                import geopandas as gpd
                gdf = gpd.read_file(found_vector_path)
                geojson_data = gdf.to_json()
                return jsonify(json.loads(geojson_data))
            except ImportError:
                return get_dynamic_fallback_basemap()
            except Exception as e:
                return get_dynamic_fallback_basemap()
        elif found_vector_path.endswith(('.geojson', '.json')):
            return send_file(found_vector_path, mimetype='application/geo+json')
        elif found_vector_path.endswith('.pbf'):
            return send_file(found_vector_path, mimetype='application/octet-stream')
    except Exception as e:
        return get_hardcoded_fallback_basemap()

def get_dynamic_fallback_basemap():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        ST_XMin(ST_Extent(target_geom)) as min_lon,
                        ST_YMin(ST_Extent(target_geom)) as min_lat, 
                        ST_XMax(ST_Extent(target_geom)) as max_lon,
                        ST_YMax(ST_Extent(target_geom)) as max_lat
                    FROM findings 
                    WHERE target_geom IS NOT NULL
                    LIMIT 1
                """)
                extent_result = cur.fetchone()
                if extent_result and extent_result['min_lon']:
                    min_lon = float(extent_result['min_lon'])
                    min_lat = float(extent_result['min_lat'])
                    max_lon = float(extent_result['max_lon'])
                    max_lat = float(extent_result['max_lat'])
                    lon_buffer = (max_lon - min_lon) * 0.1
                    lat_buffer = (max_lat - min_lat) * 0.1
                    dynamic_geojson = {
                        "type": "FeatureCollection",
                        "features": [{
                            "type": "Feature",
                            "geometry": {
                                "type": "Polygon",
                                "coordinates": [[
                                    [min_lon - lon_buffer, min_lat - lat_buffer],
                                    [max_lon + lon_buffer, min_lat - lat_buffer],
                                    [max_lon + lon_buffer, max_lat + lat_buffer],
                                    [min_lon - lon_buffer, max_lat + lat_buffer],
                                    [min_lon - lon_buffer, min_lat - lat_buffer]
                                ]]
                            },
                            "properties": {
                                "name": "Data Extent Boundary",
                                "type": "extent",
                                "source": "dynamic_fallback"
                            }
                        }]
                    }
                    return jsonify(dynamic_geojson)
    except Exception as e:
        pass
    return get_hardcoded_fallback_basemap()

def get_hardcoded_fallback_basemap():
    sample_geojson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [8.0, 49.5], [9.0, 49.5], [9.0, 50.5], [8.0, 50.5], [8.0, 49.5]
                    ]]
                },
                "properties": {"name": "Sample Region", "type": "administrative"}
            }
        ]
    }
    return jsonify(sample_geojson)

# ==================== PAGE ROUTES ====================
@app.route('/api')
def api_documentation_page():
    return send_from_directory('.', 'api-docs.html')

@app.route('/health-page')
def health_page():
    return send_from_directory('.', 'health.html')

@app.route('/basemap')
def basemap_page():
    return send_from_directory('.', 'basemap.html')

@app.route('/historical-deployment')  
def historical_deployment_page():
    return send_from_directory('.', 'historical.html')

@app.route('/api/historical-data')
def get_historical_data():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT image_date, target_class, COUNT(*) as total_count
                    FROM findings
                    GROUP BY image_date, target_class
                    ORDER BY image_date, total_count DESC
                """)
                rows = cur.fetchall()
        return jsonify([
            {'date': r['image_date'].isoformat() if r['image_date'] else None,
             'target_class': r['target_class'],
             'total_count': r['total_count']}
            for r in rows
        ])
    except Exception as e:
        app.logger.error(f"Historical data query failed: {e}")
        return jsonify({"error": "Failed to retrieve historical data"}), 500

# ==================== STATIC ASSETS (REMOVED COG/TILES) ====================
@app.route('/assets/<path:filename>')
def serve_assets(filename):
    return send_from_directory('dist/assets', filename)

# REMOVED: /cogs/<filename> — now served by NGINX

@app.route('/')
@app.route('/<path:path>')
def serve_frontend(path='index.html'):
    if os.path.exists(f"dist/{path}"):
        return send_from_directory('dist', path)
    else:
        return send_from_directory('dist', 'index.html')

@app.route('/api-list')
def list_endpoints():
    endpoints = []
    for rule in app.url_map.iter_rules():
        endpoints.append({
            "endpoint": rule.endpoint,
            "methods": list(rule.methods),
            "path": str(rule)
        })
    return jsonify(endpoints)

# ==================== HEALTH CHECK ====================
@app.route('/health')
def health_check():
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'version': '1.0.0-rc.4'
    }
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT 1')
        health_status['database'] = 'connected'
    except Exception as e:
        health_status['database'] = 'disconnected'
        health_status['status'] = 'unhealthy'
        health_status['database_error'] = str(e)

    def count_image_id_directories(directory):
        try:
            if not os.path.exists(directory):
                return 0
            items = os.listdir(directory)
            return sum(1 for item in items if os.path.isdir(os.path.join(directory, item)))
        except OSError:
            return 0

    def count_recursive_files(directory, extension):
        count = 0
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith(extension):
                    count += 1
        return count

    essential_dirs = {
        'reports_dir': app.config['REPORTS_DIR'],
        'cogs_dir': app.config['COGS_DIR'],
        'tiles_dir': app.config['TILES_DIR']
    }
    for dir_name, dir_path in essential_dirs.items():
        if os.path.exists(dir_path) and os.path.isdir(dir_path):
            health_status[dir_name] = 'exists'
            try:
                if dir_name == 'tiles_dir':
                    layer_count = count_image_id_directories(dir_path)
                    health_status[f'{dir_name}_layer_count'] = layer_count
                    tile_count = count_recursive_files(dir_path, '.png')
                    health_status[f'{dir_name}_tile_count'] = tile_count
                else:
                    file_count = len([f for f in os.listdir(dir_path) if os.path.isfile(os.path.join(dir_path, f))])
                    health_status[f'{dir_name}_file_count'] = file_count
            except OSError:
                health_status[f'{dir_name}_file_count'] = 'unaccessible'
        else:
            health_status[dir_name] = 'missing'
            health_status['status'] = 'degraded'

    status_code = 200 if health_status['status'] == 'healthy' else 503
    return jsonify(health_status), status_code

# ==================== ERROR HANDLING ====================
# Custom error handlers
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

@app.errorhandler(502)
def bad_gateway(e):
    return render_template('502.html'), 502

@app.errorhandler(503)
def service_unavailable(e):
    return render_template('503.html'), 503

@app.errorhandler(403)
def forbidden(error):
    return render_template('403.html'), 403

'''@app.errorhandler(500)
def handle_internal_error(e):
    app.logger.error(f"Internal error: {str(e)}")
    return jsonify({"error": "Internal server error"}), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found"}), 404'''

@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY' 
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    app.run(host='127.0.0.1', port=5000, debug=True)