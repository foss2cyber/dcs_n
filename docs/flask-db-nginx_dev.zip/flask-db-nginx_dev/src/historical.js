// src/historical.js - COMPLETE WORKING VERSION
import "open-props";
import { Chart, registerables } from "chart.js";
import "chartjs-adapter-date-fns";
Chart.register(...registerables);

const API_BASE = "/api";
let timelineChart = null;
let chartInitialized = false;

const currentSelections = {
  country: null,
  targetName: null,
  fromDate: "2020-01-01",
  toDate: new Date().toISOString().split("T")[0],
};

// Vibrant professional color palette
const vibrantColors = [
  "#3B82F6",
  "#10B981",
  "#F59E0B",
  "#EF4444",
  "#8B5CF6",
  "#06B6D4",
  "#84CC16",
  "#F97316",
  "#EC4899",
  "#14B8A6",
];

function getVibrantColor(index) {
  return vibrantColors[index % vibrantColors.length];
}

// View state
let currentView = "single";
let currentTimelineData = null;

// Main initialization
async function initializeHistoricalPage() {
  console.log("📊 Initializing Historical Page...");

  // Initialize chart in the existing container
  initializeTimelineChart();

  initializeViewToggle();
  await loadCountries();
  setupEventHandlers();

  document.getElementById("fromDate").value = currentSelections.fromDate;
  document.getElementById("toDate").value = currentSelections.toDate;

  updateStatus("Select country and airfield to view timeline graph");
}

function setupEventHandlers() {
  document
    .getElementById("historicalCountry")
    ?.addEventListener("change", async (e) => {
      currentSelections.country = e.target.value;
      if (currentSelections.country) {
        await loadTargets(currentSelections.country);
        updateStatus(`Country: ${currentSelections.country} - Select Airfield`);
      } else {
        clearTargets();
        clearChart();
      }
    });

  document
    .getElementById("historicalTarget")
    ?.addEventListener("change", async (e) => {
      currentSelections.targetName = e.target.value;
      if (currentSelections.targetName && currentSelections.country) {
        await loadHistoricalData();
      } else {
        clearChart();
      }
    });

  document
    .getElementById("applyFilter")
    ?.addEventListener("click", async () => {
      currentSelections.fromDate = document.getElementById("fromDate").value;
      currentSelections.toDate = document.getElementById("toDate").value;
      if (currentSelections.country && currentSelections.targetName) {
        await loadHistoricalData();
      }
    });

  document.getElementById("resetFilter")?.addEventListener("click", () => {
    document.getElementById("fromDate").value = "2020-01-01";
    document.getElementById("toDate").value = new Date()
      .toISOString()
      .split("T")[0];
    currentSelections.fromDate = "2020-01-01";
    currentSelections.toDate = new Date().toISOString().split("T")[0];
    if (currentSelections.country && currentSelections.targetName) {
      loadHistoricalData();
    }
  });

  document.getElementById("pageReset")?.addEventListener("click", resetPage);
}

// Chart initialization - FIXED
function initializeTimelineChart() {
  const timelineCanvas = document.getElementById("timelineChart");
  if (!timelineCanvas) {
    console.error("❌ Timeline chart canvas not found");
    return;
  }

  // Destroy existing chart if it exists
  if (timelineChart) {
    timelineChart.destroy();
  }

  timelineChart = new Chart(timelineCanvas, {
    type: "line",
    data: {
      datasets: [],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: "Select data to begin analysis",
          font: {
            size: 16,
            weight: "bold",
          },
          color: "var(--gray-12)",
          padding: 20,
        },
        legend: {
          display: true,
          position: "right",
          labels: {
            usePointStyle: true,
            padding: 15,
            font: { size: 12 },
          },
        },
        tooltip: {
          mode: "index",
          intersect: false,
          backgroundColor: "white",
          titleColor: "black",
          bodyColor: "darkslategrey",
          borderColor: "grey",
          borderWidth: 1,
          callbacks: {
            title: (context) =>
              new Date(context[0].parsed.x).toLocaleDateString(),
            label: (context) => `Count: ${context.parsed.y}`,
          },
        },
      },
      scales: {
        x: {
          type: "time",
          time: {
            unit: "month",
            tooltipFormat: "dd MMM yyyy",
          },
          grid: {
            color: "var(--gray-3)",
            drawBorder: true,
          },
          ticks: {
            color: "var(--gray-9)",
            maxTicksLimit: 8,
          },
          title: {
            display: true,
            text: "Date",
            color: "var(--gray-11)",
          },
        },
        y: {
          beginAtZero: true,
          suggestedMin: 0,
          suggestedMax: 10,
          grid: {
            color: "var(--gray-3)",
            drawBorder: true,
          },
          ticks: {
            stepSize: 1,
            precision: 0,
            color: "var(--gray-9)",
          },
          title: {
            display: true,
            text: "Count",
            color: "var(--gray-11)",
          },
        },
      },
      elements: {
        point: {
          radius: 6,
          hoverRadius: 10,
          borderWidth: 2,
          backgroundColor: "white",
        },
        line: {
          tension: 0.4,
          borderWidth: 3,
        },
      },
    },
  });

  console.log("✅ Timeline chart initialized");
}

function initializeViewToggle() {
  const viewToggle = document.getElementById("viewToggle");
  if (!viewToggle) return;

  viewToggle.querySelectorAll(".view-option").forEach((option) => {
    option.addEventListener("click", function () {
      viewToggle
        .querySelectorAll(".view-option")
        .forEach((opt) => opt.classList.remove("active"));
      this.classList.add("active");
      switchView(this.getAttribute("data-view"));
    });
  });
}

function switchView(view) {
  currentView = view;
  updateStatus(`View: ${view === "single" ? "Single Pane" : "Dual Pane"}`);

  if (currentTimelineData) {
    renderCurrentView();
  }
}

function renderCurrentView() {
  const chartContainer = document.getElementById("chartContainer");
  if (!chartContainer) return;

  chartContainer.innerHTML = "";
  chartContainer.className = `chart-container ${currentView}-pane`;

  if (currentView === "single") {
    renderSinglePane();
  } else {
    renderDualPane();
  }
}

function renderSinglePane() {
  const chartContainer = document.getElementById("chartContainer");
  chartContainer.innerHTML = `
    <div class="chart-card">
      <div class="chart-header">
        <h5 id="dynamicChartTitle">Timeline Analysis</h5>
      </div>
      <div style="height: 550px; position: relative;">
        <canvas id="timelineChart"></canvas>
        <div id="chartLoading" class="chart-overlay" style="display: none;">
          <div class="spinner"></div>
        </div>
      </div>
    </div>
  `;

  // Re-initialize chart in the new container
  initializeTimelineChart();

  // Update with current data if available
  if (currentTimelineData) {
    updateChartData(currentTimelineData);
  }
}

function renderDualPane() {
  if (!currentTimelineData?.length) {
    document.getElementById("chartContainer").innerHTML =
      '<div class="no-data">No data for dual pane</div>';
    return;
  }

  const chartsByTarget = groupDataByTarget(currentTimelineData);
  const chartContainer = document.getElementById("chartContainer");

  Object.entries(chartsByTarget).forEach(([targetName, targetData], index) => {
    const chartCard = document.createElement("div");
    chartCard.className = "chart-card dual-pane-card";

    const targetClasses = [
      ...new Set(targetData.map((item) => item.target_class)),
    ];
    const title =
      targetClasses.length === 1
        ? `Class: ${targetClasses[0]}`
        : `Classes: ${targetClasses.join(", ")}`;

    chartCard.innerHTML = `
      <div class="chart-header">
        <h6>${targetName}</h6>
        <small>${title}</small>
      </div>
      <div style="height: 250px;">
        <canvas id="dualChart${index}"></canvas>
      </div>
    `;

    chartContainer.appendChild(chartCard);
    createDualPaneChart(`dualChart${index}`, targetData);
  });
}

// FIXED: Update chart data function
function updateChartData(timelineData) {
  if (!timelineChart) {
    console.error("❌ Timeline chart not initialized");
    return;
  }

  console.log("📊 Updating chart with data:", timelineData);

  // Update dynamic title
  updateDynamicTitle(timelineData);

  // Create datasets
  const datasets = timelineData.map((item, index) => {
    const dataPoints = item.data_points
      .map((point) => ({
        x: new Date(point.date),
        y: point.count,
      }))
      .sort((a, b) => a.x - b.x);

    console.log(
      `📈 Dataset ${index}: ${item.target_name} - ${item.target_class}`,
      {
        points: dataPoints.length,
        dates: dataPoints.map((p) => p.x),
        counts: dataPoints.map((p) => p.y),
      }
    );

    return {
      label: `${item.target_name} - ${item.target_class}`,
      data: dataPoints,
      borderColor: getVibrantColor(index),
      backgroundColor: `${getVibrantColor(index)}20`,
      borderWidth: 3,
      fill: false,
      tension: 0.4,
      pointRadius: 6,
      pointHoverRadius: 10,
      pointBackgroundColor: "white",
      pointBorderColor: getVibrantColor(index),
      pointBorderWidth: 2,
    };
  });

  // Update chart
  timelineChart.data.datasets = datasets;

  // Adjust Y axis based on data
  const maxCount = Math.max(
    ...datasets.flatMap((dataset) => dataset.data.map((point) => point.y))
  );
  timelineChart.options.scales.y.suggestedMax = Math.max(10, maxCount + 2);

  timelineChart.update();
  console.log("✅ Chart updated with", datasets.length, "datasets");
}

function updateDynamicTitle(timelineData) {
  const titleElement = document.getElementById("dynamicChartTitle");
  if (!titleElement) return;

  const targetNames = [
    ...new Set(timelineData.map((item) => item.target_name)),
  ];
  const targetClasses = [
    ...new Set(timelineData.map((item) => item.target_class)),
  ];

  const targetName = targetNames[0];
  const classText =
    targetClasses.length === 1
      ? `Class: <code>${targetClasses[0]}</code>`
      : `Classes: <code>${targetClasses.join("</code>, <code>")}</code>`;

  titleElement.innerHTML = `Timeline: ${targetName} - ${classText}`;
}

function createDualPaneChart(canvasId, chartData) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;

  const datasets = chartData.map((item, index) => {
    const dataPoints = item.data_points
      .map((point) => ({ x: new Date(point.date), y: point.count }))
      .sort((a, b) => a.x - b.x);

    return {
      label: item.target_class,
      data: dataPoints,
      borderColor: getVibrantColor(index),
      backgroundColor: `${getVibrantColor(index)}20`,
      borderWidth: 2,
      fill: false,
      tension: 0.4,
    };
  });

  new Chart(ctx, {
    type: "line",
    data: { datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: datasets.length > 1 },
      },
      scales: {
        x: {
          type: "time",
          time: { unit: "month" },
          grid: { color: "var(--gray-3)" },
          display: true,
        },
        y: {
          beginAtZero: true,
          suggestedMin: 0,
          suggestedMax: 10,
          grid: { color: "var(--gray-3)" },
          ticks: { stepSize: 1 },
          display: true,
        },
      },
    },
  });
}

function groupDataByTarget(timelineData) {
  const grouped = {};
  timelineData.forEach((item) => {
    if (!grouped[item.target_name]) grouped[item.target_name] = [];
    grouped[item.target_name].push(item);
  });
  return grouped;
}

async function loadCountries() {
  try {
    const response = await fetch(`${API_BASE}/historical-countries`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const countries = await response.json();

    const select = document.getElementById("historicalCountry");
    if (select) {
      select.innerHTML = '<option value="">Select Country</option>';
      countries.forEach((country) => {
        const option = document.createElement("option");
        option.value = country;
        option.textContent = country;
        select.appendChild(option);
      });
    }
  } catch (error) {
    console.error("Failed to load countries:", error);
    updateStatus("Error loading countries");
  }
}

async function loadTargets(country) {
  try {
    const response = await fetch(
      `${API_BASE}/historical-targets/${encodeURIComponent(country)}`
    );
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const targets = await response.json();

    const select = document.getElementById("historicalTarget");
    if (select) {
      select.innerHTML = '<option value="">Select Airfield</option>';
      select.disabled = false;
      targets.forEach((target) => {
        const option = document.createElement("option");
        option.value = target;
        option.textContent = target;
        select.appendChild(option);
      });
    }
  } catch (error) {
    console.error("Failed to load targets:", error);
    updateStatus("Error loading targets");
  }
}

async function loadHistoricalData() {
  if (!currentSelections.country || !currentSelections.targetName) {
    updateStatus("Please select both country and target");
    return;
  }

  try {
    showLoading(true);
    updateStatus(`Loading data for ${currentSelections.targetName}...`);

    const params = new URLSearchParams({
      country: currentSelections.country,
      target_name: currentSelections.targetName,
    });

    if (currentSelections.fromDate)
      params.append("from_date", currentSelections.fromDate);
    if (currentSelections.toDate)
      params.append("to_date", currentSelections.toDate);

    const response = await fetch(`${API_BASE}/historical-timeline?${params}`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const timelineData = await response.json();
    currentTimelineData = timelineData;

    if (timelineData?.length) {
      updateChartData(timelineData);
      renderCurrentView();
    } else {
      updateStatus("No data found");
      clearChart();
    }
  } catch (error) {
    console.error("Failed to load data:", error);
    updateStatus("Error loading data");
    clearChart();
  } finally {
    showLoading(false);
  }
}

function resetPage() {
  console.log("🔄 Resetting page");

  currentSelections.country = null;
  currentSelections.targetName = null;
  currentSelections.fromDate = "2020-01-01";
  currentSelections.toDate = new Date().toISOString().split("T")[0];

  document.getElementById("historicalCountry").selectedIndex = 0;
  document.getElementById("historicalTarget").selectedIndex = 0;
  document.getElementById("historicalTarget").disabled = true;
  document.getElementById("fromDate").value = currentSelections.fromDate;
  document.getElementById("toDate").value = currentSelections.toDate;

  currentTimelineData = null;
  clearChart();

  currentView = "single";
  document
    .querySelectorAll(".view-option")
    .forEach((opt) => opt.classList.remove("active"));
  document
    .querySelector('.view-option[data-view="single"]')
    .classList.add("active");

  renderSinglePane();
  updateStatus("Select country and airfield to view timeline graph");
}

// Helper functions
function clearTargets() {
  const select = document.getElementById("historicalTarget");
  if (select) {
    select.innerHTML = '<option value="">Select Country First</option>';
    select.disabled = true;
  }
}

function clearChart() {
  if (timelineChart) {
    timelineChart.data.datasets = [];
    timelineChart.update();
  }
}

function updateStatus(message) {
  const element = document.getElementById("historicalStatus");
  if (element) element.textContent = message;
}

function showLoading(show) {
  const overlay = document.getElementById("chartLoading");
  if (overlay) overlay.style.display = show ? "flex" : "none";
}

// Make functions available globally for testing
window.updateChartData = updateChartData;
window.timelineChart = () => timelineChart;
window.debugData = () => currentTimelineData;

// Initialize
document.addEventListener("DOMContentLoaded", initializeHistoricalPage);
