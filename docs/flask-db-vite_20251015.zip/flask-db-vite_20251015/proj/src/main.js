// main.js - Complete with percentage score implementation
import "open-props/open-props.min.css";

import OlMap from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import XYZ from "ol/source/XYZ";
import GeoTIFFSource from "ol/source/GeoTIFF";
import WebGLTileLayer from "ol/layer/WebGLTile";
import { fromLonLat, toLonLat } from "ol/proj";
import { defaults as defaultInteractions } from "ol/interaction";
import { defaults as defaultControls } from "ol/control";
import ScaleLine from "ol/control/ScaleLine";
import Rotate from "ol/control/Rotate";
import { Style, Stroke, Fill, Circle as CircleStyle, Text } from "ol/style";
import Overlay from "ol/Overlay";

import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

import { marked } from "marked";

let map, vectorSource, barChart;
let cogLayer, xyzLayer;
let currentSelections = {
  country: null,
  targetType: null,
  imageId: null,
};
let currentFilters = {};

document.addEventListener("DOMContentLoaded", async () => {
  // ==================== DEBUG INITIALIZATION ====================
  console.log("🚀 main.js loaded successfully");
  console.log("📋 DOM Elements:", {
    countrySelector: document.getElementById("countrySelector"),
    targetTypeSelector: document.getElementById("targetTypeSelector"),
    imageIdSelector: document.getElementById("imageIdSelector"),
    map: document.getElementById("map"),
  });
  console.log("🗺️ OpenLayers available:", typeof OlMap);
  console.log("📊 Chart.js available:", typeof Chart);
  console.log("📝 Marked available:", typeof marked);

  // ==================== DOM ELEMENTS ====================
  const countrySelector = document.getElementById("countrySelector");
  const targetTypeSelector = document.getElementById("targetTypeSelector");
  const imageIdSelector = document.getElementById("imageIdSelector");
  const loadDataBtn = document.getElementById("loadDataBtn");
  const selectionStatus = document.getElementById("selectionStatus");
  const reportContent = document.getElementById("reportContent");
  const barCanvas = document.getElementById("barChart");
  const opacitySlider = document.getElementById("opacitySlider");
  const fitToDataBtn = document.getElementById("fitToData");
  const clearDataBtn = document.getElementById("clearData");
  const scoreRange = document.getElementById("scoreRange");
  const scoreValue = document.getElementById("scoreValue");

  if (!countrySelector || !targetTypeSelector || !imageIdSelector) {
    console.error("Required DOM elements not found");
    return;
  }

  // ==================== TOOLTIP SETUP ====================
  const tooltipElement = document.createElement("div");
  tooltipElement.className = "map-tooltip";
  document.body.appendChild(tooltipElement);

  const tooltipOverlay = new Overlay({
    element: tooltipElement,
    positioning: "bottom-center",
    offset: [0, -15],
    stopEvent: false,
  });

  // ==================== MAP SETUP ====================
  vectorSource = new VectorSource();

  const vectorLayer = new VectorLayer({
    source: vectorSource,
    style: function (feature) {
      const geom = feature.getGeometry();
      const isHover = feature.get("hover");
      const props = feature.getProperties();

      const styles = [
        new Style({
          stroke: new Stroke({
            color: isHover ? "#ff4444" : "#3388ff",
            width: isHover ? 4 : 3,
          }),
          fill: new Fill({
            color: isHover ? "rgba(255, 68, 68, 0.3)" : "rgba(51, 136, 255, 0)",
          }),
          zIndex: 2,
        }),
      ];

      if (
        geom &&
        (geom.getType() === "Polygon" || geom.getType() === "Point")
      ) {
        try {
          const centroid =
            geom.getType() === "Polygon" ? geom.getInteriorPoint() : geom;

          styles.push(
            new Style({
              geometry: centroid,
              image: new CircleStyle({
                radius: 6,
                fill: new Fill({
                  color: getColorForClass(props.target_class),
                }),
                stroke: new Stroke({
                  color: "white",
                  width: 1.5,
                }),
              }),
              zIndex: 1,
            })
          );
        } catch (e) {
          console.warn("Could not calculate centroid for feature:", e);
        }
      }

      return styles;
    },
  });

  cogLayer = new WebGLTileLayer({
    visible: false,
    opacity: 1,
    source: null,
  });

  xyzLayer = new TileLayer({
    visible: true,
    opacity: 1,
    source: null,
  });

  map = new OlMap({
    target: "map",
    layers: [cogLayer, xyzLayer, vectorLayer],
    view: new View({
      center: fromLonLat([8.55, 50.04]),
      zoom: 12,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" }),
      new Rotate({ autoHide: false }),
    ]),
    interactions: defaultInteractions(),
  });

  // Add this right after your map initialization in main.js
  setTimeout(() => {
    console.log("🗺️ Force map sizing");
    map.updateSize();
    map.render();
  }, 100);

  map.addOverlay(tooltipOverlay);

  // Force map controls to be visible and properly sized
  setTimeout(() => {
    map.updateSize();
    console.log("🗺️ Map controls initialized and visible");
  }, 100);

  // ==================== UPDATED TOOLTIP INTERACTION ====================
  let hoverFeature = null;

  map.on("pointermove", function (evt) {
    const feature = map.forEachFeatureAtPixel(evt.pixel, function (feature) {
      return feature;
    });

    if (feature) {
      if (hoverFeature !== feature) {
        if (hoverFeature) {
          hoverFeature.set("hover", false);
        }
        feature.set("hover", true);
        hoverFeature = feature;

        const props = feature.getProperties();
        const coordinates = evt.coordinate;

        const geometry = feature.getGeometry();
        let centroidCoords = [0, 0];
        if (geometry.getType() === "Polygon") {
          const centroid = geometry.getInteriorPoint();
          centroidCoords = toLonLat(centroid.getCoordinates());
        } else {
          centroidCoords = toLonLat(geometry.getCoordinates());
        }

        // ENHANCED: Proper target name display with fallbacks
        const displayName =
          props.target_name ||
          (props.target_class
            ? `Target_${props.target_class}`
            : "Unknown Target");

        tooltipElement.innerHTML = `
                <div class="tooltip-content">
                    <strong>${displayName}</strong>
                    <div class="tooltip-details">
                        <span class="tooltip-label">Class:</span> ${
                          props.target_class || "N/A"
                        }<br/>
                        <span class="tooltip-label">Type:</span> ${
                          props.target_type || "N/A"
                        }<br/>
                        <span class="tooltip-label">Score:</span> ${
                          props.score
                            ? (props.score * 100).toFixed(1) + "%"
                            : "N/A"
                        }<br/>
                        <span class="tooltip-label">Centroid:</span> ${centroidCoords[0].toFixed(
                          6
                        )}, ${centroidCoords[1].toFixed(6)}
                    </div>
                </div>
            `;

        tooltipOverlay.setPosition(coordinates);
        tooltipElement.style.display = "block";
      }
    } else {
      if (hoverFeature) {
        hoverFeature.set("hover", false);
        hoverFeature = null;
      }
      tooltipElement.style.display = "none";
    }
  });

  map.on("pointermove", function (evt) {
    const pixel = map.getEventPixel(evt.originalEvent);
    const hit = map.hasFeatureAtPixel(pixel);
    map.getTargetElement().style.cursor = hit ? "pointer" : "";
  });

  map.getViewport().addEventListener("mouseout", function () {
    tooltipElement.style.display = "none";
    if (hoverFeature) {
      hoverFeature.set("hover", false);
      hoverFeature = null;
    }
  });

  // ==================== UPDATED CONFIDENCE SCORE HANDLING (0-100%) ====================

  /**
   * Load filter options with percentage-based score range
   */
  async function loadFilterOptions(imageId) {
    try {
      console.log(
        "🎛️ Loading contextual filter options for:",
        imageId,
        currentSelections
      );

      // Build query parameters with current hierarchical context
      const params = new URLSearchParams();
      if (currentSelections.country) {
        params.append("country", currentSelections.country);
      }
      if (currentSelections.targetType) {
        params.append("target_name", currentSelections.targetType);
      }

      const res = await fetch(`/api/filter-options/${imageId}?${params}`);
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      const options = await res.json();

      console.log("🎛️ Contextual filter options received:", options);

      const classFilter = document.getElementById("classFilter");
      if (classFilter) {
        const currentClassValue = classFilter.value;
        classFilter.innerHTML =
          '<option value="">All Classes</option>' +
          (options.target_classes && Array.isArray(options.target_classes)
            ? options.target_classes
                .map((cls) => `<option value="${cls}">${cls}</option>`)
                .join("")
            : "");

        // Preserve current selection if it still exists in new options
        if (
          currentClassValue &&
          options.target_classes.includes(currentClassValue)
        ) {
          classFilter.value = currentClassValue;
        }
        console.log("🎛️ Class filter populated");
      }

      // Target name filter
      const nameFilter = document.getElementById("nameFilter");
      if (nameFilter) {
        const currentNameValue = nameFilter.value;
        nameFilter.innerHTML =
          '<option value="">All Names</option>' +
          (options.target_names && Array.isArray(options.target_names)
            ? options.target_names
                .map((name) => `<option value="${name}">${name}</option>`)
                .join("")
            : "");

        // Preserve current selection if it still exists
        if (
          currentNameValue &&
          options.target_names.includes(currentNameValue)
        ) {
          nameFilter.value = currentNameValue;
        }
        console.log(
          "🎛️ Name filter populated with contextual target_names:",
          options.target_names
        );
      }

      // UPDATED: Percentage-based score range handling
      if (scoreRange && scoreValue && options.score_range) {
        // Convert backend 0-1 range to 0-100 for frontend
        const minScorePercent = (options.score_range.min || 0) * 100;
        const maxScorePercent = (options.score_range.max || 1) * 100;

        scoreRange.min = 0;
        scoreRange.max = 100;
        scoreRange.step = 0.1;

        // Convert current score from 0-1 to 0-100 if needed
        let currentScorePercent = 0;
        if (currentFilters.min_score !== undefined) {
          currentScorePercent = currentFilters.min_score * 100;
        }

        scoreRange.value = currentScorePercent;
        scoreValue.textContent = `${parseFloat(currentScorePercent).toFixed(
          1
        )}%`;
        console.log("🎛️ Score range configured for percentages:", {
          min: minScorePercent,
          max: maxScorePercent,
        });
      }

      // Update filter context display
      updateFilterContextDisplay();
    } catch (error) {
      console.error("Failed to load filter options:", error);
    }
  }

  /**
   * Get current filters with percentage to decimal conversion
   */
  function getCurrentFilters() {
    const filters = {};
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");

    // Apply filters based on what's selected
    if (nameFilter && nameFilter.value) {
      filters.target_name = [nameFilter.value];
      console.log("🎛️ Filtering by target_name:", nameFilter.value);
    } else if (classFilter && classFilter.value) {
      filters.target_class = [classFilter.value];
      console.log("🎛️ Filtering by target_class:", classFilter.value);
    }

    // UPDATED: Apply score filter - convert percentage to decimal
    if (scoreRange && parseFloat(scoreRange.value) > 0) {
      filters.min_score = parseFloat(scoreRange.value) / 100;
      console.log(
        "🎛️ Filtering by min_score:",
        filters.min_score,
        `(${scoreRange.value}%)`
      );
    }

    console.log("🎛️ Final filters applied:", filters);
    return filters;
  }

  function resetFilters() {
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");
    const scoreValue = document.getElementById("scoreValue");

    if (classFilter) classFilter.value = "";
    if (nameFilter) nameFilter.value = "";
    if (scoreRange && scoreValue) {
      scoreRange.value = scoreRange.min;
      scoreValue.textContent = `${parseFloat(scoreRange.min).toFixed(1)}%`;
    }

    console.log("🎛️ Filters reset");
    updateFilterContextDisplay();
  }

  // Update score display in real-time
  if (scoreRange && scoreValue) {
    scoreRange.addEventListener("input", function () {
      scoreValue.textContent = `${parseFloat(this.value).toFixed(1)}%`;
    });
  }

  // ==================== UPDATED HIERARCHICAL DROPDOWN SYSTEM ====================

  /**
   * Load available countries from backend
   */
  async function loadCountries() {
    try {
      console.log("🌍 Starting loadCountries...");
      showLoadingState("country", "Loading countries...");
      const response = await fetch("/api/countries");
      console.log("🌍 API Response status:", response.status);

      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const countries = await response.json();
      console.log("🌍 Countries data received:", countries);

      countrySelector.innerHTML = '<option value="">Select Country</option>';

      if (countries.length > 0) {
        countries.forEach((country) => {
          const option = document.createElement("option");
          option.value = country;
          option.textContent = country;
          countrySelector.appendChild(option);
        });
        console.log("🌍 Country dropdown populated");
        updateSelectionStatus("Select a country to continue");
      } else {
        countrySelector.innerHTML =
          '<option value="">No countries available</option>';
        updateSelectionStatus("No countries found in database");
      }
    } catch (error) {
      console.error("Failed to load countries:", error);
      countrySelector.innerHTML =
        '<option value="">Error loading countries</option>';
      updateSelectionStatus("Error loading countries");
    } finally {
      console.log(
        "🌍 loadCountries completed, countrySelector disabled:",
        countrySelector.disabled
      );
      hideLoadingState("country");
      console.log(
        "🌍 After hideLoadingState, countrySelector disabled:",
        countrySelector.disabled
      );
    }
  }

  /**
   * Load target NAMES for selected country
   */
  async function loadTargetTypes(country) {
    if (!country) return;

    try {
      showLoadingState("targetType", "Loading target names...");
      targetTypeSelector.disabled = true;
      imageIdSelector.disabled = true;

      const response = await fetch(
        `/api/target-types/${encodeURIComponent(country)}`
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const targetNames = await response.json();
      targetTypeSelector.innerHTML =
        '<option value="">Select Target Name</option>';

      if (targetNames.length > 0) {
        targetNames.forEach((targetName) => {
          const option = document.createElement("option");
          option.value = targetName;
          option.textContent = targetName;
          targetTypeSelector.appendChild(option);
        });
        targetTypeSelector.disabled = false;
        updateSelectionStatus(`Country: ${country} - Select target name`);

        // Clear and reload filter options when hierarchy changes
        if (currentSelections.imageId) {
          await loadFilterOptions(currentSelections.imageId);
        }
      } else {
        targetTypeSelector.innerHTML =
          '<option value="">No target names available</option>';
        updateSelectionStatus(`No target names found for ${country}`);
      }
    } catch (error) {
      console.error("Failed to load target names:", error);
      targetTypeSelector.innerHTML =
        '<option value="">Error loading target names</option>';
      updateSelectionStatus("Error loading target names");
    } finally {
      hideLoadingState("targetType");
    }
  }

  /**
   * Load image IDs for selected country and target NAME
   */
  async function loadImageIds(country, targetName) {
    if (!country || !targetName) return;

    try {
      showLoadingState("imageId", "Loading image IDs...");
      imageIdSelector.disabled = true;

      const response = await fetch(
        `/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(
          targetName
        )}`
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const imageIds = await response.json();
      imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';

      if (imageIds.length > 0) {
        imageIds.forEach((imageId) => {
          const option = document.createElement("option");
          option.value = imageId;
          option.textContent = imageId;
          imageIdSelector.appendChild(option);
        });
        imageIdSelector.disabled = false;
        updateSelectionStatus(
          `Country: ${country}, Name: ${targetName} - Select image ID`
        );
      } else {
        imageIdSelector.innerHTML =
          '<option value="">No images available</option>';
        updateSelectionStatus(
          `No images found for ${targetName} in ${country}`
        );
      }
    } catch (error) {
      console.error("Failed to load image IDs:", error);
      imageIdSelector.innerHTML =
        '<option value="">Error loading images</option>';
      updateSelectionStatus("Error loading images");
    } finally {
      hideLoadingState("imageId");
      updateLoadButtonState();
    }
  }

  // ==================== UNIFIED DATA LOADING ====================

  /**
   * Load unified data (vector + chart) for selected image ID
   */
  async function loadUnifiedData(imageId, filters = {}) {
    if (!imageId) return;

    try {
      showMainLoading(true);
      updateSelectionStatus(`Loading data for ${imageId}...`);

      const queryParams = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          value.forEach((v) => queryParams.append(key, v));
        } else if (value) {
          queryParams.append(key, value);
        }
      });

      const url = `/api/unified-data/${imageId}?${queryParams}`;
      console.log("📡 Loading unified data from:", url);
      const response = await fetch(url);

      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const unifiedData = await response.json();
      console.log("✅ Unified data received:", unifiedData);

      // Load vector data to map
      await loadVectorData(unifiedData.vector_data);

      // Load chart data
      await loadChartData(unifiedData.chart_data);

      // Load report
      await loadReportData(imageId);

      // Update raster layers
      await updateRasterLayers(imageId);

      // Load filter options for advanced filters
      await loadFilterOptions(imageId);

      updateSelectionStatus(`Data loaded: ${imageId}`);
      fitToDataBtn.disabled = false;
    } catch (error) {
      console.error("Failed to load unified data:", error);
      updateSelectionStatus("Error loading data");
      reportContent.innerHTML =
        '<div class="error-message">Failed to load data. Please try again.</div>';
    } finally {
      showMainLoading(false);
    }
  }

  /**
   * Load vector data to map from unified response
   */
  async function loadVectorData(vectorData) {
    vectorSource.clear();

    if (vectorData && vectorData.features && vectorData.features.length > 0) {
      const features = new GeoJSON().readFeatures(vectorData, {
        featureProjection: "EPSG:3857",
      });
      vectorSource.addFeatures(features);

      // Fit view to data extent
      map.getView().fit(vectorSource.getExtent(), {
        padding: [50, 50, 50, 50],
        maxZoom: 16,
        duration: 1000, // Smooth animation
      });

      console.log(`✅ Loaded ${features.length} vector features`);
    } else {
      console.log("ℹ️ No vector features found");
    }
  }

  /**
   * Load chart data from unified response with proper target names
   */
  async function loadChartData(chartData) {
    if (barChart) barChart.destroy();

    if (!chartData || chartData.length === 0) {
      console.log("ℹ️ No chart data available");
      return;
    }

    // Chart configuration
    const baseBarThickness = 30;
    const minBarThickness = 20;
    const maxBarThickness = 50;
    const barThickness = Math.max(
      minBarThickness,
      Math.min(maxBarThickness, baseBarThickness - chartData.length * 0.5)
    );

    const accessibleColors = [
      "#3366CC",
      "#DC3912",
      "#FF9900",
      "#109618",
      "#990099",
      "#0099C6",
      "#DD4477",
      "#66AA00",
      "#B82E2E",
      "#316395",
    ];

    // ENHANCED: Use proper target names with fallbacks
    barChart = new Chart(barCanvas, {
      type: "bar",
      data: {
        labels: chartData.map(
          (d) => d.target_name || d.target_class || "Unknown Target"
        ),
        datasets: [
          {
            label: "Total Count",
            data: chartData.map((d) => d.total_count),
            backgroundColor: chartData.map(
              (d, i) => accessibleColors[i % accessibleColors.length]
            ),
            borderColor: chartData.map(
              (d, i) => accessibleColors[i % accessibleColors.length]
            ),
            borderWidth: 1,
            barThickness: barThickness,
            maxBarThickness: maxBarThickness,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
            labels: {
              font: {
                size: 13,
                weight: "bold",
              },
              color: "#2c3e50",
              usePointStyle: true,
            },
          },
          tooltip: {
            callbacks: {
              // ENHANCED: Proper target name in tooltip
              title: function (context) {
                const dataPoint = chartData[context[0].dataIndex];
                return (
                  dataPoint.target_name ||
                  dataPoint.target_class ||
                  "Unknown Target"
                );
              },
              label: function (context) {
                const dataPoint = chartData[context.dataIndex];
                return [
                  `Target: ${dataPoint.target_name || "Unknown"}`,
                  `Class: ${dataPoint.target_class || "N/A"}`,
                  `Type: ${dataPoint.target_type || "N/A"}`,
                  `Total Count: ${context.parsed.y}`,
                  `Avg Score: ${
                    dataPoint.avg_score
                      ? (dataPoint.avg_score * 100).toFixed(1) + "%"
                      : "N/A"
                  }`,
                ];
              },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Total Count",
              font: {
                size: 12,
                weight: "bold",
              },
            },
          },
          x: {
            title: {
              display: true,
              text: "Target Name",
              font: {
                size: 12,
                weight: "bold",
              },
            },
          },
        },
      },
    });

    console.log("✅ Chart loaded with", chartData.length, "data points");
  }

  // ==================== FIXED COG RENDERING ====================

  /**
   * Fixed COG layer configuration
   */
  async function updateRasterLayers(imageId) {
    console.log(`🔄 Updating raster layers for: ${imageId}`);

    // Enhanced XYZ source configuration
    const xyzSource = new XYZ({
      url: `/tiles/${imageId}/{z}/{x}/{y}.png`,
      crossOrigin: "anonymous",
      transition: 250,
      minZoom: 12,
      maxZoom: 20,
    });

    xyzLayer.setSource(xyzSource);
    xyzLayer.setVisible(true);
    xyzLayer.setOpacity(parseFloat(opacitySlider?.value || 1));

    // COG detection and configuration - FIXED VERSION
    const cogExtensions = [".tiff", ".tif"];
    let cogSource = null;
    let cogUrl = null;

    for (const ext of cogExtensions) {
      const testUrl = `/cogs/${imageId}${ext}`;
      try {
        const response = await fetch(testUrl, {
          method: "HEAD",
          cache: "no-cache",
          headers: { "Cache-Control": "no-cache" },
        });

        if (response.ok) {
          const contentLength = response.headers.get("content-length");

          if (contentLength && parseInt(contentLength) > 1000) {
            const imgResponse = await fetch(testUrl, {
              method: "GET",
              headers: {
                Range: "bytes=0-1000",
                "Cache-Control": "no-cache",
              },
            });

            if (imgResponse.ok) {
              const buffer = await imgResponse.arrayBuffer();
              const header = new Uint8Array(buffer);

              const isTIFF =
                (header[0] === 0x49 && header[1] === 0x49) ||
                (header[0] === 0x4d && header[1] === 0x4d);

              if (isTIFF) {
                cogUrl = testUrl;
                console.log(`✅ Valid COG found at: ${cogUrl}`);
                break;
              }
            }
          }
        }
      } catch (error) {
        console.log(`COG not found at: ${testUrl}:`, error.message);
      }
    }

    if (cogUrl) {
      try {
        // FIXED COG source configuration - removed problematic options
        cogSource = new GeoTIFFSource({
          sources: [
            {
              url: cogUrl,
              forceXHR: true,
              maxRanges: 10,
            },
          ],
          convertToRGB: true,
          normalize: true,
          wrapX: true,
          interpolate: true,
          maxZoom: 18,
          minZoom: 0,
          transition: 250,
        });

        // Error handling
        cogSource.on("error", (error) => {
          console.error(`❌ COG source error for ${imageId}:`, error);
          fallbackToXYZ();
        });

        cogLayer.setSource(cogSource);
        cogLayer.setOpacity(parseFloat(opacitySlider?.value || 1));

        // Update layer controls
        const cogRadio = document.querySelector('input[value="cog"]');
        if (cogRadio) {
          cogRadio.disabled = false;
          cogRadio.parentElement.style.opacity = "1";
          cogRadio.parentElement.title = "COG imagery available";
        }

        console.log(`✅ COG layer configured for: ${imageId}`);
      } catch (cogError) {
        console.error(`❌ COG layer creation failed for ${imageId}:`, cogError);
        fallbackToXYZ();
      }
    } else {
      console.warn(`❌ No valid COG found for: ${imageId}`);
      fallbackToXYZ();
    }

    function fallbackToXYZ() {
      const cogRadio = document.querySelector('input[value="cog"]');
      const xyzRadio = document.querySelector('input[value="xyz"]');

      if (cogRadio) {
        cogRadio.disabled = true;
        cogRadio.parentElement.style.opacity = "0.6";
        cogRadio.parentElement.title = "COG imagery not available";
      }

      if (xyzRadio && !xyzRadio.checked) {
        xyzRadio.checked = true;
      }

      cogLayer.setVisible(false);
      xyzLayer.setVisible(true);

      console.log(`🔄 Fallback to XYZ tiles for ${imageId}`);
    }
  }

  /**
   * Enhanced layer switching
   */
  function setupLayerControls() {
    document.querySelectorAll('input[name="layer"]').forEach((radio) => {
      radio.addEventListener("change", (e) => {
        const isCog = e.target.value === "cog";
        const cogHasSource = cogLayer.getSource() !== null;

        if (isCog && cogHasSource) {
          console.log("🔄 Switching to COG layer");
          cogLayer.setVisible(true);
          xyzLayer.setVisible(false);

          // Refresh view
          setTimeout(() => {
            map.getView().setZoom(map.getView().getZoom());
          }, 100);
        } else {
          console.log("🔄 Switching to XYZ layer");
          cogLayer.setVisible(false);
          xyzLayer.setVisible(true);
        }
      });
    });
  }

  // Initialize layer controls
  setupLayerControls();

  // ==================== EXISTING FUNCTIONS ====================

  async function loadReportData(imageId) {
    try {
      showReportLoading(true);
      const res = await fetch(`/api/reports/${imageId}.txt`);
      if (!res.ok) throw new Error("Report not found");
      const reportText = await res.text();
      reportContent.innerHTML = marked(reportText);
    } catch (error) {
      console.error("Failed to load report:", error);
      reportContent.innerHTML =
        '<div class="error-message">Report not available for this image.</div>';
    } finally {
      showReportLoading(false);
    }
  }

  function updateFilterContextDisplay() {
    const contextElement = document.querySelector(".filter-context");
    if (!contextElement) {
      // Create context element if it doesn't exist
      const filterSection = document.querySelector(".filter-section");
      if (filterSection) {
        const newContextElement = document.createElement("div");
        newContextElement.className = "filter-context";
        filterSection.insertBefore(newContextElement, filterSection.firstChild);
      }
      return;
    }

    let contextText = "";
    if (currentSelections.country && currentSelections.targetType) {
      contextText = `Filtering: ${currentSelections.country} → ${currentSelections.targetType}`;
    } else if (currentSelections.country) {
      contextText = `Filtering: ${currentSelections.country}`;
    } else {
      contextText = "No context - showing all data";
    }

    contextElement.innerHTML = `
      <span>Context:</span>
      <span class="context-value">${contextText}</span>
    `;
  }

  // ==================== UI STATE MANAGEMENT ====================

  function updateSelectionStatus(message) {
    if (selectionStatus) {
      selectionStatus.textContent = message;
      selectionStatus.title = message; // Add tooltip for overflow
    }
  }

  function updateLoadButtonState() {
    const hasAllSelections =
      currentSelections.country &&
      currentSelections.targetType &&
      currentSelections.imageId;
    if (loadDataBtn) {
      loadDataBtn.disabled = !hasAllSelections;
    }
  }

  function showLoadingState(selectorType, message) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = true;
      selector.innerHTML = `<option value="">${message}</option>`;
    }
  }

  function hideLoadingState(selectorType) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = false;
      console.log(`✅ ${selectorType} selector enabled`);
    }
  }

  function showMainLoading(show) {
    const mapLoading = document.getElementById("mapLoading");
    const chartLoading = document.getElementById("chartLoading");
    if (mapLoading) mapLoading.style.display = show ? "flex" : "none";
    if (chartLoading) chartLoading.style.display = show ? "flex" : "none";
  }

  function showReportLoading(show) {
    const reportLoading = document.getElementById("reportLoading");
    if (reportLoading) reportLoading.style.display = show ? "flex" : "none";
  }

  function clearAllData() {
    currentSelections = { country: null, targetType: null, imageId: null };
    currentFilters = {};

    // Reset dropdowns
    countrySelector.value = "";
    targetTypeSelector.innerHTML =
      '<option value="">Select Country First</option>';
    targetTypeSelector.disabled = true;
    imageIdSelector.innerHTML =
      '<option value="">Select Target Type First</option>';
    imageIdSelector.disabled = true;

    // Clear data displays
    vectorSource.clear();
    if (barChart) {
      barChart.destroy();
      barChart = null;
    }
    reportContent.innerHTML = `
            <div class="report-placeholder">
                <div class="placeholder-icon">📊</div>
                <p>Select a country, target type, and image ID to view the analysis report.</p>
            </div>
        `;

    // Reset map view
    map.getView().setCenter(fromLonLat([8.55, 50.04]));
    map.getView().setZoom(12);

    // Reset filters
    resetFilters();

    // Update UI states
    updateLoadButtonState();
    fitToDataBtn.disabled = true;
    updateSelectionStatus("Ready to load data");
  }

  // Helper function
  function getColorForClass(targetClass) {
    const colorMap = {
      "FR-AF-CGAA-1": "#3366CC",
      "FR-AP-CGSV-1": "#DC3912",
      "FR-AF-CPA-2": "#FF9900",
      "FR-AF-CCTA-3": "#109618",
      "FR-AF-CCA-4": "#990099",
      "FR-AP-CMV-2": "#0099C6",
    };
    return colorMap[targetClass] || "#666666";
  }

  // ==================== ENHANCED EVENT HANDLERS ====================

  // Country selection - UPDATED to reload filters
  countrySelector.addEventListener("change", async (e) => {
    const country = e.target.value;
    currentSelections.country = country;
    currentSelections.targetType = null;
    currentSelections.imageId = null;

    // Reset dependent dropdowns
    targetTypeSelector.innerHTML =
      '<option value="">Select Target Name</option>';
    targetTypeSelector.disabled = !country;
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = true;

    // Reset filters when hierarchy changes
    resetFilters();

    if (country) {
      await loadTargetTypes(country);
      // Reload filter options if we have an image ID selected
      if (currentSelections.imageId) {
        await loadFilterOptions(currentSelections.imageId);
      }
    } else {
      updateSelectionStatus("Select a country to continue");
    }
    updateLoadButtonState();
  });

  // Target type selection - UPDATED to reload filters
  targetTypeSelector.addEventListener("change", async (e) => {
    const targetName = e.target.value;
    currentSelections.targetType = targetName;
    currentSelections.imageId = null;

    // Reset image ID dropdown
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = !targetName;

    // Reset filters when hierarchy changes
    resetFilters();

    if (targetName && currentSelections.country) {
      await loadImageIds(currentSelections.country, targetName);
      // Reload filter options if we have an image ID selected
      if (currentSelections.imageId) {
        await loadFilterOptions(currentSelections.imageId);
      }
    }
    updateLoadButtonState();
  });

  // Image ID selection - UPDATED to reload filters
  imageIdSelector.addEventListener("change", async (e) => {
    currentSelections.imageId = e.target.value;

    if (currentSelections.imageId) {
      // Load filter options with current hierarchical context
      await loadFilterOptions(currentSelections.imageId);
      updateSelectionStatus(`Ready to load: ${currentSelections.imageId}`);
    }
    updateLoadButtonState();
  });

  // Load data button
  loadDataBtn.addEventListener("click", () => {
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  });

  // Enhanced filter application
  const applyFiltersBtn = document.getElementById("applyFilters");
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener("click", () => {
      if (currentSelections.imageId) {
        currentFilters = getCurrentFilters();
        console.log("🎛️ Applying filters with context:", currentFilters);
        loadUnifiedData(currentSelections.imageId, currentFilters);
      }
    });
  }

  // Enhanced filter reset
  const resetFiltersBtn = document.getElementById("resetFilters");
  if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener("click", () => {
      resetFilters();
      if (currentSelections.imageId) {
        currentFilters = {};
        console.log("🎛️ Resetting all filters");
        loadUnifiedData(currentSelections.imageId);
      }
    });
  }

  // Quick actions
  if (fitToDataBtn) {
    fitToDataBtn.addEventListener("click", () => {
      if (vectorSource.getFeatures().length > 0) {
        console.log("🎯 Fitting map to data extent");
        map.getView().fit(vectorSource.getExtent(), {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 1000,
        });
      } else {
        console.log("⚠️ No features to fit to");
      }
    });
  }

  if (clearDataBtn) {
    clearDataBtn.addEventListener("click", clearAllData);
  }

  // Layer and opacity controls
  if (opacitySlider) {
    opacitySlider.addEventListener("input", () => {
      const opacity = parseFloat(opacitySlider.value);
      cogLayer.setOpacity(opacity);
      xyzLayer.setOpacity(opacity);
    });
  }

  // ==================== INITIALIZATION ====================
  await loadCountries();
});
