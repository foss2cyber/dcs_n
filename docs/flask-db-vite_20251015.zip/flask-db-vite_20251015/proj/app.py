# app.py
import os
import re
import json
import datetime
import logging
from flask import Flask, jsonify, request, send_file, send_from_directory
import psycopg2
from psycopg2.extras import RealDictCursor
from config import Config

app = Flask(__name__,
    static_folder='public',
    static_url_path=''
)
app.config.from_object(Config)
os.makedirs(app.config['REPORTS_DIR'], exist_ok=True)

def get_db():
    return psycopg2.connect(
        dsn=app.config['DB_URL'],
        cursor_factory=RealDictCursor
    )

# ==================== UPDATED HIERARCHICAL DROPDOWN ENDPOINTS ====================

@app.route('/api/countries')
def get_countries():
    """Get distinct countries available in the database"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get countries from comprehensive_query (most reliable source)
                cur.execute("""
                    SELECT DISTINCT country_name 
                    FROM comprehensive_query 
                    WHERE country_name IS NOT NULL 
                    ORDER BY country_name
                """)
                countries = [row['country_name'] for row in cur.fetchall()]
                
                # Fallback to target table if no countries found
                if not countries:
                    cur.execute("""
                        SELECT DISTINCT country_name 
                        FROM target 
                        WHERE country_name IS NOT NULL 
                        ORDER BY country_name
                    """)
                    countries = [row['country_name'] for row in cur.fetchall()]
                
        return jsonify(countries)
        
    except Exception as e:
        app.logger.error(f"Countries query failed: {e}")
        return jsonify([])

@app.route('/api/target-types/<country>')
def get_target_types(country):
    """Get distinct target NAMES for a specific country - FIXED with proper joins"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get target NAMES from sql_scat_query2 (primary source) with proper filtering
                cur.execute("""
                    SELECT DISTINCT sq.target_name 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name IS NOT NULL 
                    ORDER BY sq.target_name
                """, (country,))
                target_names = [row['target_name'] for row in cur.fetchall()]
                
        return jsonify(target_names)
        
    except Exception as e:
        app.logger.error(f"Target names query failed for {country}: {e}")
        return jsonify([])

@app.route('/api/image-ids/<country>/<target_name>')
def get_image_ids(country, target_name):
    """Get distinct image IDs for a specific country and target NAME - FIXED with proper filtering"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.image_id 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name = %s 
                    AND sq.image_id IS NOT NULL 
                    ORDER BY sq.image_id
                """, (country, target_name))
                image_ids = [row['image_id'] for row in cur.fetchall()]
                
        return jsonify(image_ids)
        
    except Exception as e:
        app.logger.error(f"Image IDs query failed for {country}/{target_name}: {e}")
        return jsonify([])

# ==================== UPDATED UNIFIED FILTERING ENDPOINT ====================

@app.route('/api/unified-data/<image_id>')
def get_unified_data(image_id):
    """Unified endpoint with proper target_type joining"""
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    
    target_names = request.args.getlist('target_name')
    target_classes = request.args.getlist('target_class')
    min_score = request.args.get('min_score', 0.0, type=float)
    max_score = request.args.get('max_score', 1.0, type=float)
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # VECTOR DATA - Use sql_scat_query2 joined with target_classification
                vector_query = """
                    SELECT 
                        sq.target_name,
                        sq.country_name,
                        sq.image_id, 
                        sq.image_date,
                        sq.target_class,
                        sq.score,
                        sq.st_x as centroid_lon,
                        sq.st_y as centroid_lat,
                        COALESCE(tc.target_type, t.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target_classification tc ON sq.target_class = tc.target_class
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.image_id = %s
                """
                vector_params = [image_id]
                vector_conditions = []
                
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    vector_conditions.append(f"sq.target_name IN ({placeholders})")
                    vector_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    vector_conditions.append(f"sq.target_class IN ({placeholders})")
                    vector_params.extend(target_classes)
                    
                if min_score > 0:
                    vector_conditions.append("sq.score >= %s")
                    vector_params.append(min_score)
                    
                if max_score < 1.0:
                    vector_conditions.append("sq.score <= %s")
                    vector_params.append(max_score)
                
                if vector_conditions:
                    vector_query += " AND " + " AND ".join(vector_conditions)
                
                cur.execute(vector_query, vector_params)
                vector_rows = cur.fetchall()
                
                # Format vector features
                vector_features = []
                for row in vector_rows:
                    # Create a bounding box around the centroid
                    geometry_data = {
                        "type": "Polygon",
                        "coordinates": [[
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001]
                        ]]
                    }
                    
                    vector_features.append({
                        "type": "Feature",
                        "geometry": geometry_data,
                        "properties": {
                            "id": f"{row['image_id']}_{row['target_class']}",
                            "target_class": row["target_class"],
                            "target_name": row["target_name"],
                            "target_type": row["target_type"],
                            "country_name": row["country_name"],
                            "score": float(row["score"]) if row["score"] is not None else None,
                            "centroid": [float(row["centroid_lon"]), float(row["centroid_lat"])]
                        }
                    })
                
                # CHART DATA - Use comprehensive_query joined with target_classification
                chart_query = """
                    SELECT 
                        cq.target_name,
                        cq.target_class, 
                        cq.total_count,
                        cq.score as avg_score,
                        COALESCE(tc.target_type, 'N/A') as target_type
                    FROM comprehensive_query cq
                    LEFT JOIN target_classification tc ON cq.target_class = tc.target_class
                    WHERE cq.image_id = %s
                """
                chart_params = [image_id]
                chart_conditions = []
                
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    chart_conditions.append(f"cq.target_name IN ({placeholders})")
                    chart_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    chart_conditions.append(f"cq.target_class IN ({placeholders})")
                    chart_params.extend(target_classes)
                    
                if min_score > 0:
                    chart_conditions.append("cq.score >= %s")
                    chart_params.append(min_score)
                    
                if max_score < 1.0:
                    chart_conditions.append("cq.score <= %s")
                    chart_params.append(max_score)
                
                if chart_conditions:
                    chart_query += " AND " + " AND ".join(chart_conditions)
                
                chart_query += " ORDER BY cq.total_count DESC"
                
                cur.execute(chart_query, chart_params)
                chart_rows = cur.fetchall()
                
                chart_data = [
                    {
                        'target_name': row['target_name'],
                        'target_class': row['target_class'],
                        'target_type': row['target_type'],
                        'total_count': row['total_count'],
                        'avg_score': float(row['avg_score']) if row['avg_score'] is not None else 0.0
                    }
                    for row in chart_rows
                ]
        
        return jsonify({
            "vector_data": {
                "type": "FeatureCollection", 
                "features": vector_features
            },
            "chart_data": chart_data
        })
        
    except Exception as e:
        app.logger.error(f"Unified data query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to retrieve unified data"}), 500

@app.route('/api/filter-options/<image_id>')
def get_filter_options(image_id):
    """Get available filter values with hierarchical context - ENHANCED with percentage scores"""
    country = request.args.get('country')
    target_name = request.args.get('target_name')
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get target names based on current hierarchy
                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                        ORDER BY sq.target_name
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                        ORDER BY sq.target_name
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_name
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s 
                        ORDER BY sq.target_name
                    """, (image_id,))
                
                names_result = cur.fetchall()
                target_names = [row['target_name'] for row in names_result if row['target_name']]
                
                # Get target classes with the same hierarchical context
                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                        ORDER BY sq.target_class
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                        ORDER BY sq.target_class
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s 
                        ORDER BY sq.target_class
                    """, (image_id,))
                
                classes = [row['target_class'] for row in cur.fetchall()]
                
                # Get score range with the same hierarchical context - return as 0-1 for percentage conversion
                if country and target_name:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                
                score_result = cur.fetchone()
                
        return jsonify({
            'target_names': target_names or [],
            'target_classes': classes or [],
            'score_range': {
                'min': float(score_result['min_score']) if score_result and score_result['min_score'] is not None else 0.0,
                'max': float(score_result['max_score']) if score_result and score_result['max_score'] is not None else 1.0
            }
        })
        
    except Exception as e:
        app.logger.error(f"Filter options query failed for {image_id}: {e}")
        return jsonify({
            'target_names': [],
            'target_classes': [],
            'score_range': {'min': 0.0, 'max': 1.0}
        })

# ==================== DYNAMIC LOCAL BASEMAP ENDPOINTS ====================

# ==================== DYNAMIC LOCAL BASEMAP ENDPOINTS ====================

@app.route('/api/local-basemap')
def get_local_basemap():
    """Dynamic local basemap data - attempts to load real vector data from ./public/basemaps/, falls back to sample"""
    basemap_dir = 'public/basemaps'  # Define at function scope
    
    try:
        # Check if basemaps directory exists
        if not os.path.exists(basemap_dir):
            app.logger.info(f"Basemaps directory not found: {basemap_dir}")
            return get_dynamic_fallback_basemap()
        
        # Look for vector files in the basemaps directory
        vector_files = []
        for file in os.listdir(basemap_dir):
            if file.endswith(('.shp', '.geojson', '.json', '.pbf')):
                vector_files.append(os.path.join(basemap_dir, file))
        
        if not vector_files:
            app.logger.info(f"No vector files found in {basemap_dir}")
            return get_dynamic_fallback_basemap()
        
        # Sort files by preference: GeoJSON first (easiest to serve), then Shapefile, then PBF
        preferred_order = ['.geojson', '.json', '.shp', '.pbf']
        vector_files.sort(key=lambda x: [preferred_order.index(ext) if any(ext in x for ext in preferred_order) else len(preferred_order) for ext in preferred_order][0])
        
        found_vector_path = vector_files[0]
        app.logger.info(f"Found local vector data at: {found_vector_path}")
        
        # Load and serve the actual vector data
        if found_vector_path.endswith('.shp'):
            try:
                import geopandas as gpd
                gdf = gpd.read_file(found_vector_path)
                geojson_data = gdf.to_json()
                app.logger.info(f"Serving shapefile with {len(gdf)} features")
                return jsonify(json.loads(geojson_data))
            except ImportError:
                app.logger.warning("Geopandas not available, falling back to dynamic basemap")
                return get_dynamic_fallback_basemap()
            except Exception as e:
                app.logger.error(f"Error reading shapefile {found_vector_path}: {e}")
                return get_dynamic_fallback_basemap()
                
        elif found_vector_path.endswith(('.geojson', '.json')):
            try:
                # Directly serve GeoJSON file
                app.logger.info(f"Serving GeoJSON file: {found_vector_path}")
                return send_file(found_vector_path, mimetype='application/geo+json')
            except Exception as e:
                app.logger.error(f"Error serving GeoJSON {found_vector_path}: {e}")
                return get_dynamic_fallback_basemap()
                
        elif found_vector_path.endswith('.pbf'):
            try:
                # For PBF, serve as binary
                app.logger.info(f"Serving PBF file: {found_vector_path}")
                return send_file(found_vector_path, mimetype='application/octet-stream')
            except Exception as e:
                app.logger.error(f"Error serving PBF {found_vector_path}: {e}")
                return get_dynamic_fallback_basemap()
        
    except Exception as e:
        app.logger.error(f"Failed to load local basemap: {e}")
        # Final fallback to hardcoded sample
        return get_hardcoded_fallback_basemap()

def get_dynamic_fallback_basemap():
    """Generate dynamic fallback basemap based on actual data extent"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get actual data extent from findings
                cur.execute("""
                    SELECT 
                        ST_XMin(ST_Extent(target_geom)) as min_lon,
                        ST_YMin(ST_Extent(target_geom)) as min_lat, 
                        ST_XMax(ST_Extent(target_geom)) as max_lon,
                        ST_YMax(ST_Extent(target_geom)) as max_lat
                    FROM findings 
                    WHERE target_geom IS NOT NULL
                    LIMIT 1
                """)
                extent_result = cur.fetchone()
                
                if extent_result and extent_result['min_lon']:
                    # Create bounding box around actual data extent
                    min_lon = float(extent_result['min_lon'])
                    min_lat = float(extent_result['min_lat'])
                    max_lon = float(extent_result['max_lon'])
                    max_lat = float(extent_result['max_lat']) # type: ignore
                    
                    # Expand bounds slightly for better visualization
                    lon_buffer = (max_lon - min_lon) * 0.1
                    lat_buffer = (max_lat - min_lat) * 0.1
                    
                    dynamic_geojson = {
                        "type": "FeatureCollection",
                        "features": [
                            {
                                "type": "Feature",
                                "geometry": {
                                    "type": "Polygon",
                                    "coordinates": [[
                                        [min_lon - lon_buffer, min_lat - lat_buffer],
                                        [max_lon + lon_buffer, min_lat - lat_buffer],
                                        [max_lon + lon_buffer, max_lat + lat_buffer],
                                        [min_lon - lon_buffer, max_lat + lat_buffer],
                                        [min_lon - lon_buffer, min_lat - lat_buffer]
                                    ]]
                                },
                                "properties": {
                                    "name": "Data Extent Boundary",
                                    "type": "extent",
                                    "source": "dynamic_fallback",
                                    "description": f"Data extent: {min_lon:.4f},{min_lat:.4f} to {max_lon:.4f},{max_lat:.4f}"
                                }
                            }
                        ]
                    }
                    app.logger.info("Serving dynamic extent-based basemap")
                    return jsonify(dynamic_geojson)
                else:
                    app.logger.info("No spatial data found in database for dynamic basemap")
                    
    except Exception as e:
        app.logger.warning(f"Could not generate dynamic basemap: {e}")
    
    # Ultimate fallback to hardcoded sample
    return get_hardcoded_fallback_basemap()

def get_hardcoded_fallback_basemap():
    """Final fallback - hardcoded sample data"""
    app.logger.info("Using hardcoded fallback basemap")
    sample_geojson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [8.0, 49.5], [9.0, 49.5], [9.0, 50.5], [8.0, 50.5], [8.0, 49.5]
                    ]]
                },
                "properties": {
                    "name": "Sample Region",
                    "type": "administrative",
                    "source": "hardcoded_fallback",
                    "description": "Fallback sample data - no local basemap files found"
                }
            },
            {
                "type": "Feature", 
                "geometry": {
                    "type": "Point",
                    "coordinates": [8.55, 50.04]
                },
                "properties": {
                    "name": "Frankfurt Area",
                    "type": "location",
                    "source": "hardcoded_fallback",
                    "description": "Central reference point"
                }
            },
            {
                "type": "Feature",
                "geometry": {
                    "type": "LineString",
                    "coordinates": [
                        [8.0, 50.0], [8.2, 50.1], [8.4, 50.0], [8.6, 49.9], [8.8, 50.0]
                    ]
                },
                "properties": {
                    "name": "Sample Route",
                    "type": "transportation",
                    "source": "hardcoded_fallback"
                }
            }
        ]
    }
    return jsonify(sample_geojson)

@app.route('/api/local-basemap-info')
def get_local_basemap_info():
    """Return information about available local basemap data sources"""
    basemap_dir = 'public/basemaps'  # Define at function scope
    
    sources_info = {
        "available_sources": [],
        "active_source": None,
        "data_type": None,
        "basemap_directory": basemap_dir
    }
    
    try:
        # Check the main basemaps directory
        if os.path.exists(basemap_dir) and os.path.isdir(basemap_dir):
            for file in os.listdir(basemap_dir):
                if file.endswith(('.shp', '.geojson', '.json', '.pbf')):
                    full_path = os.path.join(basemap_dir, file)
                    file_type = 'shapefile' if file.endswith('.shp') else \
                               'geojson' if file.endswith(('.geojson', '.json')) else \
                               'pbf' if file.endswith('.pbf') else 'unknown'
                    
                    sources_info["available_sources"].append({
                        'path': full_path,
                        'type': file_type,
                        'size': os.path.getsize(full_path) if os.path.isfile(full_path) else None,
                        'filename': file
                    })
        
        # Sort sources by file type preference
        type_preference = {'geojson': 1, 'shapefile': 2, 'pbf': 3, 'unknown': 4}
        sources_info["available_sources"].sort(key=lambda x: type_preference.get(x['type'], 99))
        
        if sources_info["available_sources"]:
            sources_info["active_source"] = sources_info["available_sources"][0]
            sources_info["data_type"] = "local_file"
            sources_info["status"] = "success"
            app.logger.info(f"Found {len(sources_info['available_sources'])} basemap source(s)")
        else:
            sources_info["data_type"] = "fallback"
            sources_info["active_source"] = {"type": "dynamic_fallback", "description": "No local basemap files found"}
            sources_info["status"] = "fallback"
            app.logger.info("No local basemap files found, using fallback")
            
    except Exception as e:
        app.logger.error(f"Error getting basemap info: {e}")
        sources_info["data_type"] = "error"
        sources_info["status"] = "error"
        sources_info["error"] = str(e)
        
    return jsonify(sources_info)

@app.route('/api/basemap-files')
def list_basemap_files():
    """List all available basemap files in the basemaps directory"""
    basemap_dir = 'public/basemaps'  # Define at function scope
    
    try:
        files_info = []
        
        if os.path.exists(basemap_dir) and os.path.isdir(basemap_dir):
            for file in os.listdir(basemap_dir):
                if file.endswith(('.shp', '.geojson', '.json', '.pbf')):
                    full_path = os.path.join(basemap_dir, file)
                    file_type = 'shapefile' if file.endswith('.shp') else \
                               'geojson' if file.endswith(('.geojson', '.json')) else \
                               'pbf' if file.endswith('.pbf') else 'unknown'
                    
                    file_stats = os.stat(full_path)
                    files_info.append({
                        'name': file,
                        'type': file_type,
                        'size': file_stats.st_size,
                        'size_mb': round(file_stats.st_size / (1024 * 1024), 2),
                        'modified': file_stats.st_mtime,
                        'path': full_path
                    })
            
            # Sort by file type and name
            files_info.sort(key=lambda x: (x['type'], x['name']))
        
        return jsonify({
            'directory': basemap_dir,
            'exists': os.path.exists(basemap_dir),
            'files': files_info,
            'total_files': len(files_info)
        })
        
    except Exception as e:
        app.logger.error(f"Error listing basemap files: {e}")
        return jsonify({
            'directory': basemap_dir,
            'exists': os.path.exists(basemap_dir),
            'files': [],
            'total_files': 0,
            'error': str(e)
        })

# ==================== ENHANCED BASEMAP ENDPOINTS WITH IMAGERY SUPPORT ====================

# ==================== DEBUG BASEMAP ENDPOINT ====================

@app.route('/api/debug-basemap')
def debug_basemap():
    """Debug endpoint to check basemap data"""
    try:
        basemap_dir = 'public/basemaps'
        
        # Check what files exist
        files = []
        if os.path.exists(basemap_dir):
            for file in os.listdir(basemap_dir):
                full_path = os.path.join(basemap_dir, file)
                files.append({
                    'name': file,
                    'size': os.path.getsize(full_path),
                    'type': 'geojson' if file.endswith(('.geojson', '.json')) else 'shapefile' if file.endswith('.shp') else 'other'
                })
        
        # Get the actual basemap data
        basemap_response = get_local_basemap()
        basemap_data = basemap_response.get_json()
        
        # Check if it's a valid GeoJSON
        is_valid_geojson = (
            basemap_data and 
            isinstance(basemap_data, dict) and 
            basemap_data.get('type') == 'FeatureCollection' and 
            'features' in basemap_data
        )
        
        debug_info = {
            'basemaps_directory': basemap_dir,
            'directory_exists': os.path.exists(basemap_dir),
            'files_count': len(files),
            'files': files,
            'basemap_data_info': {
                'is_valid_geojson': is_valid_geojson,
                'data_type': type(basemap_data).__name__ if basemap_data else 'None',
                'has_features': 'features' in basemap_data if basemap_data else False,
                'feature_count': len(basemap_data.get('features', [])) if basemap_data else 0,
            },
            'sample_data': None
        }
        
        # Add sample data if available
        if is_valid_geojson and basemap_data['features']:
            sample_features = []
            for i, feature in enumerate(basemap_data['features'][:3]):  # First 3 features
                sample_features.append({
                    'index': i,
                    'geometry_type': feature.get('geometry', {}).get('type') if feature.get('geometry') else 'no geometry',
                    'properties_keys': list(feature.get('properties', {}).keys()) if feature.get('properties') else [],
                    'has_geometry': bool(feature.get('geometry'))
                })
            debug_info['sample_data'] = sample_features
        
        return jsonify(debug_info)
        
    except Exception as e:
        import traceback
        return jsonify({
            'error': str(e),
            'traceback': traceback.format_exc()
        })

# ==================== ENHANCED BASEMAP WITH IMAGERY ENDPOINT ====================

@app.route('/api/basemap-with-imagery')
def get_basemap_with_imagery():
    """Serve basemap data with imagery layer information"""
    try:
        # Get basemap data
        basemap_response = get_local_basemap()
        basemap_data = basemap_response.get_json()
        
        # Get available imagery layers
        imagery_layers = get_available_imagery_layers()
        
        response_data = {
            'vector_data': basemap_data,
            'imagery_layers': imagery_layers,
            'default_imagery': 'xyz' if any(layer['type'] == 'xyz' for layer in imagery_layers) else 'cog' if imagery_layers else 'none'
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        app.logger.error(f"Failed to get basemap with imagery: {e}")
        return jsonify({
            'vector_data': get_hardcoded_fallback_basemap().get_json(),
            'imagery_layers': [],
            'error': str(e)
        })

@app.route('/api/imagery-layers')
def get_imagery_layers():
    """Get available imagery layers"""
    return jsonify(get_available_imagery_layers())

# ==================== ENHANCED HISTORICAL TIMELINE ENDPOINT ====================

@app.route('/api/historical-timeline')
def get_historical_timeline():
    """Enhanced historical timeline data with hierarchical filtering"""
    country = request.args.get('country')
    target_type = request.args.get('target_type')
    target_name = request.args.get('target_name')
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Build query based on filters
                query = """
                    SELECT 
                        sq.target_name,
                        sq.image_date,
                        COUNT(*) as detection_count,
                        COALESCE(tc.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target_classification tc ON sq.target_class = tc.target_class
                    WHERE sq.country_name = %s
                """
                params = [country]
                
                if target_type and target_type != 'All Types':
                    query += " AND tc.target_type = %s"
                    params.append(target_type)
                    
                if target_name and target_name != 'All Targets':
                    query += " AND sq.target_name = %s"
                    params.append(target_name)
                
                query += """
                    GROUP BY sq.target_name, sq.image_date, tc.target_type
                    ORDER BY sq.target_name, sq.image_date
                """
                
                cur.execute(query, params)
                rows = cur.fetchall()
                
        # Format data for timeline chart
        timeline_data = {}
        for row in rows:
            target_name = row['target_name']
            if target_name not in timeline_data:
                timeline_data[target_name] = {
                    'target_name': target_name,
                    'target_type': row['target_type'],
                    'data_points': []
                }
            
            timeline_data[target_name]['data_points'].append({
                'date': row['image_date'].isoformat() if row['image_date'] else None,
                'count': row['detection_count']
            })
        
        return jsonify(list(timeline_data.values()))
        
    except Exception as e:
        app.logger.error(f"Historical timeline query failed: {e}")
        return jsonify([])

# ==================== COMPREHENSIVE HEALTH CHECK ENDPOINT =====================
@app.route('/health')
def health_check():
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'version': '1.0.0-rc.3'
    }
    
    # Check database connectivity
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT 1')
        health_status['database'] = 'connected'
    except Exception as e:
        health_status['database'] = 'disconnected'
        health_status['status'] = 'unhealthy'
        health_status['database_error'] = str(e)

    # Add directory counting function
    def count_image_id_directories(directory):
        """Count the number of image_id directories (layers) in tiles directory"""
        try:
            if not os.path.exists(directory):
                return 0
            # Count only immediate subdirectories (image_id folders)
            items = os.listdir(directory)
            dir_count = sum(1 for item in items if os.path.isdir(os.path.join(directory, item)))
            return dir_count
        except OSError:
            return 0
    
    # Add recursive file counting function (keep for other directories)
    def count_recursive_files(directory, extension):
        count = 0
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith(extension):
                    count += 1
        return count
    
    # Check essential directories
    essential_dirs = {
        'reports_dir': app.config['REPORTS_DIR'],
        'cogs_dir': 'public/cogs',
        'tiles_dir': 'public/tiles'
    }
    
    for dir_name, dir_path in essential_dirs.items():
        if os.path.exists(dir_path) and os.path.isdir(dir_path):
            health_status[dir_name] = 'exists'
            try:
                if dir_name == 'tiles_dir':
                    # Count image_id directories instead of PNG files
                    layer_count = count_image_id_directories(dir_path)
                    health_status[f'{dir_name}_layer_count'] = layer_count
                    # Optional: also count total tiles for debugging
                    tile_count = count_recursive_files(dir_path, '.png')
                    health_status[f'{dir_name}_tile_count'] = tile_count
                else:
                    file_count = len([f for f in os.listdir(dir_path) if os.path.isfile(os.path.join(dir_path, f))])
                    health_status[f'{dir_name}_file_count'] = file_count
            except OSError:
                health_status[f'{dir_name}_file_count'] = 'unaccessible'
        else:
            health_status[dir_name] = 'missing'
            health_status['status'] = 'degraded'
    
    status_code = 200 if health_status['status'] == 'healthy' else 503
    return jsonify(health_status), status_code

@app.route('/api/data/<image_id>')
def get_geospatial_data(image_id):
    # ... existing geospatial data endpoint unchanged ...
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        f.id,
                        f.target_class,
                        f.score,
                        ST_AsGeoJSON(f.target_geom) AS geometry,
                        ST_X(ST_Centroid(f.target_geom)) AS centroid_lon,
                        ST_Y(ST_Centroid(f.target_geom)) AS centroid_lat
                    FROM findings f
                    WHERE f.image_id = %s
                """, (image_id,))
                rows = cur.fetchall()

        if not rows:
            return jsonify({
                "type": "FeatureCollection",
                "features": []
            })

        features = []
        for row in rows:
            if row["geometry"]:
                geometry_data = json.loads(row["geometry"])
            else:
                geometry_data = {
                    "type": "Point", 
                    "coordinates": [
                        row["centroid_lon"] or 8.55, 
                        row["centroid_lat"] or 50.04
                    ]
                }
            
            features.append({
                "type": "Feature",
                "geometry": geometry_data,
                "properties": {
                    "id": row["id"],
                    "target_class": row["target_class"],
                    "score": float(row["score"]) if row["score"] is not None else None,
                    "centroid": [
                        float(row["centroid_lon"]) if row["centroid_lon"] is not None else 8.55,
                        float(row["centroid_lat"]) if row["centroid_lat"] is not None else 50.04
                    ]
                }
            })

        return jsonify({
            "type": "FeatureCollection",
            "features": features
        })
    except Exception as e:
        app.logger.error(f"Failed to fetch data for image_id={image_id}: {e}")
        return jsonify({"error": "Failed to retrieve geospatial data"}), 500

@app.route('/api/charts/<image_id>/target_class')
def get_target_class_counts(image_id):
    # ... existing chart endpoint unchanged ...
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
        
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        target_class,
                        total_count
                    FROM comprehensive_query
                    WHERE image_id = %s
                """, (image_id,))
                rows = cur.fetchall()
                
        if not rows:
            with get_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        SELECT 
                            target_class,
                            COUNT(*) as total_count
                        FROM findings 
                        WHERE image_id = %s
                        GROUP BY target_class
                    """, (image_id,))
                    rows = cur.fetchall()

        if not rows:
            return jsonify([])

        return jsonify([
            {
                "label": r["target_class"],
                "value": r["total_count"]
            }
            for r in rows
        ])
    except Exception as e:
        app.logger.error(f"Chart query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to generate chart data"}), 500

# ... remaining endpoints unchanged (reports, assets, cogs, frontend serving) ...

@app.route('/api/reports')
def list_reports():
    try:
        files = [f for f in os.listdir(app.config['REPORTS_DIR']) if f.endswith('.txt')]
        return jsonify(sorted(files))
    except Exception as e:
        app.logger.error(f"Failed to list reports: {e}")
        return jsonify({"error": "Cannot list reports"}), 500

@app.route('/api/reports/<filename>')
def get_report(filename):
    if not filename.endswith('.txt'):
        return jsonify({"error": "Only .txt reports are allowed"}), 400
    try:
        return send_from_directory(app.config['REPORTS_DIR'], filename, mimetype='text/plain')
    except FileNotFoundError:
        return jsonify({"error": "Report not found"}), 404
    
# ==================== NEW PAGE ROUTES ====================

@app.route('/api')
def api_documentation_page():
    """Serve the API documentation page"""
    return send_from_directory('.', 'api-docs.html')

@app.route('/health-page')
def health_page():
    """Serve the modern health status page"""
    return send_from_directory('.', 'health.html')

@app.route('/basemap')
def basemap_page():
    """Serve the basemap viewer page"""
    return send_from_directory('.', 'basemap.html')

@app.route('/historical-deployment')  
def historical_deployment_page():
    """Serve the historical deployment analysis page"""
    return send_from_directory('.', 'historical.html')

# ==================== NEW API ENDPOINT ====================

@app.route('/api/historical-data')
def get_historical_data():
    """Time series data for historical deployment analysis"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        image_date,
                        target_class,
                        COUNT(*) as total_count
                    FROM findings
                    GROUP BY image_date, target_class
                    ORDER BY image_date, total_count DESC
                """)
                rows = cur.fetchall()
        
        # Format the data for time series
        formatted_data = []
        for row in rows:
            formatted_data.append({
                'date': row['image_date'].isoformat() if row['image_date'] else None,
                'target_class': row['target_class'],
                'total_count': row['total_count']
            })
            
        return jsonify(formatted_data)
        
    except Exception as e:
        app.logger.error(f"Historical data query failed: {e}")
        return jsonify({"error": "Failed to retrieve historical data"}), 500

@app.route('/assets/<path:filename>')
def serve_assets(filename):
    return send_from_directory('dist/assets', filename)

@app.route('/cogs/<filename>')
def serve_cog(filename):
    if not filename.endswith(('.tiff', '.tif')):
        return jsonify({"error": "Invalid file type"}), 400
    return send_from_directory('public/cogs', filename, mimetype='image/tiff')

@app.route('/')
@app.route('/<path:path>')
def serve_frontend(path='index.html'):
    if os.path.exists(f"dist/{path}"):
        return send_from_directory('dist', path)
    else:
        return send_from_directory('dist', 'index.html')

# ==================== LIST ALL ENDPOINTS ====================

@app.route('/api-list')
def list_endpoints():
    endpoints = []
    for rule in app.url_map.iter_rules():
        endpoints.append({
            "endpoint": rule.endpoint,
            "methods": list(rule.methods),
            "path": str(rule)
        })
    return jsonify(endpoints)

# ==================== ERROR HANDLING ====================

@app.errorhandler(500)
def handle_internal_error(e):
    app.logger.error(f"Internal error: {str(e)}")
    return jsonify({"error": "Internal server error"}), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found"}), 404

@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY' 
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    app.run(host='127.0.0.1', port=5000, debug=True)