Looking at your historical page implementation, I can identify several critical issues that are preventing it from working properly. Let me break down the problems and provide fixes:

## 🔴 Critical Issues Found:

### 1. **Frontend-Backend API Mismatch**
- Frontend expects: `/api/target-classes` and `/api/image-dates/{target_class}`
- Backend provides: `/api/target-types/{country}` and `/api/image-ids/{country}/{target_name}`
- **Complete mismatch in parameter structure**

### 2. **Missing DOM Elements in HTML**
- JavaScript looks for `historicalTargetClass` and `historicalImageDate` elements
- HTML has `historicalCountry` and `historicalTarget` instead
- **DOM selectors don't match**

### 3. **Broken Historical Timeline Query**
- Backend query uses `comprehensive_query` but expects `target_class` column that doesn't exist
- Frontend sends parameters that backend doesn't use correctly

## ✅ Fixes Needed:

### **Fix 1: Update Backend Historical Endpoints**

Replace your historical endpoints in `app.py` with:

```python
# ==================== HISTORICAL DEPLOYMENT ENDPOINTS ====================
@app.route('/api/historical-countries')
def get_historical_countries():
    """Get distinct countries for historical analysis"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT country_name 
                    FROM sql_scat_query2 
                    WHERE country_name IS NOT NULL 
                    ORDER BY country_name
                """)
                countries = [row['country_name'] for row in cur.fetchall()]
        return jsonify(countries)
    except Exception as e:
        app.logger.error(f"Historical countries query failed: {e}")
        return jsonify([])

@app.route('/api/historical-targets/<country>')
def get_historical_targets(country):
    """Get distinct target names for a country"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT target_name 
                    FROM sql_scat_query2 
                    WHERE country_name = %s 
                    AND target_name IS NOT NULL 
                    ORDER BY target_name
                """, (country,))
                targets = [row['target_name'] for row in cur.fetchall()]
        return jsonify(targets)
    except Exception as e:
        app.logger.error(f"Historical targets query failed for {country}: {e}")
        return jsonify([])

# ==================== HISTORICAL TIMELINE - FIXED ====================
@app.route('/api/historical-timeline')
def get_historical_timeline():
    country = request.args.get('country')
    target_name = request.args.get('target_name')
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    
    if not country or not target_name:
        return jsonify({"error": "Country and target name are required"}), 400
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # FIXED: Use sql_scat_query2 which has the actual data
                query = """
                    SELECT 
                        target_name,
                        image_date,
                        target_class,
                        COUNT(*) as detection_count
                    FROM sql_scat_query2
                    WHERE country_name = %s
                    AND target_name = %s
                """
                params = [country, target_name]
                
                # Add date filter if provided
                if from_date and to_date:
                    query += " AND image_date >= %s AND image_date <= %s"
                    params.extend([from_date, to_date])
                
                query += """
                    GROUP BY target_name, target_class, image_date
                    ORDER BY image_date
                """
                
                cur.execute(query, params)
                rows = cur.fetchall()
                
                # Format data for frontend
                timeline_data = {}
                for row in rows:
                    key = f"{row['target_name']}_{row['target_class']}"
                    if key not in timeline_data:
                        timeline_data[key] = {
                            'target_name': row['target_name'],
                            'target_class': row['target_class'],
                            'data_points': []
                        }
                    timeline_data[key]['data_points'].append({
                        'date': row['image_date'].isoformat() if row['image_date'] else None,
                        'count': row['detection_count']
                    })
                
                return jsonify(list(timeline_data.values()))
                
    except Exception as e:
        app.logger.error(f"Historical timeline query failed: {e}")
        return jsonify({"error": "Failed to retrieve historical data"}), 500
```

### **Fix 2: Update Frontend JavaScript**

Replace your `historical.js` with this fixed version:

```javascript
// src/historical.js - FIXED VERSION
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

const API_BASE = "/api";
let timelineChart = null;
let currentSelections = {
    country: null,
    targetName: null,
    fromDate: '2020-01-01',
    toDate: new Date().toISOString().split('T')[0]
};

// Main initialization
async function initializeHistoricalPage() {
    console.log("📊 Initializing Historical Page...");
    
    // Initialize chart first
    initializeTimelineChart();
    
    // Load countries
    await loadCountries();
    
    // Set up event handlers
    setupEventHandlers();
    
    // Set default dates
    document.getElementById('fromDate').value = currentSelections.fromDate;
    document.getElementById('toDate').value = currentSelections.toDate;
    
    updateStatus("Select country and target to view historical timeline");
}

function setupEventHandlers() {
    // Country selection
    const countrySelect = document.getElementById('historicalCountry');
    if (countrySelect) {
        countrySelect.addEventListener('change', async (e) => {
            currentSelections.country = e.target.value;
            if (currentSelections.country) {
                await loadTargets(currentSelections.country);
                updateStatus(`Country: ${currentSelections.country} - Select target`);
            } else {
                clearTargets();
                clearChart();
            }
        });
    }

    // Target selection
    const targetSelect = document.getElementById('historicalTarget');
    if (targetSelect) {
        targetSelect.addEventListener('change', async (e) => {
            currentSelections.targetName = e.target.value;
            if (currentSelections.targetName && currentSelections.country) {
                await loadHistoricalData();
            } else {
                clearChart();
            }
        });
    }

    // Date filters
    const applyFilter = document.getElementById('applyFilter');
    if (applyFilter) {
        applyFilter.addEventListener('click', async () => {
            currentSelections.fromDate = document.getElementById('fromDate').value;
            currentSelections.toDate = document.getElementById('toDate').value;
            if (currentSelections.country && currentSelections.targetName) {
                await loadHistoricalData();
            }
        });
    }

    const resetFilter = document.getElementById('resetFilter');
    if (resetFilter) {
        resetFilter.addEventListener('click', () => {
            document.getElementById('fromDate').value = '2020-01-01';
            document.getElementById('toDate').value = new Date().toISOString().split('T')[0];
            currentSelections.fromDate = '2020-01-01';
            currentSelections.toDate = new Date().toISOString().split('T')[0];
            if (currentSelections.country && currentSelections.targetName) {
                loadHistoricalData();
            }
        });
    }
}

// Chart initialization
function initializeTimelineChart() {
    const timelineCanvas = document.getElementById('timelineChart');
    if (!timelineCanvas) {
        console.error("Timeline chart canvas not found");
        return;
    }

    timelineChart = new Chart(timelineCanvas, {
        type: 'line',
        data: {
            datasets: []
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Historical Deployment Timeline',
                    font: { size: 16, weight: 'bold' }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Detections: ${context.raw.y}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'month',
                        tooltipFormat: 'MMM yyyy'
                    },
                    title: {
                        display: true,
                        text: 'Date'
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Detections'
                    }
                }
            }
        }
    });
}

// Data loading functions
async function loadCountries() {
    try {
        const response = await fetch(`${API_BASE}/historical-countries`);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const countries = await response.json();
        
        const countrySelect = document.getElementById('historicalCountry');
        if (countrySelect) {
            countrySelect.innerHTML = '<option value="">Select Country</option>';
            countries.forEach(country => {
                const option = document.createElement('option');
                option.value = country;
                option.textContent = country;
                countrySelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Failed to load countries:', error);
        updateStatus('Error loading countries');
    }
}

async function loadTargets(country) {
    try {
        const response = await fetch(`${API_BASE}/historical-targets/${encodeURIComponent(country)}`);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const targets = await response.json();
        
        const targetSelect = document.getElementById('historicalTarget');
        if (targetSelect) {
            targetSelect.innerHTML = '<option value="">Select Target</option>';
            targetSelect.disabled = false;
            targets.forEach(target => {
                const option = document.createElement('option');
                option.value = target;
                option.textContent = target;
                targetSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Failed to load targets:', error);
        updateStatus('Error loading targets');
    }
}

async function loadHistoricalData() {
    if (!currentSelections.country || !currentSelections.targetName) {
        updateStatus('Please select both country and target');
        return;
    }

    try {
        showLoading(true);
        updateStatus(`Loading historical data for ${currentSelections.targetName}...`);

        const params = new URLSearchParams({
            country: currentSelections.country,
            target_name: currentSelections.targetName
        });

        if (currentSelections.fromDate) params.append('from_date', currentSelections.fromDate);
        if (currentSelections.toDate) params.append('to_date', currentSelections.toDate);

        const response = await fetch(`${API_BASE}/historical-timeline?${params}`);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        
        const timelineData = await response.json();
        updateTimelineChart(timelineData);
        
    } catch (error) {
        console.error('Failed to load historical data:', error);
        updateStatus('Error loading historical data');
        clearChart();
    } finally {
        showLoading(false);
    }
}

function updateTimelineChart(timelineData) {
    if (!timelineChart) return;

    if (!timelineData || timelineData.length === 0) {
        updateStatus('No historical data found for selected filters');
        timelineChart.data.datasets = [];
        timelineChart.update();
        return;
    }

    // Create datasets for each target_class
    const datasets = timelineData.map(item => {
        const dataPoints = item.data_points.map(point => ({
            x: new Date(point.date),
            y: point.count
        })).sort((a, b) => a.x - b.x);

        return {
            label: `${item.target_name} - ${item.target_class}`,
            data: dataPoints,
            borderColor: getRandomColor(),
            backgroundColor: 'rgba(99, 102, 241, 0.1)',
            borderWidth: 2,
            fill: false,
            tension: 0.4
        };
    });

    timelineChart.data.datasets = datasets;
    timelineChart.update();

    const totalPoints = timelineData.reduce((sum, item) => sum + item.data_points.length, 0);
    updateStatus(`Showing ${totalPoints} data points for ${currentSelections.targetName}`);
}

// Helper functions
function clearTargets() {
    const targetSelect = document.getElementById('historicalTarget');
    if (targetSelect) {
        targetSelect.innerHTML = '<option value="">Select Country First</option>';
        targetSelect.disabled = true;
    }
}

function clearChart() {
    if (timelineChart) {
        timelineChart.data.datasets = [];
        timelineChart.update();
    }
}

function updateStatus(message) {
    const statusElement = document.getElementById('historicalStatus');
    if (statusElement) {
        statusElement.textContent = message;
    }
}

function showLoading(show) {
    // You can implement a loading indicator here
    console.log(show ? 'Loading...' : 'Loading complete');
}

function getRandomColor() {
    const colors = [
        '#6366f1', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6',
        '#06b6d4', '#84cc16', '#f97316', '#ec4899', '#14b8a6'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', initializeHistoricalPage);
```

### **Fix 3: Add Chart Canvas to HTML**

Add this to your `historical.html` in the chart container:

```html
<!-- Add this inside the .main-content div, after the status-info -->
<div class="chart-container" id="chartContainer">
    <div class="chart-card">
        <div class="chart-header">
            <h5>Historical Timeline</h5>
        </div>
        <div style="height: 400px; position: relative;">
            <canvas id="timelineChart"></canvas>
            <div id="chartLoading" class="chart-overlay" style="display: none;">
                <div class="spinner"></div>
            </div>
        </div>
    </div>
</div>
```

## 🎯 Summary of Changes:

1. **Fixed API endpoints** - Now use correct database tables and parameters
2. **Fixed frontend-backend alignment** - Parameters now match
3. **Fixed DOM element references** - JavaScript now finds the correct HTML elements
4. **Improved error handling** - Better user feedback
5. **Proper data structure** - Uses `sql_scat_query2` which has the actual detection data

## 🚀 Testing:

After applying these fixes, your historical page should work with this flow:
1. Select Country → Loads targets for that country
2. Select Target → Loads historical timeline data
3. Apply date filters → Updates the chart

The chart will show detection counts over time for the selected target, with different lines for each target class.
