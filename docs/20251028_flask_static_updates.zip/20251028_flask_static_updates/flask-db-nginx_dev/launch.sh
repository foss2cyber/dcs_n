#!/bin/bash

echo "========================================"
echo " Geospatial App Launcher"
echo "========================================"

if [ "$1" = "prod" ]; then
    echo "Starting PRODUCTION mode..."
    
    # Build frontend
    echo "Building frontend..."
    npm run build
    if [ $? -ne 0 ]; then
        echo "❌ Frontend build failed!"
        exit 1
    fi
    
    # Start Flask backend
    echo "Starting Flask server..."
    python app.py &
    FLASK_PID=$!
    
    # Wait and open browser
    sleep 5
    echo "Opening browser..."
    xdg-open "http://localhost:5000" 2>/dev/null || open "http://localhost:5000" 2>/dev/null
    
    echo ""
    echo "✅ Application launched!"
    echo "Backend: http://localhost:5000" 
    echo "Health Check: http://localhost:5000/health"
    echo ""
    echo "Press Ctrl+C to stop the application"
    
    wait $FLASK_PID
    
else
    echo "Starting DEVELOPMENT mode..."
    
    # Start Flask backend
    echo "Starting Flask server..."
    python app.py &
    FLASK_PID=$!
    
    # Start Vite dev server
    echo "Starting Vite dev server..."
    npm run dev &
    VITE_PID=$!
    
    # Wait and open browser
    sleep 5
    echo "Opening browser..."
    xdg-open "http://localhost:5173" 2>/dev/null || open "http://localhost:5173" 2>/dev/null
    
    echo ""
    echo "✅ Application launched!"
    echo "Backend: http://localhost:5000"
    echo "Frontend: http://localhost:5173"
    echo "Health Check: http://localhost:5000/health"
    echo ""
    echo "Press Ctrl+C to stop both servers"
    
    trap "kill $FLASK_PID $VITE_PID; exit" SIGINT SIGTERM
    wait
fi