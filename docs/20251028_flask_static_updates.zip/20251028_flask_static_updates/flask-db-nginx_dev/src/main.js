// src/main.js
import "open-props/open-props.min.css";
import OlMap from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import XYZ from "ol/source/XYZ";
import WebGLTileLayer from "ol/layer/WebGLTile";
import { fromLonLat, toLonLat } from "ol/proj";
import { defaults as defaultInteractions } from "ol/interaction";
import { defaults as defaultControls } from "ol/control";
import ScaleLine from "ol/control/ScaleLine";
import Rotate from "ol/control/Rotate";
import { Style, Stroke, Fill, Circle as CircleStyle } from "ol/style";
import Overlay from "ol/Overlay";
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);
import { marked } from "marked";
import { CONFIG, getAssetUrl } from "./config.js";

let map, vectorSource, barChart;
let cogLayer, xyzLayer;
let currentSelections = {
  country: null,
  targetType: null,
  imageId: null,
};
let currentFilters = {};
let scoreFilterTimeout;
let abortController = new AbortController(); // For canceling in-flight requests

document.addEventListener("DOMContentLoaded", async () => {
  const requiredElements = [
    "countrySelector",
    "targetTypeSelector",
    "imageIdSelector",
    "map",
    "barChart",
    "reportContent",
  ];
  const missingElements = requiredElements.filter(
    (id) => !document.getElementById(id)
  );
  if (missingElements.length > 0) {
    console.error("Missing DOM elements:", missingElements);
    showErrorToUser(`Required elements missing: ${missingElements.join(", ")}`);
    return;
  }

  const countrySelector = document.getElementById("countrySelector");
  const targetTypeSelector = document.getElementById("targetTypeSelector");
  const imageIdSelector = document.getElementById("imageIdSelector");
  const selectionStatus = document.getElementById("selectionStatus");
  const reportContent = document.getElementById("reportContent");
  const barCanvas = document.getElementById("barChart");
  const opacitySlider = document.getElementById("opacitySlider");
  const fitToDataBtn = document.getElementById("fitToData");
  const clearDataBtn = document.getElementById("clearData");
  const scoreRange = document.getElementById("scoreRange");
  const scoreValue = document.getElementById("scoreValue");

  // Validate critical elements exist
  if (!barCanvas) {
    console.error("Bar chart canvas element not found");
    return;
  }

  // TOOLTIP SETUP
  const tooltipElement = document.createElement("div");
  tooltipElement.className = "map-tooltip";
  tooltipElement.setAttribute("role", "tooltip");
  tooltipElement.setAttribute("aria-live", "polite");
  document.body.appendChild(tooltipElement);
  const tooltipOverlay = new Overlay({
    element: tooltipElement,
    positioning: "bottom-center",
    offset: [0, -15],
    stopEvent: false,
  });

  // MAP SETUP
  vectorSource = new VectorSource();
  const vectorLayer = new VectorLayer({
    source: vectorSource,
    style: function (feature) {
      const geom = feature.getGeometry();
      const isHover = feature.get("hover");
      const props = feature.getProperties();
      const styles = [
        new Style({
          stroke: new Stroke({
            color: isHover ? "#ff4444" : "#3388ff",
            width: isHover ? 4 : 3,
          }),
          fill: new Fill({
            color: isHover ? "rgba(255, 68, 68, 0.3)" : "rgba(51, 136, 255, 0)",
          }),
          zIndex: 2,
        }),
      ];

      if (
        geom &&
        (geom.getType() === "Polygon" || geom.getType() === "Point")
      ) {
        try {
          const centroid =
            geom.getType() === "Polygon" ? geom.getInteriorPoint() : geom;
          styles.push(
            new Style({
              geometry: centroid,
              image: new CircleStyle({
                radius: 6,
                fill: new Fill({
                  color: getColorForClass(props.target_class),
                }),
                stroke: new Stroke({
                  color: "white",
                  width: 1.5,
                }),
              }),
              zIndex: 1,
            })
          );
        } catch (e) {
          console.warn("Could not calculate centroid for feature:", e);
        }
      }
      return styles;
    },
  });

  cogLayer = new WebGLTileLayer({
    visible: false,
    opacity: 1,
    source: null,
  });
  xyzLayer = new TileLayer({
    visible: true,
    opacity: 1,
    source: null,
  });

  map = new OlMap({
    target: "map",
    layers: [cogLayer, xyzLayer, vectorLayer],
    view: new View({
      center: fromLonLat([8.55, 50.04]),
      zoom: 12,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" }),
      new Rotate({ autoHide: false }),
    ]),
    interactions: defaultInteractions(),
  });
  map.addOverlay(tooltipOverlay);

  // Ensure map is properly sized
  setTimeout(() => {
    map.updateSize();
  }, 100);

  // TOOLTIP INTERACTION
  let hoverFeature = null;
  map.on("pointermove", function (evt) {
    const feature = map.forEachFeatureAtPixel(evt.pixel, function (feature) {
      return feature;
    });

    if (feature) {
      if (hoverFeature !== feature) {
        if (hoverFeature) {
          hoverFeature.set("hover", false);
        }
        feature.set("hover", true);
        hoverFeature = feature;
        const props = feature.getProperties();
        const coordinates = evt.coordinate;
        const geometry = feature.getGeometry();

        let centroidCoords = [0, 0];
        if (geometry) {
          try {
            if (geometry.getType() === "Polygon") {
              const centroid = geometry.getInteriorPoint();
              centroidCoords = toLonLat(centroid.getCoordinates());
            } else {
              centroidCoords = toLonLat(geometry.getCoordinates());
            }
          } catch (e) {
            console.warn("Error calculating coordinates for tooltip:", e);
          }
        }

        const displayName =
          props.target_name ||
          (props.target_class
            ? `Target_${props.target_class}`
            : "Unknown Target");

        tooltipElement.innerHTML = `
          <div class="tooltip-content">
            <strong>${escapeHtml(displayName)}</strong>
            <div class="tooltip-details">
              <span class="tooltip-label">Class:</span> ${escapeHtml(
                props.target_class || "N/A"
              )}<br/>
              <span class="tooltip-label">Type:</span> ${escapeHtml(
                props.target_type || "N/A"
              )}<br/>
              <span class="tooltip-label">Score:</span> ${
                props.score ? (props.score * 100).toFixed(1) + "%" : "N/A"
              }<br/>
              <span class="tooltip-label">Centroid:</span> ${centroidCoords[0].toFixed(
                6
              )}, ${centroidCoords[1].toFixed(6)}
            </div>
          </div>
        `;
        tooltipOverlay.setPosition(coordinates);
        tooltipElement.style.display = "block";
      }
    } else {
      if (hoverFeature) {
        hoverFeature.set("hover", false);
        hoverFeature = null;
      }
      tooltipElement.style.display = "none";
    }
  });

  // AUTO-LOAD FUNCTIONALITY
  async function autoLoadData() {
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      await loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  }

  function applyDynamicScoreFilter(scorePercent) {
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  }

  async function loadFilterOptions(imageId) {
    if (!imageId) return;

    try {
      const params = new URLSearchParams();
      if (currentSelections.country) {
        params.append("country", currentSelections.country);
      }
      if (currentSelections.targetType) {
        params.append("target_name", currentSelections.targetType);
      }

      const res = await fetch(`/api/filter-options/${imageId}?${params}`, {
        signal: abortController.signal,
      });
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

      const options = await res.json();

      // Update class filter
      const classFilter = document.getElementById("classFilter");
      if (classFilter) {
        const currentClassValue = classFilter.value;
        classFilter.innerHTML =
          '<option value="">All Classes</option>' +
          (options.target_classes && Array.isArray(options.target_classes)
            ? options.target_classes
                .map(
                  (cls) =>
                    `<option value="${escapeHtml(cls)}">${escapeHtml(
                      cls
                    )}</option>`
                )
                .join("")
            : "");
        if (
          currentClassValue &&
          options.target_classes.includes(currentClassValue)
        ) {
          classFilter.value = currentClassValue;
        }
      }

      // Update name filter
      const nameFilter = document.getElementById("nameFilter");
      if (nameFilter) {
        const currentNameValue = nameFilter.value;
        nameFilter.innerHTML =
          '<option value="">All Names</option>' +
          (options.target_names && Array.isArray(options.target_names)
            ? options.target_names
                .map(
                  (name) =>
                    `<option value="${escapeHtml(name)}">${escapeHtml(
                      name
                    )}</option>`
                )
                .join("")
            : "");
        if (
          currentNameValue &&
          options.target_names.includes(currentNameValue)
        ) {
          nameFilter.value = currentNameValue;
        }
      }

      // Update score range
      if (scoreRange && scoreValue && options.score_range) {
        const minScorePercent = (options.score_range.min || 0) * 100;
        const maxScorePercent = (options.score_range.max || 1) * 100;
        scoreRange.min = 0;
        scoreRange.max = 100;
        scoreRange.step = 0.1;
        let currentScorePercent = 0;
        if (currentFilters.min_score !== undefined) {
          currentScorePercent = currentFilters.min_score * 100;
        }
        scoreRange.value = currentScorePercent;
        scoreValue.textContent = `${parseFloat(currentScorePercent).toFixed(
          1
        )}%`;
      }

      updateFilterContextDisplay();
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load filter options:", error);
        showErrorToUser("Failed to load filter options");
      }
    }
  }

  function getCurrentFilters() {
    const filters = {};
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");

    if (nameFilter && nameFilter.value) {
      filters.target_name = [nameFilter.value];
    } else if (classFilter && classFilter.value) {
      filters.target_class = [classFilter.value];
    }

    if (scoreRange && parseFloat(scoreRange.value) > 0) {
      filters.min_score = parseFloat(scoreRange.value) / 100;
    }

    return filters;
  }

  function resetFilters() {
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");
    const scoreValue = document.getElementById("scoreValue");

    if (classFilter) classFilter.value = "";
    if (nameFilter) nameFilter.value = "";
    if (scoreRange && scoreValue) {
      scoreRange.value = scoreRange.min;
      scoreValue.textContent = `${parseFloat(scoreRange.min).toFixed(1)}%`;
    }
    updateFilterContextDisplay();
  }

  // HIERARCHICAL DROPDOWN SYSTEM
  async function loadCountries() {
    try {
      showLoadingState("country", "Loading countries...");
      const response = await fetch("/api/countries", {
        signal: abortController.signal,
      });
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const countries = await response.json();
      countrySelector.innerHTML = '<option value="">Select Country</option>';

      if (countries.length > 0) {
        countries.forEach((country) => {
          const option = document.createElement("option");
          option.value = country;
          option.textContent = country;
          countrySelector.appendChild(option);
        });
        updateSelectionStatus("Select a country to continue");
      } else {
        countrySelector.innerHTML =
          '<option value="">No countries available</option>';
        updateSelectionStatus("No countries found in database");
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load countries:", error);
        countrySelector.innerHTML =
          '<option value="">Error loading countries</option>';
        updateSelectionStatus("Error loading countries");
        showErrorToUser("Failed to load countries");
      }
    } finally {
      hideLoadingState("country");
    }
  }

  async function loadTargetTypes(country) {
    if (!country) return;

    try {
      showLoadingState("targetType", "Loading target names...");
      targetTypeSelector.disabled = true;
      imageIdSelector.disabled = true;

      const response = await fetch(
        `/api/target-types/${encodeURIComponent(country)}`,
        { signal: abortController.signal }
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const targetNames = await response.json();
      targetTypeSelector.innerHTML =
        '<option value="">Select Target Name</option>';

      if (targetNames.length > 0) {
        targetNames.forEach((targetName) => {
          const option = document.createElement("option");
          option.value = targetName;
          option.textContent = targetName;
          targetTypeSelector.appendChild(option);
        });
        targetTypeSelector.disabled = false;
        updateSelectionStatus(`Country: ${country} - Select target name`);

        if (currentSelections.imageId) {
          await loadFilterOptions(currentSelections.imageId);
        }
      } else {
        targetTypeSelector.innerHTML =
          '<option value="">No target names available</option>';
        updateSelectionStatus(`No target names found for ${country}`);
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load target names:", error);
        targetTypeSelector.innerHTML =
          '<option value="">Error loading target names</option>';
        updateSelectionStatus("Error loading target names");
      }
    } finally {
      hideLoadingState("targetType");
    }
  }

  async function loadImageIds(country, targetName) {
    if (!country || !targetName) return;

    try {
      showLoadingState("imageId", "Loading image IDs...");
      imageIdSelector.disabled = true;

      const response = await fetch(
        `/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(
          targetName
        )}`,
        { signal: abortController.signal }
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const imageIds = await response.json();
      imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';

      if (imageIds.length > 0) {
        imageIds.forEach((imageId) => {
          const option = document.createElement("option");
          option.value = imageId;
          option.textContent = imageId;
          imageIdSelector.appendChild(option);
        });
        imageIdSelector.disabled = false;
        updateSelectionStatus(
          `Country: ${country}, Name: ${targetName} - Select image ID`
        );
      } else {
        imageIdSelector.innerHTML =
          '<option value="">No images available</option>';
        updateSelectionStatus(
          `No images found for ${targetName} in ${country}`
        );
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load image IDs:", error);
        imageIdSelector.innerHTML =
          '<option value="">Error loading images</option>';
        updateSelectionStatus("Error loading images");
      }
    } finally {
      hideLoadingState("imageId");
    }
  }

  // UNIFIED DATA LOADING
  async function loadUnifiedData(imageId, filters = {}) {
    if (!imageId) return;

    // Cancel any ongoing requests
    abortController.abort();
    abortController = new AbortController();

    try {
      showMainLoading(true);
      updateSelectionStatus(`Loading data for ${imageId}...`);

      const queryParams = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          value.forEach((v) => queryParams.append(key, v));
        } else if (value) {
          queryParams.append(key, value);
        }
      });

      const url = `/api/unified-data/${imageId}?${queryParams}`;
      const response = await fetch(url, {
        signal: abortController.signal,
      });

      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const unifiedData = await response.json();

      // Load data in parallel for better performance
      await Promise.all([
        loadVectorData(unifiedData.vector_data),
        loadChartData(unifiedData.chart_data),
        loadReportData(imageId),
        updateRasterLayers(imageId),
      ]);

      await loadFilterOptions(imageId);
      updateSelectionStatus(`Data loaded: ${imageId}`);

      if (fitToDataBtn) fitToDataBtn.disabled = false;
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load unified data:", error);
        updateSelectionStatus("Error loading data");
        if (reportContent) {
          reportContent.innerHTML =
            '<div class="error-message">Failed to load data. Please try again.</div>';
        }
        showErrorToUser("Failed to load data");
      }
    } finally {
      showMainLoading(false);
    }
  }

  async function loadVectorData(vectorData) {
    vectorSource.clear();

    if (vectorData && vectorData.features && vectorData.features.length > 0) {
      try {
        const features = new GeoJSON().readFeatures(vectorData, {
          featureProjection: "EPSG:3857",
        });
        vectorSource.addFeatures(features);

        // Fit view to features
        map.getView().fit(vectorSource.getExtent(), {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 1000,
        });

        console.log(`✅ Loaded ${features.length} vector features`);
      } catch (error) {
        console.error("Error reading vector features:", error);
        showErrorToUser("Error loading map data");
      }
    } else {
      console.log("ℹ️ No vector features found");
      // Don't change the view if no features
    }
  }

  async function loadChartData(chartData) {
    // Destroy existing chart
    if (barChart) {
      barChart.destroy();
      barChart = null;
    }

    if (!chartData || chartData.length === 0) {
      console.log("ℹ️ No chart data available");
      barCanvas.innerHTML =
        '<div class="no-data-message">No chart data available</div>';
      return;
    }

    try {
      const accessibleColors = [
        "#3366CC",
        "#DC3912",
        "#FF9900",
        "#109618",
        "#990099",
        "#0099C6",
        "#DD4477",
        "#66AA00",
        "#B82E2E",
        "#316395",
      ];

      // FIXED: Added the missing 'data' property key
      barChart = new Chart(barCanvas, {
        type: "bar",
        data: {
          // This was missing - added the 'data' property
          labels: chartData.map(
            (d) => d.target_name || d.target_class || "Unknown Target"
          ),
          datasets: [
            {
              label: "Total Count",
              data: chartData.map((d) => d.total_count), // Fixed missing data array
              backgroundColor: chartData.map(
                (d, i) => accessibleColors[i % accessibleColors.length]
              ),
              borderColor: chartData.map(
                (d, i) => accessibleColors[i % accessibleColors.length]
              ),
              borderWidth: 1,
              barThickness: 30,
              maxBarThickness: 50,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                title: function (context) {
                  const dataPoint = chartData[context[0].dataIndex];
                  return (
                    dataPoint.target_name ||
                    dataPoint.target_class ||
                    "Unknown Target"
                  );
                },
                label: function (context) {
                  const dataPoint = chartData[context.dataIndex];
                  return [
                    `Class: ${dataPoint.target_class || "N/A"}`,
                    `Type: ${dataPoint.target_type || "N/A"}`,
                    `Total Count: ${context.parsed.y}`,
                    `Avg Score: ${
                      dataPoint.avg_score
                        ? (dataPoint.avg_score * 100).toFixed(1) + "%"
                        : "N/A"
                    }`,
                  ];
                },
              },
            },
          },
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: "Total Count",
                font: { size: 12, weight: "bold" },
              },
            },
            x: {
              title: {
                display: true,
                text: "Target Name",
                font: { size: 12, weight: "bold" },
              },
            },
          },
        },
      });

      console.log("✅ Chart loaded with", chartData.length, "data points");
    } catch (error) {
      console.error("Error creating chart:", error);
      barCanvas.innerHTML =
        '<div class="error-message">Error loading chart</div>';
    }
  }

  // RASTER LAYER MANAGEMENT
  async function updateRasterLayers(imageId) {
    console.log(`🔄 Updating raster layers for: ${imageId}`);

    try {
      const xyzSource = new XYZ({
        url: `${getAssetUrl(`tiles/${imageId}/{z}/{x}/{y}.png`)}`,
        crossOrigin: "anonymous",
        transition: 250,
        minZoom: 12,
        maxZoom: 20,
      });

      xyzLayer.setSource(xyzSource);
      xyzLayer.setVisible(true);

      if (opacitySlider) {
        xyzLayer.setOpacity(parseFloat(opacitySlider.value || 1));
      }
    } catch (error) {
      console.error("Error updating raster layers:", error);
    }
  }

  // REPORT LOADING WITH ASSET SERVER FALLBACK
  async function loadReportData(imageId) {
    try {
      showReportLoading(true);
      const reportUrl = `${getAssetUrl(`reports/${imageId}.txt`)}`;
      const res = await fetch(reportUrl, {
        signal: abortController.signal,
      });

      if (!res.ok) throw new Error("Report not found");

      const reportText = await res.text();
      if (reportContent) {
        reportContent.innerHTML = await marked.parse(reportText);
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load report from asset server:", error);
        try {
          const localRes = await fetch(`/api/reports/${imageId}.txt`, {
            signal: abortController.signal,
          });
          if (localRes.ok) {
            const localReportText = await localRes.text();
            if (reportContent) {
              reportContent.innerHTML = await marked.parse(localReportText);
            }
            return;
          }
        } catch (fallbackError) {
          if (fallbackError.name !== "AbortError") {
            if (reportContent) {
              reportContent.innerHTML =
                '<div class="error-message">Report not available for this image.</div>';
            }
          }
        }
      }
    } finally {
      showReportLoading(false);
    }
  }

  function updateFilterContextDisplay() {
    const contextElement = document.querySelector(".filter-context");
    if (!contextElement) {
      const filterSection = document.querySelector(".filter-section");
      if (filterSection) {
        const newContextElement = document.createElement("div");
        newContextElement.className = "filter-context";
        filterSection.insertBefore(newContextElement, filterSection.firstChild);
      }
      return;
    }

    let contextText = "";
    if (currentSelections.country && currentSelections.targetType) {
      contextText = `Filtering: ${currentSelections.country} → ${currentSelections.targetType}`;
    } else if (currentSelections.country) {
      contextText = `Filtering: ${currentSelections.country}`;
    } else {
      contextText = "No context - showing all data";
    }

    contextElement.innerHTML = `
      <span>Context:</span>
      <span class="context-value">${escapeHtml(contextText)}</span>
    `;
  }

  // UI STATE MANAGEMENT
  function updateSelectionStatus(message) {
    if (selectionStatus) {
      selectionStatus.textContent = message;
      selectionStatus.title = message;
      selectionStatus.setAttribute("aria-live", "polite");
    }
  }

  function showLoadingState(selectorType, message) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = true;
      selector.innerHTML = `<option value="">${message}</option>`;
    }
  }

  function hideLoadingState(selectorType) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = false;
    }
  }

  function showMainLoading(show) {
    const mapLoading = document.getElementById("mapLoading");
    const chartLoading = document.getElementById("chartLoading");
    if (mapLoading) mapLoading.style.display = show ? "flex" : "none";
    if (chartLoading) chartLoading.style.display = show ? "flex" : "none";
  }

  function showReportLoading(show) {
    const reportLoading = document.getElementById("reportLoading");
    if (reportLoading) reportLoading.style.display = show ? "flex" : "none";
  }

  function showErrorToUser(message) {
    // You could implement a toast notification system here
    console.error("User-facing error:", message);
    // Simple alert for now - consider a better UI in production
    alert(`Error: ${message}`);
  }

  function clearAllData() {
    // Cancel any ongoing requests
    abortController.abort();
    abortController = new AbortController();

    currentSelections = { country: null, targetType: null, imageId: null };
    currentFilters = {};
    countrySelector.value = "";
    targetTypeSelector.innerHTML =
      '<option value="">Select Country First</option>';
    targetTypeSelector.disabled = true;
    imageIdSelector.innerHTML =
      '<option value="">Select Target Type First</option>';
    imageIdSelector.disabled = true;
    vectorSource.clear();

    if (barChart) {
      barChart.destroy();
      barChart = null;
    }

    if (reportContent) {
      reportContent.innerHTML = `
        <div class="report-placeholder">
          <div class="placeholder-icon">📊</div>
          <p>Select a country, target type, and image ID to view the analysis report.</p>
        </div>
      `;
    }

    // Clear raster layers
    xyzLayer.setSource(null);
    cogLayer.setSource(null);

    map.getView().setCenter(fromLonLat([8.55, 50.04]));
    map.getView().setZoom(12);
    resetFilters();

    if (fitToDataBtn) fitToDataBtn.disabled = true;
    updateSelectionStatus("Ready to load data");
  }

  function getColorForClass(targetClass) {
    const colorMap = {
      "FR-AF-CGAA-1": "#3366CC",
      "FR-AP-CGSV-1": "#DC3912",
      "FR-AF-CPA-2": "#FF9900",
      "FR-AF-CCTA-3": "#109618",
      "FR-AF-CCA-4": "#990099",
      "FR-AP-CMV-2": "#0099C6",
    };
    return colorMap[targetClass] || "#666666";
  }

  // Utility function to escape HTML
  function escapeHtml(unsafe) {
    if (typeof unsafe !== "string") return unsafe;
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // EVENT HANDLERS
  countrySelector.addEventListener("change", async (e) => {
    const country = e.target.value;
    currentSelections.country = country;
    currentSelections.targetType = null;
    currentSelections.imageId = null;
    targetTypeSelector.innerHTML =
      '<option value="">Select Target Name</option>';
    targetTypeSelector.disabled = !country;
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = true;
    resetFilters();

    if (country) {
      await loadTargetTypes(country);
    } else {
      updateSelectionStatus("Select a country to continue");
    }
  });

  targetTypeSelector.addEventListener("change", async (e) => {
    const targetName = e.target.value;
    currentSelections.targetType = targetName;
    currentSelections.imageId = null;
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = !targetName;
    resetFilters();

    if (targetName && currentSelections.country) {
      await loadImageIds(currentSelections.country, targetName);
    }
  });

  imageIdSelector.addEventListener("change", async (e) => {
    currentSelections.imageId = e.target.value;
    if (currentSelections.imageId) {
      await loadFilterOptions(currentSelections.imageId);
      await autoLoadData();
    }
  });

  if (scoreRange && scoreValue) {
    scoreRange.addEventListener("input", function () {
      const scorePercent = parseFloat(this.value);
      scoreValue.textContent = `${scorePercent.toFixed(1)}%`;
      clearTimeout(scoreFilterTimeout);
      scoreFilterTimeout = setTimeout(() => {
        applyDynamicScoreFilter(scorePercent);
      }, 150);
    });
  }

  if (fitToDataBtn) {
    fitToDataBtn.addEventListener("click", () => {
      if (vectorSource.getFeatures().length > 0) {
        map.getView().fit(vectorSource.getExtent(), {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 1000,
        });
      }
    });
  }

  if (clearDataBtn) {
    clearDataBtn.addEventListener("click", clearAllData);
  }

  if (opacitySlider) {
    opacitySlider.addEventListener("input", () => {
      const opacity = parseFloat(opacitySlider.value);
      cogLayer.setOpacity(opacity);
      xyzLayer.setOpacity(opacity);
    });
  }

  // Clean up on page unload
  window.addEventListener("beforeunload", () => {
    abortController.abort();
    if (barChart) {
      barChart.destroy();
    }
  });

  // INITIALIZATION
  await loadCountries();
});
