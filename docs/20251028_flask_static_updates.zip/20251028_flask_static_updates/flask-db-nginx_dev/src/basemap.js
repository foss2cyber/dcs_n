// src/basemap.js - CORRECT VERSION
import OlMap from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import XYZ from "ol/source/XYZ";
import { fromLonLat, toLonLat } from "ol/proj"; // FIXED: Added toLonLat
import { defaults as defaultControls } from "ol/control";
import ScaleLine from "ol/control/ScaleLine";
import Rotate from "ol/control/Rotate";
import { Style, Stroke, Fill, Circle as CircleStyle } from "ol/style";
import Overlay from "ol/Overlay";
import { CONFIG, getAssetUrl } from "./config.js";

let map;
let vectorSource, vectorLayer;
let imageryLayer;
let detectionSource, detectionLayer;
let tooltipElement, tooltipOverlay;

document.addEventListener("DOMContentLoaded", async function () {
  initializeMap();
  setupTooltip();
  await setupBasemapPage();
  await loadLocalBasemap();
});

function setupTooltip() {
  tooltipElement = document.createElement("div");
  tooltipElement.className = "map-tooltip";
  document.body.appendChild(tooltipElement);

  tooltipOverlay = new Overlay({
    element: tooltipElement,
    positioning: "bottom-center",
    offset: [0, -15],
    stopEvent: false,
  });
}

function initializeMap() {
  vectorSource = new VectorSource();
  vectorLayer = new VectorLayer({
    source: vectorSource,
    style: new Style({
      stroke: new Stroke({ color: "#3388ff", width: 2 }),
      fill: new Fill({ color: "rgba(51, 136, 255, 0.1)" }),
    }),
    zIndex: 1,
  });

  detectionSource = new VectorSource();
  detectionLayer = new VectorLayer({
    source: detectionSource,
    style: function (feature) {
      const props = feature.getProperties();
      const isHover = feature.get("hover");
      return new Style({
        image: new CircleStyle({
          radius: isHover ? 8 : 6,
          fill: new Fill({ color: "#ff4444" }),
          stroke: new Stroke({ color: "white", width: isHover ? 2 : 1.5 }),
        }),
        zIndex: 3,
      });
    },
  });

  imageryLayer = new TileLayer({
    source: null,
    visible: true,
    zIndex: 0,
  });

  map = new OlMap({
    target: "basemap",
    layers: [imageryLayer, vectorLayer, detectionLayer],
    view: new View({
      center: fromLonLat([0, 0]),
      zoom: 2,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" }),
      new Rotate({ autoHide: false }),
    ]),
  });

  map.addOverlay(tooltipOverlay);

  let hoverFeature = null;
  map.on("pointermove", function (evt) {
    const feature = map.forEachFeatureAtPixel(evt.pixel, (f) => f, {
      layerFilter: (layer) => layer === detectionLayer,
    });

    if (feature) {
      if (hoverFeature !== feature) {
        if (hoverFeature) hoverFeature.set("hover", false);
        feature.set("hover", true);
        hoverFeature = feature;

        const props = feature.getProperties();
        const coords = evt.coordinate;
        const geometry = feature.getGeometry();
        let centroidCoords = [0, 0];

        if (geometry.getType() === "Polygon") {
          const centroid = geometry.getInteriorPoint();
          centroidCoords = toLonLat(centroid.getCoordinates());
        } else {
          centroidCoords = toLonLat(geometry.getCoordinates());
        }

        tooltipElement.innerHTML = `
          <div class="tooltip-content">
            <strong>${props.target_name || "Unknown Target"}</strong>
            <div class="tooltip-details">
              <span class="tooltip-label">Class:</span> ${
                props.target_class || "N/A"
              }<br/>
              <span class="tooltip-label">Type:</span> ${
                props.target_type || "N/A"
              }<br/>
              <span class="tooltip-label">Score:</span> ${
                props.score ? (props.score * 100).toFixed(1) + "%" : "N/A"
              }<br/>
              <span class="tooltip-label">Centroid:</span> ${centroidCoords[0].toFixed(
                6
              )}, ${centroidCoords[1].toFixed(6)}
            </div>
          </div>
        `;
        tooltipOverlay.setPosition(coords);
        tooltipElement.style.display = "block";
      }
    } else {
      if (hoverFeature) {
        hoverFeature.set("hover", false);
        hoverFeature = null;
      }
      tooltipElement.style.display = "none";
    }
  });
}

async function loadLocalBasemap() {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById("basemapStatus").textContent =
      "Loading vector basemap...";

    const response = await fetch("/api/local-basemap");
    const geojsonData = await response.json();

    const features = new GeoJSON().readFeatures(geojsonData, {
      featureProjection: "EPSG:3857",
    });

    vectorSource.clear();
    vectorSource.addFeatures(features);

    if (features.length > 0) {
      map.getView().fit(vectorSource.getExtent(), {
        padding: [50, 50, 50, 50],
        maxZoom: 16,
        duration: 1000,
      });
    }

    document.getElementById(
      "basemapStatus"
    ).textContent = `Basemap loaded with ${features.length.toLocaleString()} features`;
    document.getElementById("basemapFit").disabled = false;
  } catch (error) {
    console.error("Failed to load local basemap:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading basemap";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

async function setupBasemapPage() {
  await loadBasemapCountries();

  document
    .getElementById("basemapCountry")
    .addEventListener("change", async function (e) {
      const country = e.target.value;
      await loadBasemapTargets(country);

      if (country) {
        document.getElementById("basemapTarget").disabled = false;
        document.getElementById(
          "basemapStatus"
        ).textContent = `Country: ${country} - Select target`;
      } else {
        document.getElementById("basemapTarget").disabled = true;
        document.getElementById("basemapTarget").innerHTML =
          '<option value="">Select Country First</option>';
        document.getElementById("basemapStatus").textContent =
          "Select country, target, and image to load data";
      }
    });

  document
    .getElementById("basemapTarget")
    .addEventListener("change", async function (e) {
      const target = e.target.value;
      const country = document.getElementById("basemapCountry").value;
      await loadBasemapImages(country, target);

      if (target) {
        document.getElementById("basemapImage").disabled = false;
        document.getElementById(
          "basemapStatus"
        ).textContent = `Country: ${country}, Target: ${target} - Select image`;
      } else {
        document.getElementById("basemapImage").disabled = true;
        document.getElementById("basemapImage").innerHTML =
          '<option value="">Select Target Name First</option>';
      }
    });

  document
    .getElementById("basemapImage")
    .addEventListener("change", async function (e) {
      const imageId = e.target.value;
      if (imageId) {
        await autoLoadBasemapData(imageId);
      }
    });

  document.querySelectorAll('input[name="basemapLayer"]').forEach((radio) => {
    radio.addEventListener("change", function (e) {
      updateLayerVisibility(e.target.value);
      updateLayerButtons(e.target.value);
    });
  });

  document.querySelectorAll(".layer-btn").forEach((btn) => {
    btn.addEventListener("click", function () {
      document
        .querySelectorAll(".layer-btn")
        .forEach((b) => b.classList.remove("active"));
      this.classList.add("active");
      const layerType = this.getAttribute("data-layer");
      updateLayerVisibility(layerType);
      updateLayerRadios(layerType);
    });
  });

  document
    .getElementById("basemapOpacity")
    .addEventListener("input", function () {
      const opacity = parseInt(this.value) / 100;
      imageryLayer.setOpacity(opacity);
      document.getElementById("basemapOpacityValue").textContent =
        this.value + "%";
    });

  document.getElementById("basemapFit").addEventListener("click", function () {
    if (vectorSource.getFeatures().length > 0) {
      map.getView().fit(vectorSource.getExtent(), {
        padding: [50, 50, 50, 50],
        maxZoom: 16,
        duration: 1000,
      });
    }
  });

  document
    .getElementById("basemapClear")
    .addEventListener("click", function () {
      imageryLayer.setSource(null);
      detectionSource.clear();
      document.getElementById("basemapCountry").value = "";
      document.getElementById("basemapTarget").innerHTML =
        '<option value="">Select Country First</option>';
      document.getElementById("basemapTarget").disabled = true;
      document.getElementById("basemapImage").innerHTML =
        '<option value="">Select Target Name First</option>';
      document.getElementById("basemapImage").disabled = true;
      document.getElementById("basemapStatus").textContent =
        "Basemap loaded - select data to overlay imagery";
      document.getElementById("basemapFit").disabled = false;

      updateLayerVisibility("both");
      updateLayerRadios("both");
      updateLayerButtons("both");
    });

  document
    .getElementById("refreshBasemap")
    .addEventListener("click", async function () {
      await loadLocalBasemap();
    });
}

function updateLayerVisibility(layerType) {
  switch (layerType) {
    case "vector":
      vectorLayer.setVisible(true);
      imageryLayer.setVisible(false);
      detectionLayer.setVisible(true);
      break;
    case "imagery":
      vectorLayer.setVisible(false);
      imageryLayer.setVisible(true);
      detectionLayer.setVisible(true);
      break;
    case "both":
      vectorLayer.setVisible(true);
      imageryLayer.setVisible(true);
      detectionLayer.setVisible(true);
      break;
  }
}

function updateLayerButtons(layerType) {
  document.querySelectorAll(".layer-btn").forEach((btn) => {
    btn.classList.remove("active");
    if (btn.getAttribute("data-layer") === layerType) {
      btn.classList.add("active");
    }
  });
}

function updateLayerRadios(layerType) {
  document.querySelectorAll('input[name="basemapLayer"]').forEach((radio) => {
    radio.checked = radio.value === layerType;
  });
}

async function loadBasemapCountries() {
  try {
    const response = await fetch("/api/countries");
    const countries = await response.json();

    const countrySelect = document.getElementById("basemapCountry");
    countrySelect.innerHTML = '<option value="">Select Country</option>';

    countries.forEach((country) => {
      const option = document.createElement("option");
      option.value = country;
      option.textContent = country;
      countrySelect.appendChild(option);
    });
  } catch (error) {
    console.error("Failed to load countries:", error);
  }
}

async function loadBasemapTargets(country) {
  if (!country) return;

  try {
    document.getElementById("basemapTarget").innerHTML =
      '<option value="">Loading targets...</option>';

    const response = await fetch(
      `/api/target-types/${encodeURIComponent(country)}`
    );
    const targets = await response.json();

    const targetSelect = document.getElementById("basemapTarget");
    targetSelect.innerHTML = '<option value="">Select Target Name</option>';

    targets.forEach((target) => {
      const option = document.createElement("option");
      option.value = target;
      option.textContent = target;
      targetSelect.appendChild(option);
    });

    document.getElementById(
      "basemapStatus"
    ).textContent = `Country: ${country} - Select target`;
  } catch (error) {
    console.error("Failed to load targets:", error);
    document.getElementById("basemapTarget").innerHTML =
      '<option value="">Error loading targets</option>';
    document.getElementById("basemapStatus").textContent =
      "Error loading targets";
  }
}

async function loadBasemapImages(country, target) {
  if (!country || !target) return;

  try {
    const response = await fetch(
      `/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(
        target
      )}`
    );
    const images = await response.json();

    const imageSelect = document.getElementById("basemapImage");
    imageSelect.innerHTML = '<option value="">Select Image ID</option>';

    images.forEach((image) => {
      const option = document.createElement("option");
      option.value = image;
      option.textContent = image;
      imageSelect.appendChild(option);
    });

    document.getElementById(
      "basemapStatus"
    ).textContent = `Country: ${country}, Target: ${target} - Select image`;
  } catch (error) {
    console.error("Failed to load images:", error);
    document.getElementById("basemapImage").innerHTML =
      '<option value="">Error loading images</option>';
    document.getElementById("basemapStatus").textContent =
      "Error loading images";
  }
}

async function autoLoadBasemapData(imageId) {
  if (!imageId) return;
  await loadImageryData(imageId);
  await loadDetectionData(imageId);
  await zoomToImageryExtent(imageId);
}

async function loadImageryData(imageId) {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById(
      "basemapStatus"
    ).textContent = `Loading imagery for ${imageId}...`;

    const xyzSource = new XYZ({
      url: `${getAssetUrl(`tiles/${imageId}/{z}/{x}/{y}.png`)}`,
      crossOrigin: "anonymous",
    });

    imageryLayer.setSource(xyzSource);

    console.log("✅ Loaded XYZ imagery from asset server:", imageId);
    document.getElementById(
      "basemapStatus"
    ).textContent = `Imagery loaded: ${imageId}`;
  } catch (error) {
    console.error("Failed to load imagery:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading imagery - using basemap only";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

async function loadDetectionData(imageId) {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById(
      "basemapStatus"
    ).textContent = `Loading detection data for ${imageId}...`;

    const response = await fetch(`/api/unified-data/${imageId}`);
    const unifiedData = await response.json();

    detectionSource.clear();

    if (unifiedData.vector_data && unifiedData.vector_data.features) {
      const features = new GeoJSON().readFeatures(unifiedData.vector_data, {
        featureProjection: "EPSG:3857",
      });
      detectionSource.addFeatures(features);

      console.log("✅ Loaded detection data:", features.length, "features");
      document.getElementById(
        "basemapStatus"
      ).textContent = `Data loaded: ${imageId} (${features.length} detections)`;
    } else {
      console.log("ℹ️ No detection data available for:", imageId);
      document.getElementById(
        "basemapStatus"
      ).textContent = `Imagery loaded: ${imageId} (no detections)`;
    }
  } catch (error) {
    console.error("Failed to load detection data:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading detection data";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

async function zoomToImageryExtent(imageId) {
  try {
    const response = await fetch(`/api/unified-data/${imageId}`);
    const data = await response.json();
    if (data.vector_data?.features?.length > 0) {
      const features = new GeoJSON().readFeatures(data.vector_data, {
        featureProjection: "EPSG:3857",
      });
      const extent = features.reduce(
        (ext, f) => {
          const geom = f.getGeometry();
          if (geom) {
            const featExtent = geom.getExtent();
            return [
              Math.min(ext[0], featExtent[0]),
              Math.min(ext[1], featExtent[1]),
              Math.max(ext[2], featExtent[2]),
              Math.max(ext[3], featExtent[3]),
            ];
          }
          return ext;
        },
        [Infinity, Infinity, -Infinity, -Infinity]
      );
      if (isFinite(extent[0])) {
        map.getView().fit(extent, {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 800,
        });
        return;
      }
    }
  } catch (e) {
    console.warn("Could not zoom to imagery extent:", e);
  }
  map.getView().setCenter(fromLonLat([8.55, 50.04]));
  map.getView().setZoom(14);
}
