export const CONFIG = {
  ASSET_SERVER: import.meta.env.VITE_ASSET_SERVER || "http://localhost:8082",
  API_BASE: "/api",
  TILES_BASE: "/tiles",
  COGS_BASE: "/cogs",
  REPORTS_BASE: "/reports",
  BASEMAPS_BASE: "/basemaps",
  ICONS_BASE: "/icons",
  IMAGES_BASE: "/images",
  CSS_BASE: "/css",
  JS_BASE: "/js",
};

export function getAssetUrl(path) {
  // Remove leading slash if present to avoid double slashes
  const cleanPath = path.startsWith("/") ? path.slice(1) : path;
  return `${CONFIG.ASSET_SERVER}/${cleanPath}`;
}

export async function checkAssetServer() {
  try {
    const response = await fetch(`${CONFIG.ASSET_SERVER}/nginx-health`, {
      method: "GET",
      timeout: 5000,
    });
    return response.ok;
  } catch (error) {
    console.warn("Asset server not accessible:", error);
    return false;
  }
}
