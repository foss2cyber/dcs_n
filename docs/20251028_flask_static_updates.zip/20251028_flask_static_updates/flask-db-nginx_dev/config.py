# config.py
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    DB_URL = (
        f"postgresql://{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}"
        f"@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '5432')}"
        f"/{os.getenv('DB_NAME')}"
    )
    REPORTS_DIR = os.getenv('REPORTS_DIR', '/reports')
    COGS_DIR = os.getenv('COGS_DIR', '/cogs')
    TILES_DIR = os.getenv('TILES_DIR', '/tiles')
    BASEMAPS_DIR = os.getenv('BASEMAP_DIR', '/basemaps')
    
    # Static Asset Server Configuration
    ASSET_SERVER = os.getenv('ASSET_SERVER', 'http://localhost:8082')
    
    # Asset paths on the static server
    TILES_BASE_URL = f"{ASSET_SERVER}/tiles"
    COGS_BASE_URL = f"{ASSET_SERVER}/cogs" 
    REPORTS_BASE_URL = f"{ASSET_SERVER}/reports"
    BASEMAPS_BASE_URL = f"{ASSET_SERVER}/basemaps"
    ICONS_BASE_URL = f"{ASSET_SERVER}/icons"
    IMAGES_BASE_URL = f"{ASSET_SERVER}/images"
    
    # Add for production security
    #SECRET_KEY = os.getenv('SECRET_KEY', 'dev-key-change-in-production')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file upload