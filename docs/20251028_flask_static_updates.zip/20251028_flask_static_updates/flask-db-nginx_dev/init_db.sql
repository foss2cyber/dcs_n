-- init_db.sql - CORRECTED SCHEMA
CREATE EXTENSION IF NOT EXISTS postgis;

-- Drop existing objects
DROP VIEW IF EXISTS comprehensive_query;

DROP TABLE IF EXISTS sql_scat_query2 CASCADE;

DROP TABLE IF EXISTS findings CASCADE;

DROP TABLE IF EXISTS target CASCADE;

-- Physical Table 1: findings (base detections)
CREATE TABLE findings (
    id INTEGER PRIMARY KEY,
    image_id CHARACTER VARYING(100) NOT NULL,
    image_date DATE,
    target_class CHARACTER VARYING(30),
    score DOUBLE PRECISION,
    target_geom GEOMETRY (POLYGON, 4326)
);

-- Physical Table 2: target (metadata)
CREATE TABLE target (
    id INTEGER PRIMARY KEY,
    target_type CHARACTER VARYING(50),
    target_name CHARACTER VARYING(100),
    country_name CHARACTER VARYING(25),
    target_geom GEOMETRY (POLYGON, 4326)
);

-- Physical Table 3: sql_scat_query2 (precomputed results WITH score)
CREATE TABLE sql_scat_query2 (
    id SERIAL PRIMARY KEY,
    country_name CHARACTER VARYING(25),
    target_name CHARACTER VARYING(100),
    image_id CHARACTER VARYING(100) NOT NULL,
    image_date DATE,
    target_class CHARACTER VARYING(30),
    score DOUBLE PRECISION,
    st_x DOUBLE PRECISION,
    st_y DOUBLE PRECISION
);

-- Create comprehensive_query as a VIEW (not a table)
CREATE VIEW comprehensive_query AS
SELECT sq.target_name, sq.country_name, sq.image_id, sq.image_date, sq.target_class, COUNT(*) AS total_count
FROM sql_scat_query2 sq
GROUP BY
    sq.target_name,
    sq.country_name,
    sq.image_id,
    sq.image_date,
    sq.target_class;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_findings_geom ON findings USING GIST (target_geom);

CREATE INDEX IF NOT EXISTS idx_findings_image_id ON findings (image_id);

CREATE INDEX IF NOT EXISTS idx_target_geom ON target USING GIST (target_geom);

CREATE INDEX IF NOT EXISTS idx_sql_scat_query2_image_id ON sql_scat_query2 (image_id);

-- Sample Data
DELETE FROM sql_scat_query2;

DELETE FROM findings;

DELETE FROM target;

INSERT INTO
    findings (
        id,
        image_id,
        image_date,
        target_class,
        score,
        target_geom
    )
VALUES (
        1,
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AF-CGAA-1',
        0.95,
        ST_GeomFromText (
            'POLYGON((8.550 50.040, 8.552 50.040, 8.552 50.038, 8.550 50.038, 8.550 50.040))',
            4326
        )
    ),
    (
        2,
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AP-CGSV-1',
        0.89,
        ST_GeomFromText (
            'POLYGON((8.553 50.041, 8.555 50.041, 8.555 50.039, 8.553 50.039, 8.553 50.041))',
            4326
        )
    );

INSERT INTO
    target (
        id,
        target_type,
        target_name,
        country_name,
        target_geom
    )
VALUES (
        1,
        'airfield',
        'Frankfurt_Airport_Aircraft_1',
        'Germany',
        ST_GeomFromText (
            'POLYGON((8.550 50.040, 8.552 50.040, 8.552 50.038, 8.550 50.038, 8.550 50.040))',
            4326
        )
    ),
    (
        2,
        'airport',
        'Frankfurt_Airport_Service_1',
        'Germany',
        ST_GeomFromText (
            'POLYGON((8.553 50.041, 8.555 50.041, 8.555 50.039, 8.553 50.039, 8.553 50.041))',
            4326
        )
    );

INSERT INTO
    sql_scat_query2 (
        country_name,
        target_name,
        image_id,
        image_date,
        target_class,
        score,
        st_x,
        st_y
    )
VALUES (
        'Germany',
        'Frankfurt_Airport_Aircraft_1',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AF-CGAA-1',
        0.95,
        8.551,
        50.039
    ),
    (
        'Germany',
        'Frankfurt_Airport_Service_1',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AP-CGSV-1',
        0.89,
        8.554,
        50.040
    );