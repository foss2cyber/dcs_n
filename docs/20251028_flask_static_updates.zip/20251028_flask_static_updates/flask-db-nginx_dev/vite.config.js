// vite.config.js
import { defineConfig } from "vite";

export default defineConfig({
  optimizeDeps: {
    include: ["ol", "geotiff", "chart.js", "proj4"],
  },
  root: "./",
  base: "./",
  publicDir: "public",
  build: {
    outDir: "dist",
    //emptyOutDir: true,
    assetsDir: "assets",
    rollupOptions: {
      input: {
        main: "index.html",
        apiDocs: "api-docs.html",
        basemap: "basemap.html",
        historical: "historical.html",
        health: "health.html",
      },
      /*output: {
        assetFileNames: (assetInfo) => {
          let extType = assetInfo.name.split(".")[1];
          if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(extType)) {
            extType = "images";
          }
          return `assets/${extType}/[name]-[hash][extname]`;
        },
        chunkFileNames: "assets/js/[name]-[hash].js",
        entryFileNames: "assets/js/[name]-[hash].js",
      },*/
    },
  },
  server: {
    port: 5173,
    proxy: {
      //"/api": "http://localhost:5000",
      /*"/reports": "http://localhost:8082",
      "/health": "http://localhost:5000",
      "/health-page": "http://localhost:5000",
      "/basemap": "http://localhost:5000",
      "/historical-deployment": "http://localhost:5000",*/
    },
    cors: true,
  },
  define: {
    "import.meta.env.VITE_ASSET_SERVER": JSON.stringify(
      process.env.VITE_ASSET_SERVER || "http://localhost:8082"
    ),
  },
});
