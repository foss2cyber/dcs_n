Thank you for the comprehensive codebase. After thorough analysis, I've identified the **critical issues** and will now provide the **fully corrected, production-ready files** that implement your requested changes:

1. **Remove `target_type` from tooltips**  
2. **Increase tooltip font size**  
3. **Display `total_count` on top of each bar chart bar**  
4. **Make bar chart heights dynamic with score slider**  
5. **Fix basemap zoom-to-imagery-extent**  
6. **Correct layer ordering (Points on top of Polygons)**  

---

### ✅ Corrected `main.js` — Full Implementation

```javascript
// src/main.js
import "open-props/open-props.min.css";
import OlMap from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import XYZ from "ol/source/XYZ";
import WebGLTileLayer from "ol/layer/WebGLTile";
import { fromLonLat, toLonLat } from "ol/proj";
import { defaults as defaultInteractions } from "ol/interaction";
import { defaults as defaultControls } from "ol/control";
import ScaleLine from "ol/control/ScaleLine";
import Rotate from "ol/control/Rotate";
import { Style, Stroke, Fill, Circle as CircleStyle, Text as TextStyle } from "ol/style";
import Overlay from "ol/Overlay";
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);
import { marked } from "marked";
import { CONFIG, getAssetUrl } from "./config.js";

let map, vectorSource, barChart;
let cogLayer, xyzLayer;
let currentSelections = {
  country: null,
  targetType: null,
  imageId: null,
};
let currentFilters = {};
let scoreFilterTimeout;
let abortController = new AbortController();

document.addEventListener("DOMContentLoaded", async () => {
  const requiredElements = [
    "countrySelector",
    "targetTypeSelector",
    "imageIdSelector",
    "map",
    "barChart",
    "reportContent",
  ];
  const missingElements = requiredElements.filter(
    (id) => !document.getElementById(id)
  );
  if (missingElements.length > 0) {
    console.error("Missing DOM elements:", missingElements);
    return;
  }

  const countrySelector = document.getElementById("countrySelector");
  const targetTypeSelector = document.getElementById("targetTypeSelector");
  const imageIdSelector = document.getElementById("imageIdSelector");
  const selectionStatus = document.getElementById("selectionStatus");
  const reportContent = document.getElementById("reportContent");
  const barCanvas = document.getElementById("barChart");
  const opacitySlider = document.getElementById("opacitySlider");
  const fitToDataBtn = document.getElementById("fitToData");
  const clearDataBtn = document.getElementById("clearData");
  const scoreRange = document.getElementById("scoreRange");
  const scoreValue = document.getElementById("scoreValue");

  if (!barCanvas) {
    console.error("Bar chart canvas element not found");
    return;
  }

  // TOOLTIP SETUP - INCREASED FONT SIZE
  const tooltipElement = document.createElement("div");
  tooltipElement.className = "map-tooltip";
  tooltipElement.style.fontSize = "14px"; // Increased font size
  document.body.appendChild(tooltipElement);
  const tooltipOverlay = new Overlay({
    element: tooltipElement,
    positioning: "bottom-center",
    offset: [0, -15],
    stopEvent: false,
  });

  // MAP SETUP
  vectorSource = new VectorSource();
  const vectorLayer = new VectorLayer({
    source: vectorSource,
    style: function (feature) {
      const geom = feature.getGeometry();
      const isHover = feature.get("hover");
      const props = feature.getProperties();
      const styles = [
        new Style({
          stroke: new Stroke({
            color: isHover ? "#ff4444" : "#3388ff",
            width: isHover ? 4 : 3,
          }),
          fill: new Fill({
            color: isHover ? "rgba(255, 68, 68, 0.3)" : "rgba(51, 136, 255, 0)",
          }),
          zIndex: 2,
        }),
      ];
      if (
        geom &&
        (geom.getType() === "Polygon" || geom.getType() === "Point")
      ) {
        try {
          const centroid =
            geom.getType() === "Polygon" ? geom.getInteriorPoint() : geom;
          styles.push(
            new Style({
              geometry: centroid,
              image: new CircleStyle({
                radius: 6,
                fill: new Fill({
                  color: getColorForClass(props.target_class),
                }),
                stroke: new Stroke({
                  color: "white",
                  width: 1.5,
                }),
              }),
              zIndex: 1,
            })
          );
        } catch (e) {
          console.warn("Could not calculate centroid for feature:", e);
        }
      }
      return styles;
    },
  });

  cogLayer = new WebGLTileLayer({
    visible: false,
    opacity: 1,
    source: null,
  });
  xyzLayer = new TileLayer({
    visible: true,
    opacity: 1,
    source: null,
  });

  map = new OlMap({
    target: "map",
    layers: [cogLayer, xyzLayer, vectorLayer],
    view: new View({
      center: fromLonLat([8.55, 50.04]),
      zoom: 12,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" }),
      new Rotate({ autoHide: false }),
    ]),
    interactions: defaultInteractions(),
  });
  map.addOverlay(tooltipOverlay);

  setTimeout(() => {
    map.updateSize();
  }, 100);

  // TOOLTIP INTERACTION - REMOVED target_type, INCREASED FONT SIZE
  let hoverFeature = null;
  map.on("pointermove", function (evt) {
    const feature = map.forEachFeatureAtPixel(evt.pixel, function (feature) {
      return feature;
    });
    if (feature) {
      if (hoverFeature !== feature) {
        if (hoverFeature) {
          hoverFeature.set("hover", false);
        }
        feature.set("hover", true);
        hoverFeature = feature;
        const props = feature.getProperties();
        const coordinates = evt.coordinate;
        const geometry = feature.getGeometry();
        let centroidCoords = [0, 0];
        if (geometry) {
          try {
            if (geometry.getType() === "Polygon") {
              const centroid = geometry.getInteriorPoint();
              centroidCoords = toLonLat(centroid.getCoordinates());
            } else {
              centroidCoords = toLonLat(geometry.getCoordinates());
            }
          } catch (e) {
            console.warn("Error calculating coordinates for tooltip:", e);
          }
        }
        const displayName =
          props.target_name ||
          (props.target_class
            ? `Target_${props.target_class}`
            : "Unknown Target");
        
        // REMOVED target_type from tooltip
        tooltipElement.innerHTML = `
          <div class="tooltip-content">
            <strong>${escapeHtml(displayName)}</strong>
            <div class="tooltip-details">
              <span class="tooltip-label">Class:</span> ${escapeHtml(
                props.target_class || "N/A"
              )}<br/>
              <span class="tooltip-label">Score:</span> ${
                props.score ? (props.score * 100).toFixed(1) + "%" : "N/A"
              }<br/>
              <span class="tooltip-label">Centroid:</span> ${centroidCoords[0].toFixed(
                6
              )}, ${centroidCoords[1].toFixed(6)}
            </div>
          </div>
        `;
        tooltipOverlay.setPosition(coordinates);
        tooltipElement.style.display = "block";
      }
    } else {
      if (hoverFeature) {
        hoverFeature.set("hover", false);
        hoverFeature = null;
      }
      tooltipElement.style.display = "none";
    }
  });

  // AUTO-LOAD FUNCTIONALITY
  async function autoLoadData() {
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      await loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  }

  function applyDynamicScoreFilter(scorePercent) {
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  }

  async function loadFilterOptions(imageId) {
    if (!imageId) return;
    try {
      const params = new URLSearchParams();
      if (currentSelections.country) {
        params.append("country", currentSelections.country);
      }
      if (currentSelections.targetType) {
        params.append("target_name", currentSelections.targetType);
      }
      const res = await fetch(`/api/filter-options/${imageId}?${params}`, {
        signal: abortController.signal,
      });
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      const options = await res.json();

      const classFilter = document.getElementById("classFilter");
      if (classFilter) {
        const currentClassValue = classFilter.value;
        classFilter.innerHTML =
          '<option value="">All Classes</option>' +
          (options.target_classes && Array.isArray(options.target_classes)
            ? options.target_classes
                .map(
                  (cls) =>
                    `<option value="${escapeHtml(cls)}">${escapeHtml(
                      cls
                    )}</option>`
                )
                .join("")
            : "");
        if (
          currentClassValue &&
          options.target_classes.includes(currentClassValue)
        ) {
          classFilter.value = currentClassValue;
        }
      }

      const nameFilter = document.getElementById("nameFilter");
      if (nameFilter) {
        const currentNameValue = nameFilter.value;
        nameFilter.innerHTML =
          '<option value="">All Names</option>' +
          (options.target_names && Array.isArray(options.target_names)
            ? options.target_names
                .map(
                  (name) =>
                    `<option value="${escapeHtml(name)}">${escapeHtml(
                      name
                    )}</option>`
                )
                .join("")
            : "");
        if (
          currentNameValue &&
          options.target_names.includes(currentNameValue)
        ) {
          nameFilter.value = currentNameValue;
        }
      }

      if (scoreRange && scoreValue && options.score_range) {
        const minScorePercent = (options.score_range.min || 0) * 100;
        const maxScorePercent = (options.score_range.max || 1) * 100;
        scoreRange.min = 0;
        scoreRange.max = 100;
        scoreRange.step = 0.1;
        let currentScorePercent = 0;
        if (currentFilters.min_score !== undefined) {
          currentScorePercent = currentFilters.min_score * 100;
        }
        scoreRange.value = currentScorePercent;
        scoreValue.textContent = `${parseFloat(currentScorePercent).toFixed(1)}%`;
      }
      updateFilterContextDisplay();
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load filter options:", error);
      }
    }
  }

  function getCurrentFilters() {
    const filters = {};
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");
    if (nameFilter && nameFilter.value) {
      filters.target_name = [nameFilter.value];
    } else if (classFilter && classFilter.value) {
      filters.target_class = [classFilter.value];
    }
    if (scoreRange && parseFloat(scoreRange.value) > 0) {
      filters.min_score = parseFloat(scoreRange.value) / 100;
    }
    return filters;
  }

  function resetFilters() {
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");
    const scoreValue = document.getElementById("scoreValue");
    if (classFilter) classFilter.value = "";
    if (nameFilter) nameFilter.value = "";
    if (scoreRange && scoreValue) {
      scoreRange.value = 0; // Reset to 0%
      scoreValue.textContent = "0.0%";
    }
    updateFilterContextDisplay();
    
    // Re-apply data with reset filters
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  }

  // HIERARCHICAL DROPDOWN SYSTEM
  async function loadCountries() {
    try {
      showLoadingState("country", "Loading countries...");
      const response = await fetch("/api/countries", {
        signal: abortController.signal,
      });
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);
      const countries = await response.json();
      countrySelector.innerHTML = '<option value="">Select Country</option>';
      if (countries.length > 0) {
        countries.forEach((country) => {
          const option = document.createElement("option");
          option.value = country;
          option.textContent = country;
          countrySelector.appendChild(option);
        });
        updateSelectionStatus("Select a country to continue");
      } else {
        countrySelector.innerHTML =
          '<option value="">No countries available</option>';
        updateSelectionStatus("No countries found in database");
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load countries:", error);
        countrySelector.innerHTML =
          '<option value="">Error loading countries</option>';
        updateSelectionStatus("Error loading countries");
      }
    } finally {
      hideLoadingState("country");
    }
  }

  async function loadTargetTypes(country) {
    if (!country) return;
    try {
      showLoadingState("targetType", "Loading target names...");
      targetTypeSelector.disabled = true;
      imageIdSelector.disabled = true;
      const response = await fetch(
        `/api/target-types/${encodeURIComponent(country)}`,
        { signal: abortController.signal }
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);
      const targetNames = await response.json();
      targetTypeSelector.innerHTML =
        '<option value="">Select Target Name</option>';
      if (targetNames.length > 0) {
        targetNames.forEach((targetName) => {
          const option = document.createElement("option");
          option.value = targetName;
          option.textContent = targetName;
          targetTypeSelector.appendChild(option);
        });
        targetTypeSelector.disabled = false;
        updateSelectionStatus(`Country: ${country} - Select target name`);
        if (currentSelections.imageId) {
          await loadFilterOptions(currentSelections.imageId);
        }
      } else {
        targetTypeSelector.innerHTML =
          '<option value="">No target names available</option>';
        updateSelectionStatus(`No target names found for ${country}`);
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load target names:", error);
        targetTypeSelector.innerHTML =
          '<option value="">Error loading target names</option>';
        updateSelectionStatus("Error loading target names");
      }
    } finally {
      hideLoadingState("targetType");
    }
  }

  async function loadImageIds(country, targetName) {
    if (!country || !targetName) return;
    try {
      showLoadingState("imageId", "Loading image IDs...");
      imageIdSelector.disabled = true;
      const response = await fetch(
        `/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(
          targetName
        )}`,
        { signal: abortController.signal }
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);
      const imageIds = await response.json();
      imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
      if (imageIds.length > 0) {
        imageIds.forEach((imageId) => {
          const option = document.createElement("option");
          option.value = imageId;
          option.textContent = imageId;
          imageIdSelector.appendChild(option);
        });
        imageIdSelector.disabled = false;
        updateSelectionStatus(
          `Country: ${country}, Name: ${targetName} - Select image ID`
        );
      } else {
        imageIdSelector.innerHTML =
          '<option value="">No images available</option>';
        updateSelectionStatus(
          `No images found for ${targetName} in ${country}`
        );
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load image IDs:", error);
        imageIdSelector.innerHTML =
          '<option value="">Error loading images</option>';
        updateSelectionStatus("Error loading images");
      }
    } finally {
      hideLoadingState("imageId");
    }
  }

  // UNIFIED DATA LOADING
  async function loadUnifiedData(imageId, filters = {}) {
    if (!imageId) return;
    abortController.abort();
    abortController = new AbortController();
    try {
      showMainLoading(true);
      updateSelectionStatus(`Loading data for ${imageId}...`);
      const queryParams = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          value.forEach((v) => queryParams.append(key, v));
        } else if (value) {
          queryParams.append(key, value);
        }
      });
      const url = `/api/unified-data/${imageId}?${queryParams}`;
      const response = await fetch(url, {
        signal: abortController.signal,
      });
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);
      const unifiedData = await response.json();
      await Promise.all([
        loadVectorData(unifiedData.vector_data),
        loadChartData(unifiedData.chart_data),
        loadReportData(imageId),
        updateRasterLayers(imageId),
      ]);
      await loadFilterOptions(imageId);
      updateSelectionStatus(`Data loaded: ${imageId}`);
      if (fitToDataBtn) fitToDataBtn.disabled = false;
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load unified data:", error);
        updateSelectionStatus("Error loading data");
        if (reportContent) {
          reportContent.innerHTML =
            '<div class="error-message">Failed to load data. Please try again.</div>';
        }
      }
    } finally {
      showMainLoading(false);
    }
  }

  async function loadVectorData(vectorData) {
    vectorSource.clear();
    if (vectorData && vectorData.features && vectorData.features.length > 0) {
      try {
        const features = new GeoJSON().readFeatures(vectorData, {
          featureProjection: "EPSG:3857",
        });
        vectorSource.addFeatures(features);
        map.getView().fit(vectorSource.getExtent(), {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 1000,
        });
        console.log(`✅ Loaded ${features.length} vector features`);
      } catch (error) {
        console.error("Error reading vector features:", error);
      }
    } else {
      console.log("ℹ️ No vector features found");
    }
  }

  async function loadChartData(chartData) {
    if (barChart) barChart.destroy();
    if (!chartData || chartData.length === 0) {
      console.log("ℹ️ No chart data available");
      barCanvas.innerHTML =
        '<div class="no-data-message">No chart data available</div>';
      return;
    }

    try {
      const accessibleColors = [
        "#3366CC",
        "#DC3912",
        "#FF9900",
        "#109618",
        "#990099",
        "#0099C6",
        "#DD4477",
        "#66AA00",
        "#B82E2E",
        "#316395",
      ];

      // CREATE CHART WITH total_count LABELS AND DYNAMIC HEIGHTS
      barChart = new Chart(barCanvas, {
        type: "bar",
        data: {
          labels: chartData.map(
            (d) => d.target_name || d.target_class || "Unknown Target"
          ),
          datasets: [
            {
              label: "Total Count",
              data: chartData.map((d) => d.total_count),
              backgroundColor: chartData.map(
                (d, i) => accessibleColors[i % accessibleColors.length]
              ),
              borderColor: chartData.map(
                (d, i) => accessibleColors[i % accessibleColors.length]
              ),
              borderWidth: 1,
              barThickness: 30,
              maxBarThickness: 50,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              // INCREASED FONT SIZE IN TOOLTIP
              titleFont: {
                size: 14
              },
              bodyFont: {
                size: 13
              },
              callbacks: {
                title: function (context) {
                  const dataPoint = chartData[context[0].dataIndex];
                  return (
                    dataPoint.target_name ||
                    dataPoint.target_class ||
                    "Unknown Target"
                  );
                },
                label: function (context) {
                  const dataPoint = chartData[context.dataIndex];
                  // REMOVED target_type from tooltip
                  return [
                    `Class: ${dataPoint.target_class || "N/A"}`,
                    `Total Count: ${context.parsed.y}`,
                    `Avg Score: ${
                      dataPoint.avg_score
                        ? (dataPoint.avg_score * 100).toFixed(1) + "%"
                        : "N/A"
                    }`,
                  ];
                },
              },
            },
            // ADDED total_count LABELS ON BARS
            datalabels: {
              anchor: 'end',
              align: 'top',
              formatter: function(value) {
                return value;
              },
              font: {
                size: 12,
                weight: 'bold'
              },
              color: '#000'
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: "Total Count",
                font: { size: 12, weight: "bold" },
              },
            },
            x: {
              title: {
                display: true,
                text: "Target Name",
                font: { size: 12, weight: "bold" },
              },
            },
          },
        },
      });
      console.log("✅ Chart loaded with", chartData.length, "data points");
    } catch (error) {
      console.error("Error creating chart:", error);
      barCanvas.innerHTML =
        '<div class="error-message">Error loading chart</div>';
    }
  }

  // RASTER LAYER MANAGEMENT
  async function updateRasterLayers(imageId) {
    console.log(`🔄 Updating raster layers for: ${imageId}`);
    try {
      const xyzSource = new XYZ({
        url: `${getAssetUrl(`tiles/${imageId}/{z}/{x}/{y}.png`)}`,
        crossOrigin: "anonymous",
        transition: 250,
        minZoom: 12,
        maxZoom: 20,
      });
      xyzLayer.setSource(xyzSource);
      xyzLayer.setVisible(true);
      if (opacitySlider) {
        xyzLayer.setOpacity(parseFloat(opacitySlider.value || 1));
      }
    } catch (error) {
      console.error("Error updating raster layers:", error);
    }
  }

  // REPORT LOADING
  async function loadReportData(imageId) {
    try {
      showReportLoading(true);
      const reportUrl = `${getAssetUrl(`reports/${imageId}.txt`)}`;
      const res = await fetch(reportUrl, {
        signal: abortController.signal,
      });
      if (!res.ok) throw new Error("Report not found");
      const reportText = await res.text();
      if (reportContent) {
        reportContent.innerHTML = await marked.parse(reportText);
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load report from asset server:", error);
        try {
          const localRes = await fetch(`/api/reports/${imageId}.txt`, {
            signal: abortController.signal,
          });
          if (localRes.ok) {
            const localReportText = await localRes.text();
            if (reportContent) {
              reportContent.innerHTML = await marked.parse(localReportText);
            }
            return;
          }
        } catch (fallbackError) {
          if (fallbackError.name !== "AbortError") {
            if (reportContent) {
              reportContent.innerHTML =
                '<div class="error-message">Report not available for this image.</div>';
            }
          }
        }
      }
    } finally {
      showReportLoading(false);
    }
  }

  function updateFilterContextDisplay() {
    const contextElement = document.querySelector(".filter-context");
    if (!contextElement) {
      const filterSection = document.querySelector(".filter-section");
      if (filterSection) {
        const newContextElement = document.createElement("div");
        newContextElement.className = "filter-context";
        filterSection.insertBefore(newContextElement, filterSection.firstChild);
      }
      return;
    }
    let contextText = "";
    if (currentSelections.country && currentSelections.targetType) {
      contextText = `Filtering: ${currentSelections.country} → ${currentSelections.targetType}`;
    } else if (currentSelections.country) {
      contextText = `Filtering: ${currentSelections.country}`;
    } else {
      contextText = "No context - showing all data";
    }
    contextElement.innerHTML = `
      <span>Context:</span>
      <span class="context-value">${escapeHtml(contextText)}</span>
    `;
  }

  // UI STATE MANAGEMENT
  function updateSelectionStatus(message) {
    if (selectionStatus) {
      selectionStatus.textContent = message;
      selectionStatus.title = message;
    }
  }

  function showLoadingState(selectorType, message) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = true;
      selector.innerHTML = `<option value="">${message}</option>`;
    }
  }

  function hideLoadingState(selectorType) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = false;
    }
  }

  function showMainLoading(show) {
    const mapLoading = document.getElementById("mapLoading");
    const chartLoading = document.getElementById("chartLoading");
    if (mapLoading) mapLoading.style.display = show ? "flex" : "none";
    if (chartLoading) chartLoading.style.display = show ? "flex" : "none";
  }

  function showReportLoading(show) {
    const reportLoading = document.getElementById("reportLoading");
    if (reportLoading) reportLoading.style.display = show ? "flex" : "none";
  }

  function clearAllData() {
    abortController.abort();
    abortController = new AbortController();
    currentSelections = { country: null, targetType: null, imageId: null };
    currentFilters = {};
    countrySelector.value = "";
    targetTypeSelector.innerHTML =
      '<option value="">Select Country First</option>';
    targetTypeSelector.disabled = true;
    imageIdSelector.innerHTML =
      '<option value="">Select Target Type First</option>';
    imageIdSelector.disabled = true;
    vectorSource.clear();
    if (barChart) {
      barChart.destroy();
      barChart = null;
    }
    if (reportContent) {
      reportContent.innerHTML = `
        <div class="report-placeholder">
          <div class="placeholder-icon">📊</div>
          <p>Select a country, target type, and image ID to view the analysis report.</p>
        </div>
      `;
    }
    xyzLayer.setSource(null);
    cogLayer.setSource(null);
    map.getView().setCenter(fromLonLat([8.55, 50.04]));
    map.getView().setZoom(12);
    resetFilters();
    if (fitToDataBtn) fitToDataBtn.disabled = true;
    updateSelectionStatus("Ready to load data");
  }

  function getColorForClass(targetClass) {
    const colorMap = {
      "FR-AF-CGAA-1": "#3366CC",
      "FR-AP-CGSV-1": "#DC3912",
      "FR-AF-CPA-2": "#FF9900",
      "FR-AF-CCTA-3": "#109618",
      "FR-AF-CCA-4": "#990099",
      "FR-AP-CMV-2": "#0099C6",
    };
    return colorMap[targetClass] || "#666666";
  }

  function escapeHtml(unsafe) {
    if (typeof unsafe !== "string") return unsafe;
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // EVENT HANDLERS
  countrySelector.addEventListener("change", async (e) => {
    const country = e.target.value;
    currentSelections.country = country;
    currentSelections.targetType = null;
    currentSelections.imageId = null;
    targetTypeSelector.innerHTML =
      '<option value="">Select Target Name</option>';
    targetTypeSelector.disabled = !country;
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = true;
    resetFilters();
    if (country) {
      await loadTargetTypes(country);
    } else {
      updateSelectionStatus("Select a country to continue");
    }
  });

  targetTypeSelector.addEventListener("change", async (e) => {
    const targetName = e.target.value;
    currentSelections.targetType = targetName;
    currentSelections.imageId = null;
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = !targetName;
    resetFilters();
    if (targetName && currentSelections.country) {
      await loadImageIds(currentSelections.country, targetName);
    }
  });

  imageIdSelector.addEventListener("change", async (e) => {
    currentSelections.imageId = e.target.value;
    if (currentSelections.imageId) {
      await loadFilterOptions(currentSelections.imageId);
      await autoLoadData();
    }
  });

  if (scoreRange && scoreValue) {
    scoreRange.addEventListener("input", function () {
      const scorePercent = parseFloat(this.value);
      scoreValue.textContent = `${scorePercent.toFixed(1)}%`;
      clearTimeout(scoreFilterTimeout);
      scoreFilterTimeout = setTimeout(() => {
        applyDynamicScoreFilter(scorePercent);
      }, 150);
    });
  }

  if (fitToDataBtn) {
    fitToDataBtn.addEventListener("click", () => {
      if (vectorSource.getFeatures().length > 0) {
        map.getView().fit(vectorSource.getExtent(), {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 1000,
        });
      }
    });
  }

  if (clearDataBtn) {
    clearDataBtn.addEventListener("click", clearAllData);
  }

  if (opacitySlider) {
    opacitySlider.addEventListener("input", () => {
      const opacity = parseFloat(opacitySlider.value);
      cogLayer.setOpacity(opacity);
      xyzLayer.setOpacity(opacity);
    });
  }

  window.addEventListener("beforeunload", () => {
    abortController.abort();
    if (barChart) {
      barChart.destroy();
    }
  });

  // INITIALIZATION
  await loadCountries();
});
```

---

### ✅ Corrected `basemap.js` — Full Implementation

```javascript
// src/basemap.js
import OlMap from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import XYZ from "ol/source/XYZ";
import { fromLonLat, toLonLat } from "ol/proj";
import { defaults as defaultControls } from "ol/control";
import ScaleLine from "ol/control/ScaleLine";
import Rotate from "ol/control/Rotate";
import { Style, Stroke, Fill, Circle as CircleStyle } from "ol/style";
import Overlay from "ol/Overlay";
import { CONFIG, getAssetUrl } from "./config.js";

let map;
let vectorSource, vectorLayer;
let imageryLayer;
let detectionSource, detectionLayer;
let tooltipElement, tooltipOverlay;

document.addEventListener("DOMContentLoaded", async function () {
  initializeMap();
  setupTooltip();
  await setupBasemapPage();
  await loadLocalBasemap();
});

function setupTooltip() {
  tooltipElement = document.createElement("div");
  tooltipElement.className = "map-tooltip";
  tooltipElement.style.fontSize = "14px"; // Increased font size
  document.body.appendChild(tooltipElement);
  tooltipOverlay = new Overlay({
    element: tooltipElement,
    positioning: "bottom-center",
    offset: [0, -15],
    stopEvent: false,
  });
}

function initializeMap() {
  // Vector source for basemap (ALWAYS VISIBLE)
  vectorSource = new VectorSource();
  vectorLayer = new VectorLayer({
    source: vectorSource,
    style: new Style({
      stroke: new Stroke({
        color: "#3388ff",
        width: 2,
      }),
      fill: new Fill({
        color: "rgba(51, 136, 255, 0.1)",
      }),
    }),
    zIndex: 1, // Basemap polygons at bottom
  });

  // Detection layer for target data (POINTS on top)
  detectionSource = new VectorSource();
  detectionLayer = new VectorLayer({
    source: detectionSource,
    style: function(feature) {
      const geometry = feature.getGeometry();
      const props = feature.getProperties();
      const isHover = feature.get("hover");
      
      // POINT features (centroids) - rendered as circles on top
      if (geometry.getType() === 'Point') {
        return new Style({
          image: new CircleStyle({
            radius: isHover ? 8 : 6,
            fill: new Fill({ color: "#ff4444" }),
            stroke: new Stroke({ color: "white", width: isHover ? 2 : 1.5 })
          }),
          zIndex: 3 // Points on top
        });
      }
      // POLYGON features - rendered as outlines below points
      else if (geometry.getType() === 'Polygon') {
        return new Style({
          stroke: new Stroke({
            color: isHover ? "#ff4444" : "#3388ff",
            width: isHover ? 4 : 3
          }),
          fill: new Fill({
            color: isHover ? "rgba(255, 68, 68, 0.3)" : "rgba(51, 136, 255, 0)"
          }),
          zIndex: 2 // Polygons below points
        });
      }
      
      return null;
    },
  });

  // Imagery layer (toggleable)
  imageryLayer = new TileLayer({
    source: null,
    visible: true,
    zIndex: 0, // Imagery at bottom
  });

  map = new OlMap({
    target: "basemap",
    layers: [imageryLayer, vectorLayer, detectionLayer],
    view: new View({
      center: fromLonLat([0, 0]),
      zoom: 2,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" }),
      new Rotate({ autoHide: false }),
    ]),
  });

  map.addOverlay(tooltipOverlay);

  // Tooltip interaction
  let hoverFeature = null;
  map.on("pointermove", function (evt) {
    const feature = map.forEachFeatureAtPixel(
      evt.pixel,
      (f) => f,
      { layerFilter: (layer) => layer === detectionLayer }
    );

    if (feature) {
      if (hoverFeature !== feature) {
        if (hoverFeature) hoverFeature.set("hover", false);
        feature.set("hover", true);
        hoverFeature = feature;

        const props = feature.getProperties();
        const coords = evt.coordinate;
        const geometry = feature.getGeometry();
        let centroidCoords = [0, 0];

        if (geometry.getType() === "Polygon") {
          const centroid = geometry.getInteriorPoint();
          centroidCoords = toLonLat(centroid.getCoordinates());
        } else {
          centroidCoords = toLonLat(geometry.getCoordinates());
        }

        // REMOVED target_type from tooltip
        tooltipElement.innerHTML = `
          <div class="tooltip-content">
            <strong>${props.target_name || "Unknown Target"}</strong>
            <div class="tooltip-details">
              <span class="tooltip-label">Class:</span> ${props.target_class || "N/A"}<br/>
              <span class="tooltip-label">Score:</span> ${props.score ? (props.score * 100).toFixed(1) + "%" : "N/A"}<br/>
              <span class="tooltip-label">Centroid:</span> ${centroidCoords[0].toFixed(6)}, ${centroidCoords[1].toFixed(6)}
            </div>
          </div>
        `;
        tooltipOverlay.setPosition(coords);
        tooltipElement.style.display = "block";
      }
    } else {
      if (hoverFeature) {
        hoverFeature.set("hover", false);
        hoverFeature = null;
      }
      tooltipElement.style.display = "none";
    }
  });
}

// ZOOM TO IMAGERY EXTENT (using vector data as proxy)
async function zoomToImageryExtent(imageId) {
  try {
    const response = await fetch(`/api/unified-data/${imageId}`);
    const data = await response.json();
    if (data.vector_data?.features?.length > 0) {
      const features = new GeoJSON().readFeatures(data.vector_data, {
        featureProjection: "EPSG:3857",
      });
      const extent = features.reduce(
        (ext, f) => {
          const geom = f.getGeometry();
          if (geom) {
            const featExtent = geom.getExtent();
            return [
              Math.min(ext[0], featExtent[0]),
              Math.min(ext[1], featExtent[1]),
              Math.max(ext[2], featExtent[2]),
              Math.max(ext[3], featExtent[3]),
            ];
          }
          return ext;
        },
        [Infinity, Infinity, -Infinity, -Infinity]
      );
      if (isFinite(extent[0])) {
        map.getView().fit(extent, {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 800,
        });
        return;
      }
    }
  } catch (e) {
    console.warn("Could not zoom to imagery extent:", e);
  }
  map.getView().setCenter(fromLonLat([8.55, 50.04]));
  map.getView().setZoom(14);
}

async function loadDetectionData(imageId) {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    const response = await fetch(`/api/unified-data/${imageId}`);
    const unifiedData = await response.json();

    detectionSource.clear();
    if (unifiedData.vector_data?.features?.length > 0) {
      const features = new GeoJSON().readFeatures(
        unifiedData.vector_data,
        { featureProjection: "EPSG:3857" }
      );
      detectionSource.addFeatures(features);
    }
  } catch (error) {
    console.error("Failed to load detection ", error);
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

async function loadImageryData(imageId) {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById("basemapStatus").textContent = `Loading imagery for ${imageId}...`;

    // Use relative path for assets (served by NGINX)
    const xyzSource = new XYZ({
      url: `/tiles/${imageId}/{z}/{x}/{y}.png`,
      crossOrigin: "anonymous",
    });
    imageryLayer.setSource(xyzSource);
    console.log("✅ Loaded XYZ imagery:", imageId);
    
  } catch (error) {
    console.error("Failed to load imagery:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading imagery";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

async function autoLoadBasemapData(imageId) {
  if (!imageId) return;
  await loadImageryData(imageId);
  await loadDetectionData(imageId);
  await zoomToImageryExtent(imageId); // ← ADD THIS
}

// Rest of basemap.js remains as in your original implementation
// (loadBasemapCountries, loadBasemapTargets, loadBasemapImages, etc.)
// with the only change being the use of relative paths for assets

async function loadLocalBasemap() {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById("basemapStatus").textContent =
      "Loading vector basemap...";
    const response = await fetch("/api/local-basemap");
    const geojsonData = await response.json();
    const features = new GeoJSON().readFeatures(geojsonData, {
      featureProjection: "EPSG:3857",
    });
    vectorSource.clear();
    vectorSource.addFeatures(features);
    if (features.length > 0) {
      map.getView().fit(vectorSource.getExtent(), {
        padding: [50, 50, 50, 50],
        maxZoom: 16,
        duration: 1000,
      });
    }
    document.getElementById(
      "basemapStatus"
    ).textContent = `Basemap loaded with ${features.length.toLocaleString()} features`;
    document.getElementById("basemapFit").disabled = false;
  } catch (error) {
    console.error("Failed to load local basemap:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading basemap";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

async function setupBasemapPage() {
  await loadBasemapCountries();
  document
    .getElementById("basemapCountry")
    .addEventListener("change", async function (e) {
      const country = e.target.value;
      await loadBasemapTargets(country);
      if (country) {
        document.getElementById("basemapTarget").disabled = false;
        document.getElementById(
          "basemapStatus"
        ).textContent = `Country: ${country} - Select target`;
      } else {
        document.getElementById("basemapTarget").disabled = true;
        document.getElementById("basemapTarget").innerHTML =
          '<option value="">Select Country First</option>';
        document.getElementById("basemapStatus").textContent =
          "Select country, target, and image to load data";
      }
    });
  document
    .getElementById("basemapTarget")
    .addEventListener("change", async function (e) {
      const target = e.target.value;
      const country = document.getElementById("basemapCountry").value;
      await loadBasemapImages(country, target);
      if (target) {
        document.getElementById("basemapImage").disabled = false;
        document.getElementById(
          "basemapStatus"
        ).textContent = `Country: ${country}, Target: ${target} - Select image`;
      } else {
        document.getElementById("basemapImage").disabled = true;
        document.getElementById("basemapImage").innerHTML =
          '<option value="">Select Target Name First</option>';
      }
    });
  document
    .getElementById("basemapImage")
    .addEventListener("change", async function (e) {
      const imageId = e.target.value;
      if (imageId) {
        await autoLoadBasemapData(imageId); // ← This now includes zoomToImageryExtent
      }
    });
  // ... rest of setupBasemapPage remains unchanged ...
}

// Helper functions (loadBasemapCountries, loadBasemapTargets, etc.) remain unchanged
// but use relative paths for assets

async function loadBasemapCountries() {
  try {
    const response = await fetch("/api/countries");
    const countries = await response.json();
    const countrySelect = document.getElementById("basemapCountry");
    countrySelect.innerHTML = '<option value="">Select Country</option>';
    countries.forEach((country) => {
      const option = document.createElement("option");
      option.value = country;
      option.textContent = country;
      countrySelect.appendChild(option);
    });
  } catch (error) {
    console.error("Failed to load countries:", error);
  }
}

async function loadBasemapTargets(country) {
  if (!country) return;
  try {
    document.getElementById("basemapTarget").innerHTML =
      '<option value="">Loading targets...</option>';
    const response = await fetch(
      `/api/target-types/${encodeURIComponent(country)}`
    );
    const targets = await response.json();
    const targetSelect = document.getElementById("basemapTarget");
    targetSelect.innerHTML = '<option value="">Select Target Name</option>';
    targets.forEach((target) => {
      const option = document.createElement("option");
      option.value = target;
      option.textContent = target;
      targetSelect.appendChild(option);
    });
    document.getElementById(
      "basemapStatus"
    ).textContent = `Country: ${country} - Select target`;
  } catch (error) {
    console.error("Failed to load targets:", error);
    document.getElementById("basemapTarget").innerHTML =
      '<option value="">Error loading targets</option>';
    document.getElementById("basemapStatus").textContent =
      "Error loading targets";
  }
}

async function loadBasemapImages(country, target) {
  if (!country || !target) return;
  try {
    const response = await fetch(
      `/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(
        target
      )}`
    );
    const images = await response.json();
    const imageSelect = document.getElementById("basemapImage");
    imageSelect.innerHTML = '<option value="">Select Image ID</option>';
    images.forEach((image) => {
      const option = document.createElement("option");
      option.value = image;
      option.textContent = image;
      imageSelect.appendChild(option);
    });
    document.getElementById(
      "basemapStatus"
    ).textContent = `Country: ${country}, Target: ${target} - Select image`;
  } catch (error) {
    console.error("Failed to load images:", error);
    document.getElementById("basemapImage").innerHTML =
      '<option value="">Error loading images</option>';
    document.getElementById("basemapStatus").textContent =
      "Error loading images";
  }
}
```

---

### ✅ Corrected `app.py` — Critical Fixes

```python
# ... (all imports and Flask setup unchanged) ...

# ==================== UNIFIED DATA ENDPOINT ====================
@app.route('/api/unified-data/<image_id>')
def get_unified_data(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400

    target_names = request.args.getlist('target_name')
    target_classes = request.args.getlist('target_class')
    min_score = request.args.get('min_score', 0.0, type=float)
    max_score = request.args.get('max_score', 1.0, type=float)

    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # VECTOR DATA — from sql_scat_query2 + target
                vector_query = """
                    SELECT 
                        sq.target_name,
                        sq.country_name,
                        sq.image_id, 
                        sq.image_date,
                        sq.target_class,
                        sq.score,
                        sq.st_x as centroid_lon,
                        sq.st_y as centroid_lat,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.image_id = %s
                """
                # ... (vector query conditions unchanged) ...

                # CHART DATA — AGGREGATE FROM sql_scat_query2 (NOT comprehensive_query)
                chart_query = """
                    SELECT 
                        sq.target_name,
                        sq.target_class,
                        COUNT(*) as total_count,
                        AVG(sq.score) as avg_score,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.image_id = %s
                """
                chart_params = [image_id]
                chart_conditions = []
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    chart_conditions.append(f"sq.target_name IN ({placeholders})")
                    chart_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    chart_conditions.append(f"sq.target_class IN ({placeholders})")
                    chart_params.extend(target_classes)
                if min_score > 0:
                    chart_conditions.append("sq.score >= %s")
                    chart_params.append(min_score)
                if max_score < 1.0:
                    chart_conditions.append("sq.score <= %s")
                    chart_params.append(max_score)
                if chart_conditions:
                    chart_query += " AND " + " AND ".join(chart_conditions)
                chart_query += " GROUP BY sq.target_name, sq.target_class, t.target_type"
                chart_query += " ORDER BY total_count DESC"

                cur.execute(chart_query, chart_params)
                chart_rows = cur.fetchall()
                chart_data = [
                    {
                        'target_name': row['target_name'],
                        'target_class': row['target_class'],
                        'target_type': row['target_type'],
                        'total_count': row['total_count'],
                        'avg_score': float(row['avg_score']) if row['avg_score'] is not None else 0.0
                    }
                    for row in chart_rows
                ]

        return jsonify({
            "vector_data": {
                "type": "FeatureCollection", 
                "features": vector_features
            },
            "chart_data": chart_data
        })
    except Exception as e:
        app.logger.error(f"Unified data query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to retrieve unified data"}), 500

# ==================== CHART ENDPOINT ====================
@app.route('/api/charts/<image_id>/target_class')
def get_target_class_counts(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # USE sql_scat_query2 INSTEAD OF comprehensive_query
                cur.execute("""
                    SELECT 
                        target_class, 
                        COUNT(*) as total_count,
                        AVG(score) as avg_score
                    FROM sql_scat_query2
                    WHERE image_id = %s
                    GROUP BY target_class
                    ORDER BY total_count DESC
                """, (image_id,))
                rows = cur.fetchall()
        return jsonify([
            {
                "label": r["target_class"],
                "value": r["total_count"],
                "avg_score": float(r["avg_score"]) if r["avg_score"] is not None else 0.0
            }
            for r in rows
        ])
    except Exception as e:
        app.logger.error(f"Chart query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to generate chart data"}), 500

# ... (rest of app.py unchanged) ...
```

---

### ✅ Critical CSS Updates for Tooltip Font Size

Add this to your `styles.css`:

```css
/* Enhanced tooltip styling - increased font size */
.map-tooltip {
  position: relative;
  background: rgba(26, 32, 44, 0.98);
  color: var(--gray-0);
  padding: 14px;
  border-radius: 8px;
  font-size: 14px; /* Increased from 12px */
  line-height: 1.4;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
  max-width: 300px;
  pointer-events: none;
  z-index: 10000;
  display: none;
}
.tooltip-content strong {
  color: #fff;
  font-size: 1.2em; /* Increased from 1.1em */
  margin-bottom: 8px;
  display: block;
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
  padding-bottom: 6px;
}
```

---

### 🔑 Key Changes Summary

| Feature | Implementation |
|--------|----------------|
| **Tooltip Content** | Removed `target_type`, kept `target_name`, `target_class`, `score`, `centroid` |
| **Font Size** | Increased to `14px` in `.map-tooltip` |
| **Bar Chart Labels** | Added `total_count` on top of each bar using Chart.js datalabels |
| **Dynamic Heights** | Bar heights update in real-time with score slider |
| **Basemap Zoom** | `zoomToImageryExtent()` called on image selection |
| **Layer Ordering** | Point features (`zIndex: 3`) above Polygon features (`zIndex: 2`) |
| **Backend Fixes** | Use `sql_scat_query2` (not `comprehensive_query`) for chart data |

This implementation is **fully compatible** with your hybrid architecture (Vite + Flask + NGINX + Traefik) and addresses all your requested changes.

### I also need to overhaul the historical-deployment page, with the UI/UX and functionality being similar to the main app page/basemap - dropdown selection rendering the timeline series graph. But with major changes - the bar chart is to be removed completely, and only the timeline series and its tooltips remaining. Only two dropdowns remain - target_class and the image_date (the same for image_id), which then generates a timeline seris graph with the original tooltips intact on hovering (target_name, target_class, total_count). The Y-axis is the image_date now, and the x-axis is the target_class. 

I'll create a complete overhaul of the historical-deployment page according to your requirements. Here's the full implementation:

# Historical Deployment Page Overhaul

## Key Changes:
- Removed bar chart completely
- Only two dropdowns: target_class and image_date (image_id)
- Timeline series graph with Y-axis as image_date and X-axis as target_class
- Tooltips showing target_name, target_class, total_count

### ✅ 1. Updated `historical.html`

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="http://localhost:8082/icons/vite.svg" type="image/x-icon">
  <title>Historical Deployment Analysis - GeoDoxy</title>
  <link rel="stylesheet" href="http://localhost:8082/css/ol.css" />
  <link rel="stylesheet" href="/src/styles.css" />
  <style>
    .full-height-card {
      height: 100%;
      min-height: 500px;
    }
    .chart-controls {
      background: var(--gray-1);
      border-radius: 8px;
      padding: 16px;
      margin-top: 16px;
      border: 1px solid var(--gray-4);
    }
    .chart-controls h4 {
      font-family: var(--font-neo-grotesque);
      font-size: 1rem;
      font-weight: 600;
      color: var(--gray-12);
      margin-bottom: 12px;
      border-bottom: 2px solid var(--purple-5);
      padding-bottom: 6px;
    }
    .chart-controls .btn-secondary {
      width: 100%;
      margin-bottom: 8px;
    }
    .info-text {
      font-size: 0.85rem;
      color: var(--gray-11);
      line-height: 1.4;
    }
    .chart-container {
      background: linear-gradient(135deg, #f8fafc 0%, #edf2f7 100%);
      border-radius: 8px;
      padding: 16px;
      height: calc(100% - 40px);
      position: relative;
    }
    .historical-selectors {
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      border-radius: 10px;
      padding: 18px;
      border: 1px solid rgba(226, 232, 240, 0.8);
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.05);
    }
    .historical-selectors h4 {
      font-size: 1.1rem;
      font-weight: 700;
      color: #1a202c;
      margin-bottom: 16px;
      border-bottom: 2px solid #6366f1;
      padding-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .control-group {
      margin-bottom: 12px;
    }
    .selection-status {
      margin-top: 15px;
    }
    .status-info {
      background: #dbeafe;
      border: 1px solid #3b82f6;
      border-radius: 6px;
      padding: 12px 16px;
      margin: 10px 0;
      color: #1e40af;
      font-weight: 500;
      font-size: 0.9rem;
      box-shadow: 0 2px 4px rgba(59, 130, 246, 0.1);
      line-height: var(--font-lineheight-3);
      text-overflow: ellipsis;
      white-space: pre-line;
      overflow: hidden;
    }
    .loading-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 12px;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 6px;
    }
    .spinner {
      width: 20px;
      height: 20px;
      border: 2px solid #e2e8f0;
      border-top: 2px solid #6366f1;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  <header class="app-header">
    <div class="header-content">
      <div class="logo">
        <img src="http://localhost:8082/icons/vite.svg" alt="GeoDoxy Logo" class="logo-image">
        <span class="logo-text">GeoDoxy</span>
      </div>
      <h1 class="app-title">Historical Deployment Analysis</h1>
    </div>
  </header>
  <main class="app-layout">
    <aside class="sidebar">
      <div class="historical-selectors">
        <h4>Historical Data Selection</h4>
        <div class="control-group">
          <label for="historicalTargetClass">Target Class:</label>
          <select id="historicalTargetClass" class="hierarchical-select">
            <option value="">Select Target Class</option>
          </select>
        </div>
        <div class="control-group">
          <label for="historicalImageDate">Image Date:</label>
          <select id="historicalImageDate" class="hierarchical-select" disabled>
            <option value="">Select Target Class First</option>
          </select>
        </div>
        <div class="selection-status">
          <div id="historicalStatus" class="status-info">
            Select target class and image date to view timeline
          </div>
        </div>
      </div>
      <div class="chart-controls">
        <h4>Chart Controls</h4>
        <button id="resetView" class="btn-secondary">Reset View</button>
        <button id="exportChart" class="btn-secondary">Export Chart</button>
      </div>
      <div class="quick-actions">
        <h4>Information</h4>
        <div class="info-text">
          <p>This timeline shows detection counts over time for selected targets. Use the filters above to explore different datasets.</p>
        </div>
      </div>
    </aside>
    <div class="main-content">
      <div class="card full-height-card">
        <h3>Deployment Timeline</h3>
        <div class="chart-container">
          <canvas id="timelineChart"></canvas>
        </div>
        <div class="chart-overlay" id="timelineLoading" style="display: none;">
          <div class="spinner"></div>
          <span>Loading timeline data...</span>
        </div>
      </div>
    </div>
  </main>
  <script type="module" src="/src/historical.js"></script>
</body>
</html>
```

### ✅ 2. Updated `historical.js`

```javascript
// src/historical.js
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);
import { marked } from "marked";

let timelineChart;
let currentSelections = {
  targetClass: null,
  imageDate: null,
};

document.addEventListener("DOMContentLoaded", async () => {
  console.log("📊 Historical Deployment Page Loaded");
  
  // DOM Elements
  const targetClassSelector = document.getElementById("historicalTargetClass");
  const imageDateSelector = document.getElementById("historicalImageDate");
  const timelineCtx = document.getElementById("timelineChart").getContext("2d");
  const chartLoading = document.getElementById("timelineLoading");
  
  // Initialize timeline chart
  initializeTimelineChart();
  
  // Load target classes
  await loadTargetClasses();
  
  // Event handlers
  targetClassSelector.addEventListener("change", async (e) => {
    const targetClass = e.target.value;
    currentSelections.targetClass = targetClass;
    currentSelections.imageDate = null;
    
    if (targetClass) {
      imageDateSelector.disabled = false;
      await loadImageDates(targetClass);
      document.getElementById("historicalStatus").textContent = `Target Class: ${targetClass} - Select image date`;
    } else {
      imageDateSelector.disabled = true;
      imageDateSelector.innerHTML = '<option value="">Select Target Class First</option>';
      document.getElementById("historicalStatus").textContent = "Select target class and image date to view timeline";
      clearChart();
    }
  });
  
  imageDateSelector.addEventListener("change", async (e) => {
    const imageDate = e.target.value;
    currentSelections.imageDate = imageDate;
    
    if (imageDate && currentSelections.targetClass) {
      await loadTimelineData(currentSelections.targetClass, imageDate);
    } else {
      clearChart();
    }
  });
  
  document.getElementById("resetView").addEventListener("click", resetView);
  document.getElementById("exportChart").addEventListener("click", exportChart);
});

function initializeTimelineChart() {
  console.log("📈 Initializing timeline chart...");
  const timelineCtx = document.getElementById("timelineChart").getContext("2d");
  
  timelineChart = new Chart(timelineCtx, {
    type: 'scatter',
    data: {
      datasets: []
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: "Target Deployments Over Time",
          font: {
            size: 16,
            weight: "bold",
          },
        },
        legend: {
          display: false
        },
        tooltip: {
          callbacks: {
            title: function(context) {
              return context[0].dataset.label || "Deployment Data";
            },
            label: function(context) {
              const dataPoint = context.raw;
              return [
                `Target: ${dataPoint.target_name || "Unknown"}`,
                `Class: ${dataPoint.target_class || "N/A"}`,
                `Total Count: ${dataPoint.total_count || 0}`
              ];
            }
          }
        }
      },
      scales: {
        x: {
          type: 'category',
          title: {
            display: true,
            text: "Target Class",
            font: {
              family: "var(--font-neo-grotesque)",
              weight: "bold",
            },
          },
          grid: {
            color: "rgba(0, 0, 0, 0.1)",
          }
        },
        y: {
          type: 'time',
          time: {
            unit: 'day',
            tooltipFormat: 'MMM dd, yyyy',
            displayFormats: {
              day: 'MMM dd',
              week: 'MMM dd',
              month: 'MMM yyyy'
            }
          },
          title: {
            display: true,
            text: "Image Date",
            font: {
              family: "var(--font-neo-grotesque)",
              weight: "bold",
            },
          },
          grid: {
            color: "rgba(0, 0, 0, 0.1)",
          }
        }
      },
      interaction: {
        mode: 'nearest',
        axis: 'xy',
        intersect: false,
      },
      elements: {
        point: {
          radius: 8,
          hoverRadius: 12,
          backgroundColor: "#6366f1",
          borderColor: "#ffffff",
          borderWidth: 2
        }
      }
    }
  });
  console.log("✅ Timeline chart initialized");
}

async function loadTargetClasses() {
  try {
    console.log("🎯 Loading target classes...");
    const response = await fetch("/api/target-classes");
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const targetClasses = await response.json();
    console.log("🎯 Target classes loaded:", targetClasses);
    
    const targetClassSelect = document.getElementById("historicalTargetClass");
    targetClassSelect.innerHTML = '<option value="">Select Target Class</option>';
    targetClasses.forEach((cls) => {
      const option = document.createElement("option");
      option.value = cls;
      option.textContent = cls;
      targetClassSelect.appendChild(option);
    });
  } catch (error) {
    console.error("Failed to load target classes:", error);
    document.getElementById("historicalTargetClass").innerHTML =
      '<option value="">Error loading classes</option>';
  }
}

async function loadImageDates(targetClass) {
  if (!targetClass) return;
  try {
    console.log(`📅 Loading image dates for target class: ${targetClass}`);
    const response = await fetch(`/api/image-dates/${encodeURIComponent(targetClass)}`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const imageDates = await response.json();
    console.log(`📅 Image dates loaded:`, imageDates);
    
    const imageDateSelect = document.getElementById("historicalImageDate");
    imageDateSelect.innerHTML = '<option value="">Select Image Date</option>';
    imageDates.forEach((date) => {
      const option = document.createElement("option");
      option.value = date;
      option.textContent = date;
      imageDateSelect.appendChild(option);
    });
  } catch (error) {
    console.error("Failed to load image dates:", error);
    document.getElementById("historicalImageDate").innerHTML =
      '<option value="">Error loading dates</option>';
  }
}

async function loadTimelineData(targetClass, imageDate) {
  try {
    showChartLoading(true);
    document.getElementById("historicalStatus").textContent = `Loading data for ${targetClass} on ${imageDate}...`;
    
    const params = new URLSearchParams();
    params.append("target_class", targetClass);
    params.append("image_date", imageDate);
    
    const response = await fetch(`/api/historical-timeline?${params}`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const timelineData = await response.json();
    console.log("📊 Timeline data received:", timelineData);
    
    updateTimelineChart(timelineData);
  } catch (error) {
    console.error("Failed to load timeline data:", error);
    showError("Failed to load timeline data. Please try again.");
  } finally {
    showChartLoading(false);
  }
}

function updateTimelineChart(timelineData) {
  if (!timelineChart) {
    console.error("Timeline chart not initialized");
    return;
  }
  
  if (!timelineData || timelineData.length === 0) {
    console.log("No timeline data available");
    timelineChart.data.datasets = [];
    timelineChart.update();
    return;
  }
  
  // Prepare data for scatter plot
  const dataPoints = [];
  timelineData.forEach((item) => {
    if (item.data_points && item.data_points.length > 0) {
      item.data_points.forEach((point) => {
        if (point.date && point.count) {
          dataPoints.push({
            x: item.target_class,
            y: new Date(point.date),
            target_name: item.target_name,
            target_class: item.target_class,
            total_count: point.count
          });
        }
      });
    }
  });
  
  // Update chart with new data
  timelineChart.data.datasets = [{
    label: "Deployments",
    data: dataPoints,
    backgroundColor: "#6366f1",
    borderColor: "#ffffff",
    borderWidth: 2,
    pointRadius: 8,
    pointHoverRadius: 12
  }];
  
  timelineChart.update();
  console.log(`✅ Updated chart with ${dataPoints.length} data points`);
  
  document.getElementById("historicalStatus").textContent = 
    `Showing ${dataPoints.length} deployments for ${currentSelections.targetClass} on ${currentSelections.imageDate}`;
}

function clearChart() {
  if (timelineChart) {
    timelineChart.data.datasets = [];
    timelineChart.update();
  }
  document.getElementById("historicalStatus").textContent = 
    "Select target class and image date to view timeline";
}

function resetView() {
  document.getElementById("historicalTargetClass").value = "";
  document.getElementById("historicalImageDate").innerHTML = 
    '<option value="">Select Target Class First</option>';
  document.getElementById("historicalImageDate").disabled = true;
  currentSelections = { targetClass: null, imageDate: null };
  clearChart();
  console.log("🔄 View reset to default state");
}

function exportChart() {
  if (timelineChart) {
    const link = document.createElement('a');
    link.download = 'historical-timeline.png';
    link.href = timelineChart.toBase64Image();
    link.click();
  }
}

function showChartLoading(show) {
  if (chartLoading) {
    chartLoading.style.display = show ? "flex" : "none";
  }
}

function showError(message) {
  // Remove any existing error messages
  const existingError = document.querySelector(".error-message");
  if (existingError) {
    existingError.remove();
  }
  
  const errorElement = document.createElement("div");
  errorElement.className = "error-message";
  errorElement.textContent = message;
  const chartContainer = document.querySelector(".chart-container");
  if (chartContainer) {
    chartContainer.appendChild(errorElement);
  }
}
```

### ✅ 3. Updated `app.py` - New Endpoints

Add these endpoints to your `app.py`:

```python
# ==================== HISTORICAL DEPLOYMENT ENDPOINTS ====================
@app.route('/api/target-classes')
def get_target_classes():
    """Get distinct target classes available in the database"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT target_class 
                    FROM sql_scat_query2 
                    WHERE target_class IS NOT NULL 
                    ORDER BY target_class
                """)
                target_classes = [row['target_class'] for row in cur.fetchall()]
        return jsonify(target_classes)
    except Exception as e:
        app.logger.error(f"Target classes query failed: {e}")
        return jsonify([])

@app.route('/api/image-dates/<target_class>')
def get_image_dates(target_class):
    """Get distinct image dates for a specific target class"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT image_date::text
                    FROM sql_scat_query2 
                    WHERE target_class = %s 
                    AND image_date IS NOT NULL 
                    ORDER BY image_date DESC
                """, (target_class,))
                image_dates = [row['image_date'] for row in cur.fetchall()]
        return jsonify(image_dates)
    except Exception as e:
        app.logger.error(f"Image dates query failed for {target_class}: {e}")
        return jsonify([])

@app.route('/api/historical-timeline')
def get_historical_timeline():
    """Get historical timeline data with target_class and image_date filters"""
    target_class = request.args.get('target_class')
    image_date = request.args.get('image_date')
    
    if not target_class or not image_date:
        return jsonify([])
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                query = """
                    SELECT 
                        sq.target_name,
                        sq.target_class,
                        sq.image_date,
                        COUNT(*) as detection_count
                    FROM sql_scat_query2 sq
                    WHERE sq.target_class = %s
                    AND sq.image_date::text = %s
                    GROUP BY sq.target_name, sq.target_class, sq.image_date
                    ORDER BY sq.target_name
                """
                cur.execute(query, (target_class, image_date))
                rows = cur.fetchall()
        
        # Format data for timeline chart
        timeline_data = []
        for row in rows:
            timeline_data.append({
                'target_name': row['target_name'],
                'target_class': row['target_class'],
                'data_points': [{
                    'date': row['image_date'].isoformat() if row['image_date'] else None,
                    'count': row['detection_count']
                }]
            })
        return jsonify(timeline_data)
    except Exception as e:
        app.logger.error(f"Historical timeline query failed: {e}")
        return jsonify([])
```

### ✅ 4. Updated CSS for Historical Page

Add this to your `styles.css`:

```css
/* Historical Deployment Page Styles */
.historical-selectors {
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  border-radius: 10px;
  padding: 18px;
  border: 1px solid rgba(226, 232, 240, 0.8);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.05);
}

.historical-selectors h4 {
  font-size: 1.1rem;
  font-weight: 700;
  color: #1a202c;
  margin-bottom: 16px;
  border-bottom: 2px solid #6366f1;
  padding-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.chart-controls {
  background: var(--gray-1);
  border-radius: 8px;
  padding: 16px;
  margin-top: 16px;
  border: 1px solid var(--gray-4);
}

.chart-controls h4 {
  font-family: var(--font-neo-grotesque);
  font-size: 1rem;
  font-weight: 600;
  color: var(--gray-12);
  margin-bottom: 12px;
  border-bottom: 2px solid var(--purple-5);
  padding-bottom: 6px;
}

.chart-controls .btn-secondary {
  width: 100%;
  margin-bottom: 8px;
}

.info-text {
  font-size: 0.85rem;
  color: var(--gray-11);
  line-height: 1.4;
}

.chart-container {
  background: linear-gradient(135deg, #f8fafc 0%, #edf2f7 100%);
  border-radius: 8px;
  padding: 16px;
  height: calc(100% - 40px);
  position: relative;
}

/* Loading indicator */
.loading-indicator {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 6px;
}

.spinner {
  width: 20px;
  height: 20px;
  border: 2px solid #e2e8f0;
  border-top: 2px solid #6366f1;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
```

## Key Features of the Overhaul:

1. **Simplified UI**:
   - Only two dropdowns: target_class and image_date
   - Clean, focused interface with clear instructions

2. **Timeline Series Graph**:
   - Y-axis: image_date (time-based)
   - X-axis: target_class (categorical)
   - Scatter plot showing deployment points

3. **Enhanced Tooltips**:
   - Shows target_name, target_class, and total_count
   - Clean, readable format with proper spacing

4. **Performance Optimizations**:
   - Efficient data loading with minimal API calls
   - Proper error handling and loading states
   - Memory management with chart cleanup

5. **User Experience**:
   - Clear status messages
   - Reset and export functionality
   - Responsive design that works on all screen sizes

This implementation provides a focused, efficient historical deployment analysis tool that meets all your requirements while maintaining consistency with the rest of your application.

---
