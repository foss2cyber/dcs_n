A separate app (no Docker - for now) for the backend that uses NGINX for serving/proxying static assets and implementing CORS on a system for any/all other web apps using those assets on the same/other systems on an air-gapped/offline/pricate network with a windows shared drive enabled as well

While there is no single pre-built app that does exactly what you describe, a manual setup using Nginx for Windows is the standard and most direct method for this task. You do not need Docker for this. You will configure Nginx to serve static files from the Windows shared drive and add the necessary configuration for CORS. 
Here is an overview of how to achieve your goal.
1. Install Nginx for Windows
The official Nginx website provides a native version for Windows that does not require the Linux-based Docker environment. 
Download the latest mainline version of Nginx for Windows from nginx.org/en/docs/windows.html.
Unpack the ZIP file to a location like C:\nginx.
You can start Nginx from the command line by running nginx.exe in the directory you unpacked it to. 
2. Configure Nginx to serve static assets
The primary step is to edit the nginx.conf file, located in the conf directory of your Nginx installation. You will need to create a server block that listens for requests and directs them to the shared drive. 
Example configuration snippet:
nginx
server {
    listen 80;
    server_name your_network_hostname; # Use the hostname or IP address of the server
    
    location /static_assets/ {
        alias //server_name/path/to/shared_folder/; # Use alias for a local-path mapping
        # Add a trailing slash to both the URI prefix and the directory path.
    }
}


Important:
Path format: The alias directive needs a UNC (Universal Naming Convention) path that Windows understands. Make sure the Nginx service has the proper read permissions for the network location.
Trailing slash: Note the trailing slash at the end of both the location and alias directive paths. This is important for Nginx to resolve file paths correctly. 
3. Implement CORS
To allow web applications on other systems (origins) to fetch assets from your Nginx server, you must configure CORS headers. This is also done within the nginx.conf file. 
Example CORS headers for Nginx:
You would add these headers inside the location block that serves your static assets:
nginx
server {
    listen 80;
    server_name your_network_hostname;

    location /static_assets/ {
        alias //server_name/path/to/shared_folder/;
        
        # --- CORS headers ---
        if ($request_method = 'OPTIONS') {
            add_header 'Access-Control-Allow-Origin' '*'; # Or specify a specific origin
            add_header 'Access-Control-Allow-Methods' 'GET, OPTIONS';
            add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
            add_header 'Access-Control-Max-Age' 1728000;
            add_header 'Content-Type' 'text/plain; charset=UTF-8';
            add_header 'Content-Length' 0;
            return 204;
        }
        add_header 'Access-Control-Allow-Origin' '*';
        # ---------------------
    }
}


Explanation:
The if ($request_method = 'OPTIONS') block handles "preflight" requests that some browsers send before the actual request.
Access-Control-Allow-Origin: * allows any domain to access the resources. For an air-gapped network, this is often acceptable. For more security, you can specify an IP address or hostname.
Other headers specify which methods (GET), headers, and the maximum time the preflight result can be cached (Access-Control-Max-Age). 
4. Running Nginx automatically (optional)
By default, Nginx for Windows does not run as a Windows service. To have it start automatically, you can use a third-party tool like NSSM (the Non-Sucking Service Manager). 
Summary
The setup you've described is a standard reverse proxy and static file-serving configuration that Nginx excels at. Since you are on a private, air-gapped network with Windows file-sharing, the native Nginx for Windows is the most direct solution without relying on a containerization platform like Docker.
