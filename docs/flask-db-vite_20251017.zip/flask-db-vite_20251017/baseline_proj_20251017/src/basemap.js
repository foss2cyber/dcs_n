// src/basemap.js - COMPLETE WORKING VERSION
import OlMap from "/node_modules/ol/Map.js";
import View from "/node_modules/ol/View.js";
import TileLayer from "/node_modules/ol/layer/Tile.js";
import VectorLayer from "/node_modules/ol/layer/Vector.js";
import VectorSource from "/node_modules/ol/source/Vector.js";
import GeoJSON from "/node_modules/ol/format/GeoJSON.js";
import XYZ from "/node_modules/ol/source/XYZ.js";
import { fromLonLat } from "/node_modules/ol/proj.js";
import { defaults as defaultControls } from "/node_modules/ol/control.js";
import ScaleLine from "/node_modules/ol/control/ScaleLine.js";
import Rotate from "/node_modules/ol/control/Rotate.js";
import {
  Style,
  Stroke,
  Fill,
  Circle as CircleStyle,
} from "/node_modules/ol/style.js";

let map;
let vectorSource, vectorLayer;
let imageryLayer;
let detectionSource, detectionLayer;

document.addEventListener("DOMContentLoaded", async function () {
  initializeMap();
  await setupBasemapPage();
  await loadLocalBasemap();
});

function initializeMap() {
  // Vector source for basemap (ALWAYS VISIBLE)
  vectorSource = new VectorSource();

  vectorLayer = new VectorLayer({
    source: vectorSource,
    style: new Style({
      stroke: new Stroke({
        color: "#3388ff",
        width: 2,
      }),
      fill: new Fill({
        color: "rgba(51, 136, 255, 0.1)",
      }),
      image: new CircleStyle({
        radius: 4,
        fill: new Fill({
          color: "#3388ff",
        }),
        stroke: new Stroke({
          color: "white",
          width: 1,
        }),
      }),
    }),
    zIndex: 2, // Vector layer on top
  });

  // Detection layer for target data
  detectionSource = new VectorSource();
  detectionLayer = new VectorLayer({
    source: detectionSource,
    style: new Style({
      image: new CircleStyle({
        radius: 6,
        fill: new Fill({
          color: "#ff4444",
        }),
        stroke: new Stroke({
          color: "white",
          width: 2,
        }),
      }),
    }),
    zIndex: 3, // Detection layer above everything
  });

  // Imagery layer (toggleable)
  imageryLayer = new TileLayer({
    source: null,
    visible: true, // Start with imagery visible
    zIndex: 1, // Imagery below vectors
  });

  map = new OlMap({
    target: "basemap",
    layers: [imageryLayer, vectorLayer, detectionLayer], // Order: imagery -> vectors -> detections
    view: new View({
      center: fromLonLat([0, 0]),
      zoom: 12,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" }),
      new Rotate({ autoHide: false }),
    ]),
  });

  console.log(
    "🗺️ Basemap initialized with layer ordering: Imagery -> Vector Basemap -> Detections"
  );
}

async function loadLocalBasemap() {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById("basemapStatus").textContent =
      "Loading vector basemap...";

    const response = await fetch("/api/local-basemap");
    const geojsonData = await response.json();

    const features = new GeoJSON().readFeatures(geojsonData, {
      featureProjection: "EPSG:3857",
    });

    vectorSource.clear();
    vectorSource.addFeatures(features);

    if (features.length > 0) {
      map.getView().fit(vectorSource.getExtent(), {
        padding: [50, 50, 50, 50],
        maxZoom: 16,
        duration: 1000,
      });
    }

    console.log("✅ Loaded local basemap with", features.length, "features");
    document.getElementById(
      "basemapStatus"
    ).textContent = `Basemap loaded with ${features.length.toLocaleString()} features`;
    document.getElementById("basemapFit").disabled = false;
  } catch (error) {
    console.error("Failed to load local basemap:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading basemap";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

async function setupBasemapPage() {
  await loadBasemapCountries();

  // Country selection
  document
    .getElementById("basemapCountry")
    .addEventListener("change", async function (e) {
      const country = e.target.value;
      await loadBasemapTargets(country);

      if (country) {
        document.getElementById("basemapTarget").disabled = false;
        document.getElementById(
          "basemapStatus"
        ).textContent = `Country: ${country} - Select target`;
      } else {
        document.getElementById("basemapTarget").disabled = true;
        document.getElementById("basemapTarget").innerHTML =
          '<option value="">Select Country First</option>';
        document.getElementById("basemapStatus").textContent =
          "Select country, target, and image to load data";
      }
    });

  // Target selection
  document
    .getElementById("basemapTarget")
    .addEventListener("change", async function (e) {
      const target = e.target.value;
      const country = document.getElementById("basemapCountry").value;
      await loadBasemapImages(country, target);

      if (target) {
        document.getElementById("basemapImage").disabled = false;
        document.getElementById(
          "basemapStatus"
        ).textContent = `Country: ${country}, Target: ${target} - Select image`;
      } else {
        document.getElementById("basemapImage").disabled = true;
        document.getElementById("basemapImage").innerHTML =
          '<option value="">Select Target Name First</option>';
      }
    });

  // Image selection - AUTO-LOAD imagery and detections
  document
    .getElementById("basemapImage")
    .addEventListener("change", async function (e) {
      const imageId = e.target.value;
      if (imageId) {
        await loadImageryData(imageId);
        await loadDetectionData(imageId);
      }
    });

  // Layer controls - radio buttons
  document.querySelectorAll('input[name="basemapLayer"]').forEach((radio) => {
    radio.addEventListener("change", function (e) {
      updateLayerVisibility(e.target.value);
      updateLayerButtons(e.target.value);
    });
  });

  // Quick layer buttons
  document.querySelectorAll(".layer-btn").forEach((btn) => {
    btn.addEventListener("click", function () {
      document
        .querySelectorAll(".layer-btn")
        .forEach((b) => b.classList.remove("active"));
      this.classList.add("active");
      const layerType = this.getAttribute("data-layer");
      updateLayerVisibility(layerType);
      updateLayerRadios(layerType);
    });
  });

  // Opacity control - applies to imagery only
  document
    .getElementById("basemapOpacity")
    .addEventListener("input", function () {
      const opacity = parseInt(this.value) / 100;
      imageryLayer.setOpacity(opacity);
      document.getElementById("basemapOpacityValue").textContent =
        this.value + "%";
    });

  // Quick actions
  document.getElementById("basemapFit").addEventListener("click", function () {
    if (vectorSource.getFeatures().length > 0) {
      map.getView().fit(vectorSource.getExtent(), {
        padding: [50, 50, 50, 50],
        maxZoom: 16,
        duration: 1000,
      });
    }
  });

  document
    .getElementById("basemapClear")
    .addEventListener("click", function () {
      // Clear imagery and detections but KEEP basemap vectors
      imageryLayer.setSource(null);
      detectionSource.clear();
      document.getElementById("basemapCountry").value = "";
      document.getElementById("basemapTarget").innerHTML =
        '<option value="">Select Country First</option>';
      document.getElementById("basemapTarget").disabled = true;
      document.getElementById("basemapImage").innerHTML =
        '<option value="">Select Target Name First</option>';
      document.getElementById("basemapImage").disabled = true;
      document.getElementById("basemapStatus").textContent =
        "Basemap loaded - select data to overlay imagery";
      document.getElementById("basemapFit").disabled = false;

      // Reset layer controls
      updateLayerVisibility("both");
      updateLayerRadios("both");
      updateLayerButtons("both");
    });

  document
    .getElementById("refreshBasemap")
    .addEventListener("click", async function () {
      await loadLocalBasemap();
    });
}

function updateLayerVisibility(layerType) {
  switch (layerType) {
    case "vector":
      vectorLayer.setVisible(true);
      imageryLayer.setVisible(false);
      detectionLayer.setVisible(true);
      break;
    case "imagery":
      vectorLayer.setVisible(false);
      imageryLayer.setVisible(true);
      detectionLayer.setVisible(true);
      break;
    case "both":
      vectorLayer.setVisible(true);
      imageryLayer.setVisible(true);
      detectionLayer.setVisible(true);
      break;
  }
  console.log(`🎛️ Layer visibility updated: ${layerType}`);
}

function updateLayerButtons(layerType) {
  document.querySelectorAll(".layer-btn").forEach((btn) => {
    btn.classList.remove("active");
    if (btn.getAttribute("data-layer") === layerType) {
      btn.classList.add("active");
    }
  });
}

function updateLayerRadios(layerType) {
  document.querySelectorAll('input[name="basemapLayer"]').forEach((radio) => {
    radio.checked = radio.value === layerType;
  });
}

async function loadBasemapCountries() {
  try {
    const response = await fetch("/api/countries");
    const countries = await response.json();

    const countrySelect = document.getElementById("basemapCountry");
    countrySelect.innerHTML = '<option value="">Select Country</option>';

    countries.forEach((country) => {
      const option = document.createElement("option");
      option.value = country;
      option.textContent = country;
      countrySelect.appendChild(option);
    });

    console.log("✅ Loaded countries:", countries.length);
  } catch (error) {
    console.error("Failed to load countries:", error);
  }
}

async function loadBasemapTargets(country) {
  if (!country) return;

  try {
    document.getElementById("basemapTarget").innerHTML =
      '<option value="">Loading targets...</option>';

    const response = await fetch(
      `/api/target-types/${encodeURIComponent(country)}`
    );
    const targets = await response.json();

    const targetSelect = document.getElementById("basemapTarget");
    targetSelect.innerHTML = '<option value="">Select Target Name</option>';

    targets.forEach((target) => {
      const option = document.createElement("option");
      option.value = target;
      option.textContent = target;
      targetSelect.appendChild(option);
    });

    document.getElementById(
      "basemapStatus"
    ).textContent = `Country: ${country} - Select target`;
    console.log("✅ Loaded targets for", country, ":", targets.length);
  } catch (error) {
    console.error("Failed to load targets:", error);
    document.getElementById("basemapTarget").innerHTML =
      '<option value="">Error loading targets</option>';
    document.getElementById("basemapStatus").textContent =
      "Error loading targets";
  }
}

async function loadBasemapImages(country, target) {
  if (!country || !target) return;

  try {
    const response = await fetch(
      `/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(
        target
      )}`
    );
    const images = await response.json();

    const imageSelect = document.getElementById("basemapImage");
    imageSelect.innerHTML = '<option value="">Select Image ID</option>';

    images.forEach((image) => {
      const option = document.createElement("option");
      option.value = image;
      option.textContent = image;
      imageSelect.appendChild(option);
    });

    document.getElementById(
      "basemapStatus"
    ).textContent = `Country: ${country}, Target: ${target} - Select image`;
    console.log("✅ Loaded images for", country, target, ":", images.length);
  } catch (error) {
    console.error("Failed to load images:", error);
    document.getElementById("basemapImage").innerHTML =
      '<option value="">Error loading images</option>';
    document.getElementById("basemapStatus").textContent =
      "Error loading images";
  }
}

async function loadImageryData(imageId) {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById(
      "basemapStatus"
    ).textContent = `Loading imagery for ${imageId}...`;

    // Try XYZ tiles (most reliable)
    const xyzSource = new XYZ({
      url: `/tiles/${imageId}/{z}/{x}/{y}.png`,
      crossOrigin: "anonymous",
    });

    imageryLayer.setSource(xyzSource);

    console.log("✅ Loaded XYZ imagery for:", imageId);
    document.getElementById(
      "basemapStatus"
    ).textContent = `Imagery loaded: ${imageId}`;
  } catch (error) {
    console.error("Failed to load imagery:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading imagery - using basemap only";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

async function loadDetectionData(imageId) {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById(
      "basemapStatus"
    ).textContent = `Loading detection data for ${imageId}...`;

    const response = await fetch(`/api/unified-data/${imageId}`);
    const unifiedData = await response.json();

    detectionSource.clear();

    if (unifiedData.vector_data && unifiedData.vector_data.features) {
      const features = new GeoJSON().readFeatures(unifiedData.vector_data, {
        featureProjection: "EPSG:3857",
      });
      detectionSource.addFeatures(features);

      console.log("✅ Loaded detection data:", features.length, "features");
      document.getElementById(
        "basemapStatus"
      ).textContent = `Data loaded: ${imageId} (${features.length} detections)`;
    } else {
      console.log("ℹ️ No detection data available for:", imageId);
      document.getElementById(
        "basemapStatus"
      ).textContent = `Imagery loaded: ${imageId} (no detections)`;
    }
  } catch (error) {
    console.error("Failed to load detection data:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading detection data";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}

// Add map click interaction for feature info
function setupMapInteractions() {
  map.on("click", function (evt) {
    const feature = map.forEachFeatureAtPixel(evt.pixel, function (feature) {
      return feature;
    });

    if (feature) {
      const props = feature.getProperties();
      console.log("📍 Map click - Feature:", props);
      // You can add a popup or tooltip here
    }
  });
}

// Initialize map interactions
setTimeout(setupMapInteractions, 1000);
