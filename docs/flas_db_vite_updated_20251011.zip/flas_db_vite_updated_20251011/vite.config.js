import { defineConfig } from "vite";

export default defineConfig({
  optimizeDeps: {
    include: ["ol", "geotiff", "chart.js", "marked", "proj4"],
  },
  root: "./",
  base: "./", // critical for offline
  publicDir: "public", // explicit (default, but clear)
  build: {
    outDir: "dist",
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: "index.html",
      },
    },
  },
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:5000",
      "/reports": "http://localhost:5000",
      "/health": "http://localhost:5000",
      // Note: /cogs and /tiles are served statically from ./public/
      // So no proxy needed for them in dev if you place COGs/tiles in ./public/
    },
  },
});
