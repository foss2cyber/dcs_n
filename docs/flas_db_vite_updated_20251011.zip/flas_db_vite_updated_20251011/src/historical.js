// Import Chart.js locally (same as in main.js)
import { Chart, registerables } from "/node_modules/chart.js/dist/chart.esm.js";
Chart.register(...registerables);

// Copy all historical page specific code from your previous inline script
let timelineChart, distributionChart;
let historicalData = [];

// Initialize charts
function initializeCharts() {
  const timelineCtx = document.getElementById("timelineChart").getContext("2d");
  const distributionCtx = document
    .getElementById("distributionChart")
    .getContext("2d");

  timelineChart = new Chart(timelineCtx, {
    type: "line",
    data: {
      labels: [],
      datasets: [],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: "Target Deployments Over Time",
        },
        legend: {
          position: "top",
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: "Number of Detections",
          },
        },
        x: {
          title: {
            display: true,
            text: "Date",
          },
        },
      },
    },
  });

  distributionChart = new Chart(distributionCtx, {
    type: "bar",
    data: {
      labels: [],
      datasets: [
        {
          label: "Total Detections",
          data: [],
          backgroundColor: [
            "#3366CC",
            "#DC3912",
            "#FF9900",
            "#109618",
            "#990099",
            "#0099C6",
            "#DD4477",
            "#66AA00",
          ],
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: "Detection Distribution by Target Type",
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: "Number of Detections",
          },
        },
      },
    },
  });
}

// Load historical data
async function loadHistoricalData() {
  try {
    const response = await fetch("/api/historical-data");
    historicalData = await response.json();
    updateCharts("all");
    updateStatistics("all");
  } catch (error) {
    console.error("Failed to load historical data:", error);
  }
}

// Update charts based on timeframe
function updateCharts(timeframe) {
  if (!historicalData.length) return;

  const filteredData = filterDataByTimeframe(historicalData, timeframe);
  updateTimelineChart(filteredData);
  updateDistributionChart(filteredData);
}

// Filter data by timeframe
function filterDataByTimeframe(data, timeframe) {
  const now = new Date();
  let cutoffDate = new Date();

  switch (timeframe) {
    case "7d":
      cutoffDate.setDate(now.getDate() - 7);
      break;
    case "30d":
      cutoffDate.setDate(now.getDate() - 30);
      break;
    case "90d":
      cutoffDate.setDate(now.getDate() - 90);
      break;
    case "all":
    default:
      return data;
  }

  return data.filter((item) => {
    const itemDate = new Date(item.date);
    return itemDate >= cutoffDate;
  });
}

// Update timeline chart
function updateTimelineChart(data) {
  // Group data by date and target class
  const dateMap = {};
  const targetClasses = [...new Set(data.map((item) => item.target_class))];

  data.forEach((item) => {
    if (!dateMap[item.date]) {
      dateMap[item.date] = {};
    }
    dateMap[item.date][item.target_class] = item.total_count;
  });

  const dates = Object.keys(dateMap).sort();
  const datasets = targetClasses.map((targetClass, index) => {
    const colors = ["#3366CC", "#DC3912", "#FF9900", "#109618", "#990099"];
    return {
      label: targetClass,
      data: dates.map((date) => dateMap[date][targetClass] || 0),
      borderColor: colors[index % colors.length],
      backgroundColor: colors[index % colors.length] + "20",
      tension: 0.4,
      fill: false,
    };
  });

  timelineChart.data.labels = dates;
  timelineChart.data.datasets = datasets;
  timelineChart.update();
}

// Update distribution chart
function updateDistributionChart(data) {
  // Aggregate by target class
  const classMap = {};
  data.forEach((item) => {
    if (!classMap[item.target_class]) {
      classMap[item.target_class] = 0;
    }
    classMap[item.target_class] += item.total_count;
  });

  const labels = Object.keys(classMap);
  const values = Object.values(classMap);

  distributionChart.data.labels = labels;
  distributionChart.data.datasets[0].data = values;
  distributionChart.update();
}

// Update statistics
function updateStatistics(timeframe) {
  const filteredData = filterDataByTimeframe(historicalData, timeframe);

  // Total detections
  const totalDetections = filteredData.reduce(
    (sum, item) => sum + item.total_count,
    0
  );
  document.getElementById("totalDetections").textContent =
    totalDetections.toLocaleString();

  // Unique target types
  const uniqueTargets = new Set(filteredData.map((item) => item.target_class))
    .size;
  document.getElementById("uniqueTargets").textContent = uniqueTargets;

  // Average daily detections
  const uniqueDays = new Set(filteredData.map((item) => item.date)).size;
  const avgDaily =
    uniqueDays > 0 ? (totalDetections / uniqueDays).toFixed(1) : 0;
  document.getElementById("avgDaily").textContent = avgDaily;

  // Peak day
  const dayMap = {};
  filteredData.forEach((item) => {
    if (!dayMap[item.date]) {
      dayMap[item.date] = 0;
    }
    dayMap[item.date] += item.total_count;
  });

  let peakDay = "-";
  let peakCount = 0;
  Object.entries(dayMap).forEach(([date, count]) => {
    if (count > peakCount) {
      peakCount = count;
      peakDay = new Date(date).toLocaleDateString();
    }
  });

  document.getElementById("peakDay").textContent = peakDay;
}

// Event listeners for timeframe controls
document.querySelectorAll(".control-btn").forEach((btn) => {
  btn.addEventListener("click", function () {
    document
      .querySelectorAll(".control-btn")
      .forEach((b) => b.classList.remove("active"));
    this.classList.add("active");

    const timeframe = this.dataset.timeframe;
    updateCharts(timeframe);
    updateStatistics(timeframe);
  });
});

// Initialize
document.addEventListener("DOMContentLoaded", function () {
  initializeCharts();
  loadHistoricalData();
});
