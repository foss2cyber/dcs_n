import os
import re
import json
import datetime
import logging
from flask import Flask, jsonify, request, send_from_directory
import psycopg2
from psycopg2.extras import RealDictCursor
from config import Config

app = Flask(__name__,
    static_folder='public',
    static_url_path=''
)
app.config.from_object(Config)
os.makedirs(app.config['REPORTS_DIR'], exist_ok=True)

def get_db():
    return psycopg2.connect(
        dsn=app.config['DB_URL'],
        cursor_factory=RealDictCursor
    )

# ==================== UPDATED HIERARCHICAL DROPDOWN ENDPOINTS ====================

@app.route('/api/countries')
def get_countries():
    """Get distinct countries available in the database"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get countries from comprehensive_query (most reliable source)
                cur.execute("""
                    SELECT DISTINCT country_name 
                    FROM comprehensive_query 
                    WHERE country_name IS NOT NULL 
                    ORDER BY country_name
                """)
                countries = [row['country_name'] for row in cur.fetchall()]
                
                # Fallback to target table if no countries found
                if not countries:
                    cur.execute("""
                        SELECT DISTINCT country_name 
                        FROM target 
                        WHERE country_name IS NOT NULL 
                        ORDER BY country_name
                    """)
                    countries = [row['country_name'] for row in cur.fetchall()]
                
        return jsonify(countries)
        
    except Exception as e:
        app.logger.error(f"Countries query failed: {e}")
        return jsonify([])

@app.route('/api/target-types/<country>')
def get_target_types(country):
    """Get distinct target NAMES (not classes) for a specific country"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get target NAMES from comprehensive_query instead of target_class
                cur.execute("""
                    SELECT DISTINCT target_name 
                    FROM comprehensive_query 
                    WHERE country_name = %s 
                    AND target_name IS NOT NULL 
                    ORDER BY target_name
                """, (country,))
                target_names = [row['target_name'] for row in cur.fetchall()]
                
        return jsonify(target_names)
        
    except Exception as e:
        app.logger.error(f"Target names query failed for {country}: {e}")
        return jsonify([])

@app.route('/api/image-ids/<country>/<target_name>')
def get_image_ids(country, target_name):
    """Get distinct image IDs for a specific country and target NAME"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT image_id 
                    FROM comprehensive_query 
                    WHERE country_name = %s 
                    AND target_name = %s 
                    AND image_id IS NOT NULL 
                    ORDER BY image_id
                """, (country, target_name))
                image_ids = [row['image_id'] for row in cur.fetchall()]
                
        return jsonify(image_ids)
        
    except Exception as e:
        app.logger.error(f"Image IDs query failed for {country}/{target_name}: {e}")
        return jsonify([])


# ==================== UPDATED UNIFIED FILTERING ENDPOINT ====================

@app.route('/api/unified-data/<image_id>')
def get_unified_data(image_id):
    """
    Unified endpoint that returns both vector data AND chart data with same filters
    Updated to use target_name in hierarchical system but preserve target_class in data
    """
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    
    # Get filter parameters
    target_names = request.args.getlist('target_name')  # Changed from target_class
    target_classes = request.args.getlist('target_class')  # Keep for backward compatibility
    min_score = request.args.get('min_score', 0.0, type=float)
    max_score = request.args.get('max_score', 1.0, type=float)
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # ========== VECTOR DATA (for map) ==========
                vector_query = """
                    SELECT 
                        f.id,
                        f.target_class,
                        f.score,
                        ST_AsGeoJSON(f.target_geom) AS geometry,
                        ST_X(ST_Centroid(f.target_geom)) AS centroid_lon,
                        ST_Y(ST_Centroid(f.target_geom)) AS centroid_lat,
                        t.target_name,
                        t.country_name
                    FROM findings f
                    LEFT JOIN target t ON f.target_class = t.target_type
                    WHERE f.image_id = %s
                """
                vector_params = [image_id]
                vector_conditions = []
                
                # Apply filters to vector data - use target_name instead of target_class
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    vector_conditions.append(f"t.target_name IN ({placeholders})")
                    vector_params.extend(target_names)
                elif target_classes:  # Fallback for backward compatibility
                    placeholders = ','.join(['%s'] * len(target_classes))
                    vector_conditions.append(f"f.target_class IN ({placeholders})")
                    vector_params.extend(target_classes)
                    
                if min_score > 0:
                    vector_conditions.append("f.score >= %s")
                    vector_params.append(min_score)
                    
                if max_score < 1.0:
                    vector_conditions.append("f.score <= %s")
                    vector_params.append(max_score)
                
                if vector_conditions:
                    vector_query += " AND " + " AND ".join(vector_conditions)
                
                cur.execute(vector_query, vector_params)
                vector_rows = cur.fetchall()
                
                # Format vector features
                vector_features = []
                for row in vector_rows:
                    if row["geometry"]:
                        geometry_data = json.loads(row["geometry"])
                    else:
                        geometry_data = {
                            "type": "Point", 
                            "coordinates": [
                                row["centroid_lon"] or 8.55, 
                                row["centroid_lat"] or 50.04
                            ]
                        }
                    
                    vector_features.append({
                        "type": "Feature",
                        "geometry": geometry_data,
                        "properties": {
                            "id": row["id"],
                            "target_class": row["target_class"],
                            "target_name": row["target_name"],
                            "country_name": row["country_name"],
                            "score": float(row["score"]) if row["score"] is not None else None,
                            "centroid": [
                                float(row["centroid_lon"]) if row["centroid_lon"] is not None else 8.55,
                                float(row["centroid_lat"]) if row["centroid_lat"] is not None else 50.04
                            ]
                        }
                    })
                
                # ========== CHART DATA (for statistics) ==========
                chart_query = """
                    SELECT 
                        t.target_name,
                        f.target_class,
                        COUNT(*) as total_count,
                        AVG(f.score) as avg_score
                    FROM findings f
                    LEFT JOIN target t ON f.target_class = t.target_type
                    WHERE f.image_id = %s
                """
                chart_params = [image_id]
                chart_conditions = []
                
                # Apply same filters to chart data
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    chart_conditions.append(f"t.target_name IN ({placeholders})")
                    chart_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    chart_conditions.append(f"f.target_class IN ({placeholders})")
                    chart_params.extend(target_classes)
                    
                if min_score > 0:
                    chart_conditions.append("f.score >= %s")
                    chart_params.append(min_score)
                    
                if max_score < 1.0:
                    chart_conditions.append("f.score <= %s")
                    chart_params.append(max_score)
                
                if chart_conditions:
                    chart_query += " AND " + " AND ".join(chart_conditions)
                
                chart_query += " GROUP BY t.target_name, f.target_class ORDER BY total_count DESC"
                
                cur.execute(chart_query, chart_params)
                chart_rows = cur.fetchall()
                
                # Format chart data with target_name as primary identifier
                chart_data = [
                    {
                        'target_name': row['target_name'],
                        'target_class': row['target_class'],
                        'total_count': row['total_count'],
                        'avg_score': float(row['avg_score']) if row['avg_score'] is not None else 0.0
                    }
                    for row in chart_rows
                ]
        
        return jsonify({
            "vector_data": {
                "type": "FeatureCollection",
                "features": vector_features
            },
            "chart_data": chart_data
        })
        
    except Exception as e:
        app.logger.error(f"Unified data query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to retrieve unified data"}), 500

# ==================== UPDATED EXISTING ENDPOINTS ====================

@app.route('/api/filtered-data/<image_id>')
def get_filtered_data(image_id):
    """Advanced filtering endpoint - UPDATED with correct schema"""
    target_classes = request.args.getlist('target_class')
    min_score = request.args.get('min_score', 0.0, type=float)
    max_score = request.args.get('max_score', 1.0, type=float)
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                query = """
                    SELECT 
                        target_class,
                        COUNT(*) as total_count,
                        AVG(score) as avg_score
                    FROM findings 
                    WHERE image_id = %s
                """
                params = [image_id]
                conditions = []
                
                if target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    conditions.append(f"target_class IN ({placeholders})")
                    params.extend(target_classes)
                    
                if min_score > 0:
                    conditions.append("score >= %s")
                    params.append(min_score)
                    
                if max_score < 1.0:
                    conditions.append("score <= %s")
                    params.append(max_score)
                
                if conditions:
                    query += " AND " + " AND ".join(conditions)
                
                query += " GROUP BY target_class ORDER BY total_count DESC"
                
                cur.execute(query, params)
                rows = cur.fetchall()
                
                result = [
                    {
                        'target_class': row['target_class'],
                        'target_name': row['target_class'],
                        'total_count': row['total_count'],
                        'avg_score': float(row['avg_score']) if row['avg_score'] is not None else 0.0
                    }
                    for row in rows
                ]
                
                return jsonify(result)
                
    except Exception as e:
        app.logger.error(f"Filtered data query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to retrieve filtered data"}), 500

# ==================== UPDATED FILTER OPTIONS ENDPOINT ====================

@app.route('/api/filter-options/<image_id>')
def get_filter_options(image_id):
    """Get available filter values - UPDATED to use target_name"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get unique target names from target table (more meaningful)
                cur.execute("""
                    SELECT DISTINCT t.target_name 
                    FROM findings f
                    LEFT JOIN target t ON f.target_class = t.target_type
                    WHERE f.image_id = %s AND t.target_name IS NOT NULL 
                    ORDER BY t.target_name
                """, (image_id,))
                names_result = cur.fetchall()
                target_names = [row['target_name'] for row in names_result]
                
                # Get unique target classes from findings (for backward compatibility)
                cur.execute(
                    "SELECT DISTINCT target_class FROM findings WHERE image_id = %s ORDER BY target_class", 
                    (image_id,)
                )
                classes = [row['target_class'] for row in cur.fetchall()]
                
                # Get score range from findings
                cur.execute(
                    "SELECT MIN(score) as min_score, MAX(score) as max_score FROM findings WHERE image_id = %s",
                    (image_id,)
                )
                score_result = cur.fetchone()
                
        return jsonify({
            'target_names': target_names or [],  # Primary filter now
            'target_classes': classes or [],     # Keep for compatibility
            'score_range': {
                'min': float(score_result['min_score']) if score_result and score_result['min_score'] is not None else 0.0,
                'max': float(score_result['max_score']) if score_result and score_result['max_score'] is not None else 1.0
            }
        })
        
    except Exception as e:
        app.logger.error(f"Filter options query failed for {image_id}: {e}")
        return jsonify({
            'target_names': [],
            'target_classes': [],
            'score_range': {'min': 0.0, 'max': 1.0}
        })

# ==================== EXISTING WORKING ENDPOINTS (UNCHANGED) ====================

# ==================== COMPREHENSIVE HEALTH CHECK ENDPOINT =====================
@app.route('/health')
def health_check():
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'version': '1.0.0-rc.3'
    }
    
    # Check database connectivity
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT 1')
        health_status['database'] = 'connected'
    except Exception as e:
        health_status['database'] = 'disconnected'
        health_status['status'] = 'unhealthy'
        health_status['database_error'] = str(e)

    # Add directory counting function
    def count_image_id_directories(directory):
        """Count the number of image_id directories (layers) in tiles directory"""
        try:
            if not os.path.exists(directory):
                return 0
            # Count only immediate subdirectories (image_id folders)
            items = os.listdir(directory)
            dir_count = sum(1 for item in items if os.path.isdir(os.path.join(directory, item)))
            return dir_count
        except OSError:
            return 0
    
    # Add recursive file counting function (keep for other directories)
    def count_recursive_files(directory, extension):
        count = 0
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith(extension):
                    count += 1
        return count
    
    # Check essential directories
    essential_dirs = {
        'reports_dir': app.config['REPORTS_DIR'],
        'cogs_dir': 'public/cogs',
        'tiles_dir': 'public/tiles'
    }
    
    for dir_name, dir_path in essential_dirs.items():
        if os.path.exists(dir_path) and os.path.isdir(dir_path):
            health_status[dir_name] = 'exists'
            try:
                if dir_name == 'tiles_dir':
                    # Count image_id directories instead of PNG files
                    layer_count = count_image_id_directories(dir_path)
                    health_status[f'{dir_name}_layer_count'] = layer_count
                    # Optional: also count total tiles for debugging
                    tile_count = count_recursive_files(dir_path, '.png')
                    health_status[f'{dir_name}_tile_count'] = tile_count
                else:
                    file_count = len([f for f in os.listdir(dir_path) if os.path.isfile(os.path.join(dir_path, f))])
                    health_status[f'{dir_name}_file_count'] = file_count
            except OSError:
                health_status[f'{dir_name}_file_count'] = 'unaccessible'
        else:
            health_status[dir_name] = 'missing'
            health_status['status'] = 'degraded'
    
    status_code = 200 if health_status['status'] == 'healthy' else 503
    return jsonify(health_status), status_code

@app.route('/api/data/<image_id>')
def get_geospatial_data(image_id):
    # ... existing geospatial data endpoint unchanged ...
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        f.id,
                        f.target_class,
                        f.score,
                        ST_AsGeoJSON(f.target_geom) AS geometry,
                        ST_X(ST_Centroid(f.target_geom)) AS centroid_lon,
                        ST_Y(ST_Centroid(f.target_geom)) AS centroid_lat
                    FROM findings f
                    WHERE f.image_id = %s
                """, (image_id,))
                rows = cur.fetchall()

        if not rows:
            return jsonify({
                "type": "FeatureCollection",
                "features": []
            })

        features = []
        for row in rows:
            if row["geometry"]:
                geometry_data = json.loads(row["geometry"])
            else:
                geometry_data = {
                    "type": "Point", 
                    "coordinates": [
                        row["centroid_lon"] or 8.55, 
                        row["centroid_lat"] or 50.04
                    ]
                }
            
            features.append({
                "type": "Feature",
                "geometry": geometry_data,
                "properties": {
                    "id": row["id"],
                    "target_class": row["target_class"],
                    "score": float(row["score"]) if row["score"] is not None else None,
                    "centroid": [
                        float(row["centroid_lon"]) if row["centroid_lon"] is not None else 8.55,
                        float(row["centroid_lat"]) if row["centroid_lat"] is not None else 50.04
                    ]
                }
            })

        return jsonify({
            "type": "FeatureCollection",
            "features": features
        })
    except Exception as e:
        app.logger.error(f"Failed to fetch data for image_id={image_id}: {e}")
        return jsonify({"error": "Failed to retrieve geospatial data"}), 500

@app.route('/api/charts/<image_id>/target_class')
def get_target_class_counts(image_id):
    # ... existing chart endpoint unchanged ...
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
        
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        target_class,
                        total_count
                    FROM comprehensive_query
                    WHERE image_id = %s
                """, (image_id,))
                rows = cur.fetchall()
                
        if not rows:
            with get_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        SELECT 
                            target_class,
                            COUNT(*) as total_count
                        FROM findings 
                        WHERE image_id = %s
                        GROUP BY target_class
                    """, (image_id,))
                    rows = cur.fetchall()

        if not rows:
            return jsonify([])

        return jsonify([
            {
                "label": r["target_class"],
                "value": r["total_count"]
            }
            for r in rows
        ])
    except Exception as e:
        app.logger.error(f"Chart query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to generate chart data"}), 500

# ... remaining endpoints unchanged (reports, assets, cogs, frontend serving) ...

@app.route('/api/reports')
def list_reports():
    try:
        files = [f for f in os.listdir(app.config['REPORTS_DIR']) if f.endswith('.txt')]
        return jsonify(sorted(files))
    except Exception as e:
        app.logger.error(f"Failed to list reports: {e}")
        return jsonify({"error": "Cannot list reports"}), 500

@app.route('/api/reports/<filename>')
def get_report(filename):
    if not filename.endswith('.txt'):
        return jsonify({"error": "Only .txt reports are allowed"}), 400
    try:
        return send_from_directory(app.config['REPORTS_DIR'], filename, mimetype='text/plain')
    except FileNotFoundError:
        return jsonify({"error": "Report not found"}), 404
    
# ==================== NEW PAGE ROUTES ====================

@app.route('/api')
def api_documentation_page():
    """Serve the API documentation page"""
    return send_from_directory('.', 'api-docs.html')

@app.route('/health-page')
def health_page():
    """Serve the modern health status page"""
    return send_from_directory('.', 'health.html')

@app.route('/basemap')
def basemap_page():
    """Serve the basemap viewer page"""
    return send_from_directory('.', 'basemap.html')

@app.route('/historical-deployment')  
def historical_deployment_page():
    """Serve the historical deployment analysis page"""
    return send_from_directory('.', 'historical.html')

# ==================== NEW API ENDPOINT ====================

@app.route('/api/historical-data')
def get_historical_data():
    """Time series data for historical deployment analysis"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        image_date,
                        target_class,
                        COUNT(*) as total_count
                    FROM findings
                    GROUP BY image_date, target_class
                    ORDER BY image_date, total_count DESC
                """)
                rows = cur.fetchall()
        
        # Format the data for time series
        formatted_data = []
        for row in rows:
            formatted_data.append({
                'date': row['image_date'].isoformat() if row['image_date'] else None,
                'target_class': row['target_class'],
                'total_count': row['total_count']
            })
            
        return jsonify(formatted_data)
        
    except Exception as e:
        app.logger.error(f"Historical data query failed: {e}")
        return jsonify({"error": "Failed to retrieve historical data"}), 500

@app.route('/assets/<path:filename>')
def serve_assets(filename):
    return send_from_directory('dist/assets', filename)

@app.route('/cogs/<filename>')
def serve_cog(filename):
    if not filename.endswith(('.tiff', '.tif')):
        return jsonify({"error": "Invalid file type"}), 400
    return send_from_directory('public/cogs', filename, mimetype='image/tiff')

@app.route('/')
@app.route('/<path:path>')
def serve_frontend(path='index.html'):
    if os.path.exists(f"dist/{path}"):
        return send_from_directory('dist', path)
    else:
        return send_from_directory('dist', 'index.html')

# ==================== LIST ALL ENDPOINTS ====================

@app.route('/api-list')
def list_endpoints():
    endpoints = []
    for rule in app.url_map.iter_rules():
        endpoints.append({
            "endpoint": rule.endpoint,
            "methods": list(rule.methods),
            "path": str(rule)
        })
    return jsonify(endpoints)

# ==================== ERROR HANDLING ====================

@app.errorhandler(500)
def handle_internal_error(e):
    app.logger.error(f"Internal error: {str(e)}")
    return jsonify({"error": "Internal server error"}), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found"}), 404

@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY' 
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    app.run(host='127.0.0.1', port=5000, debug=True)