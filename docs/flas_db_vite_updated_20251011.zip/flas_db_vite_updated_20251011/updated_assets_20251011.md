# Full, updated main.js, api-docs.html, & styles.css

# FULL UPDATED `main.js`

```javascript
import OlMap from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import XYZ from "ol/source/XYZ";
import GeoTIFFSource from "ol/source/GeoTIFF";
import WebGLTileLayer from "ol/layer/WebGLTile";
import { fromLonLat, toLonLat } from "ol/proj";
import { defaults as defaultInteractions } from "ol/interaction";
import { defaults as defaultControls } from "ol/control";
import ScaleLine from "ol/control/ScaleLine";
import Rotate from "ol/control/Rotate";
import { Style, Stroke, Fill, Circle as CircleStyle, Text } from "ol/style";
import Overlay from "ol/Overlay";

import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

import { marked } from "marked";

let map, vectorSource, barChart;
let cogLayer, xyzLayer;
let currentSelections = {
  country: null,
  targetType: null,
  imageId: null,
};
let currentFilters = {};

document.addEventListener("DOMContentLoaded", async () => {
  // ==================== DEBUG INITIALIZATION ====================
  console.log("🚀 main.js loaded successfully");
  console.log("📋 DOM Elements:", {
    countrySelector: document.getElementById("countrySelector"),
    targetTypeSelector: document.getElementById("targetTypeSelector"),
    imageIdSelector: document.getElementById("imageIdSelector"),
    map: document.getElementById("map"),
  });
  console.log("🗺️ OpenLayers available:", typeof OlMap);
  console.log("📊 Chart.js available:", typeof Chart);
  console.log("📝 Marked available:", typeof marked);

  // ==================== DOM ELEMENTS ====================
  const countrySelector = document.getElementById("countrySelector");
  const targetTypeSelector = document.getElementById("targetTypeSelector");
  const imageIdSelector = document.getElementById("imageIdSelector");
  const loadDataBtn = document.getElementById("loadDataBtn");
  const selectionStatus = document.getElementById("selectionStatus");
  const reportContent = document.getElementById("reportContent");
  const barCanvas = document.getElementById("barChart");
  const opacitySlider = document.getElementById("opacitySlider");
  const fitToDataBtn = document.getElementById("fitToData");
  const clearDataBtn = document.getElementById("clearData");

  if (!countrySelector || !targetTypeSelector || !imageIdSelector) {
    console.error("Required DOM elements not found");
    return;
  }

  // ==================== TOOLTIP SETUP ====================
  const tooltipElement = document.createElement("div");
  tooltipElement.className = "map-tooltip";
  document.body.appendChild(tooltipElement);

  const tooltipOverlay = new Overlay({
    element: tooltipElement,
    positioning: "bottom-center",
    offset: [0, -15],
    stopEvent: false,
  });

  // ==================== MAP SETUP ====================
  vectorSource = new VectorSource();

  const vectorLayer = new VectorLayer({
    source: vectorSource,
    style: function (feature) {
      const geom = feature.getGeometry();
      const isHover = feature.get("hover");
      const props = feature.getProperties();

      const styles = [
        new Style({
          stroke: new Stroke({
            color: isHover ? "#ff4444" : "#3388ff",
            width: isHover ? 4 : 3,
          }),
          fill: new Fill({
            // UPDATED: Transparent fill by default, only show on hover
            color: isHover ? "rgba(255, 68, 68, 0.3)" : "rgba(51, 136, 255, 0)",
          }),
          zIndex: 2,
        }),
      ];

      if (
        geom &&
        (geom.getType() === "Polygon" || geom.getType() === "Point")
      ) {
        try {
          const centroid =
            geom.getType() === "Polygon" ? geom.getInteriorPoint() : geom;

          styles.push(
            new Style({
              geometry: centroid,
              image: new CircleStyle({
                radius: 6,
                fill: new Fill({
                  color: getColorForClass(props.target_class),
                }),
                stroke: new Stroke({
                  color: "white",
                  width: 1.5,
                }),
              }),
              zIndex: 1,
            })
          );
        } catch (e) {
          console.warn("Could not calculate centroid for feature:", e);
        }
      }

      return styles;
    },
  });

  cogLayer = new WebGLTileLayer({
    visible: false,
    opacity: 1,
    source: null,
  });

  xyzLayer = new TileLayer({
    visible: true,
    opacity: 1,
    source: null,
  });

  map = new OlMap({
    target: "map",
    layers: [cogLayer, xyzLayer, vectorLayer],
    view: new View({
      center: fromLonLat([8.55, 50.04]),
      zoom: 12,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" }),
      new Rotate({ autoHide: false }),
    ]),
    interactions: defaultInteractions(),
  });

  // Add this right after your map initialization in main.js
  setTimeout(() => {
    console.log("🗺️ Force map sizing");
    map.updateSize();
    map.render();
  }, 100);

  map.addOverlay(tooltipOverlay);

  // Force map controls to be visible and properly sized
  setTimeout(() => {
    map.updateSize();
    console.log("🗺️ Map controls initialized and visible");
  }, 100);

  // ==================== UPDATED TOOLTIP INTERACTION ====================
  let hoverFeature = null;

  map.on("pointermove", function (evt) {
    const feature = map.forEachFeatureAtPixel(evt.pixel, function (feature) {
      return feature;
    });

    if (feature) {
      if (hoverFeature !== feature) {
        if (hoverFeature) {
          hoverFeature.set("hover", false);
        }
        feature.set("hover", true);
        hoverFeature = feature;

        const props = feature.getProperties();
        const coordinates = evt.coordinate;

        const geometry = feature.getGeometry();
        let centroidCoords = [0, 0];
        if (geometry.getType() === "Polygon") {
          const centroid = geometry.getInteriorPoint();
          centroidCoords = toLonLat(centroid.getCoordinates());
        } else {
          centroidCoords = toLonLat(geometry.getCoordinates());
        }

        // UPDATED TOOLTIP: Use target_name in title, keep target_class in details
        tooltipElement.innerHTML = `
          <div class="tooltip-content">
            <strong>${props.target_name || "Unknown Target"}</strong>
            <div class="tooltip-details">
              <span class="tooltip-label">Class:</span> ${props.target_class || "N/A"}<br/>
              <span class="tooltip-label">Score:</span> ${props.score ? props.score.toFixed(2) : "N/A"}<br/>
              <span class="tooltip-label">Centroid:</span> ${centroidCoords[0].toFixed(6)}, ${centroidCoords[1].toFixed(6)}
            </div>
          </div>
        `;

        tooltipOverlay.setPosition(coordinates);
        tooltipElement.style.display = "block";
      }
    } else {
      if (hoverFeature) {
        hoverFeature.set("hover", false);
        hoverFeature = null;
      }
      tooltipElement.style.display = "none";
    }
  });

  map.on("pointermove", function (evt) {
    const pixel = map.getEventPixel(evt.originalEvent);
    const hit = map.hasFeatureAtPixel(pixel);
    map.getTargetElement().style.cursor = hit ? "pointer" : "";
  });

  map.getViewport().addEventListener("mouseout", function () {
    tooltipElement.style.display = "none";
    if (hoverFeature) {
      hoverFeature.set("hover", false);
      hoverFeature = null;
    }
  });

  // ==================== UPDATED HIERARCHICAL DROPDOWN SYSTEM ====================

  /**
   * Load available countries from backend
   */
  async function loadCountries() {
    try {
      console.log("🌍 Starting loadCountries...");
      showLoadingState("country", "Loading countries...");
      const response = await fetch("/api/countries");
      console.log("🌍 API Response status:", response.status);

      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const countries = await response.json();
      console.log("🌍 Countries data received:", countries);

      countrySelector.innerHTML = '<option value="">Select Country</option>';

      if (countries.length > 0) {
        countries.forEach((country) => {
          const option = document.createElement("option");
          option.value = country;
          option.textContent = country;
          countrySelector.appendChild(option);
        });
        console.log("🌍 Country dropdown populated");
        updateSelectionStatus("Select a country to continue");
      } else {
        countrySelector.innerHTML =
          '<option value="">No countries available</option>';
        updateSelectionStatus("No countries found in database");
      }
    } catch (error) {
      console.error("Failed to load countries:", error);
      countrySelector.innerHTML =
        '<option value="">Error loading countries</option>';
      updateSelectionStatus("Error loading countries");
    } finally {
      console.log(
        "🌍 loadCountries completed, countrySelector disabled:",
        countrySelector.disabled
      );
      hideLoadingState("country");
      console.log(
        "🌍 After hideLoadingState, countrySelector disabled:",
        countrySelector.disabled
      );
    }
  }

  /**
   * Load target NAMES (not types) for selected country
   */
  async function loadTargetTypes(country) {
    if (!country) return;

    try {
      showLoadingState("targetType", "Loading target names...");
      targetTypeSelector.disabled = true;
      imageIdSelector.disabled = true;

      const response = await fetch(
        `/api/target-types/${encodeURIComponent(country)}`
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const targetNames = await response.json();
      targetTypeSelector.innerHTML =
        '<option value="">Select Target Name</option>';

      if (targetNames.length > 0) {
        targetNames.forEach((targetName) => {
          const option = document.createElement("option");
          option.value = targetName;
          option.textContent = targetName;
          targetTypeSelector.appendChild(option);
        });
        targetTypeSelector.disabled = false;
        updateSelectionStatus(`Country: ${country} - Select target name`);
      } else {
        targetTypeSelector.innerHTML =
          '<option value="">No target names available</option>';
        updateSelectionStatus(`No target names found for ${country}`);
      }
    } catch (error) {
      console.error("Failed to load target names:", error);
      targetTypeSelector.innerHTML =
        '<option value="">Error loading target names</option>';
      updateSelectionStatus("Error loading target names");
    } finally {
      hideLoadingState("targetType");
    }
  }

  /**
   * Load image IDs for selected country and target NAME
   */
  async function loadImageIds(country, targetName) {
    if (!country || !targetName) return;

    try {
      showLoadingState("imageId", "Loading image IDs...");
      imageIdSelector.disabled = true;

      const response = await fetch(
        `/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(
          targetName
        )}`
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const imageIds = await response.json();
      imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';

      if (imageIds.length > 0) {
        imageIds.forEach((imageId) => {
          const option = document.createElement("option");
          option.value = imageId;
          option.textContent = imageId;
          imageIdSelector.appendChild(option);
        });
        imageIdSelector.disabled = false;
        updateSelectionStatus(
          `Country: ${country}, Name: ${targetName} - Select image ID`
        );
      } else {
        imageIdSelector.innerHTML =
          '<option value="">No images available</option>';
        updateSelectionStatus(
          `No images found for ${targetName} in ${country}`
        );
      }
    } catch (error) {
      console.error("Failed to load image IDs:", error);
      imageIdSelector.innerHTML =
        '<option value="">Error loading images</option>';
      updateSelectionStatus("Error loading images");
    } finally {
      hideLoadingState("imageId");
      updateLoadButtonState();
    }
  }

  // ==================== UNIFIED DATA LOADING ====================

  /**
   * Load unified data (vector + chart) for selected image ID
   */
  async function loadUnifiedData(imageId, filters = {}) {
    if (!imageId) return;

    try {
      showMainLoading(true);
      updateSelectionStatus(`Loading data for ${imageId}...`);

      const queryParams = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          value.forEach((v) => queryParams.append(key, v));
        } else if (value) {
          queryParams.append(key, value);
        }
      });

      const url = `/api/unified-data/${imageId}?${queryParams}`;
      const response = await fetch(url);

      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const unifiedData = await response.json();

      // Load vector data to map
      await loadVectorData(unifiedData.vector_data);

      // Load chart data
      await loadChartData(unifiedData.chart_data);

      // Load report
      await loadReportData(imageId);

      // Update raster layers
      await updateRasterLayers(imageId);

      // Load filter options for advanced filters
      await loadFilterOptions(imageId);

      updateSelectionStatus(`Data loaded: ${imageId}`);
      fitToDataBtn.disabled = false;
    } catch (error) {
      console.error("Failed to load unified data:", error);
      updateSelectionStatus("Error loading data");
      reportContent.innerHTML =
        '<div class="error-message">Failed to load data. Please try again.</div>';
    } finally {
      showMainLoading(false);
    }
  }

  /**
   * Load vector data to map from unified response
   */
  async function loadVectorData(vectorData) {
    vectorSource.clear();

    if (vectorData && vectorData.features && vectorData.features.length > 0) {
      const features = new GeoJSON().readFeatures(vectorData, {
        featureProjection: "EPSG:3857",
      });
      vectorSource.addFeatures(features);

      // Fit view to data extent
      map.getView().fit(vectorSource.getExtent(), {
        padding: [50, 50, 50, 50],
        maxZoom: 16,
        duration: 1000, // Smooth animation
      });

      console.log(`✅ Loaded ${features.length} vector features`);
    } else {
      console.log("ℹ️ No vector features found");
    }
  }

  /**
   * Load chart data from unified response
   */
  async function loadChartData(chartData) {
    if (barChart) barChart.destroy();

    if (!chartData || chartData.length === 0) {
      console.log("ℹ️ No chart data available");
      return;
    }

    // Chart configuration
    const baseBarThickness = 30;
    const minBarThickness = 20;
    const maxBarThickness = 50;
    const barThickness = Math.max(
      minBarThickness,
      Math.min(maxBarThickness, baseBarThickness - chartData.length * 0.5)
    );

    const accessibleColors = [
      "#3366CC", "#DC3912", "#FF9900", "#109618", 
      "#990099", "#0099C6", "#DD4477", "#66AA00",
      "#B82E2E", "#316395", "#994499", "#22AA99",
      "#AAAA11", "#6633CC", "#E67300", "#8B0707",
      "#651067", "#329262",
    ];

    // UPDATED: Use target_name for labels instead of target_class
    barChart = new Chart(barCanvas, {
      type: "bar",
      data: {
        labels: chartData.map((d) => d.target_name || d.target_class), // Prefer target_name
        datasets: [
          {
            label: "Total Count",
            data: chartData.map((d) => d.total_count),
            backgroundColor: chartData.map(
              (d, i) => accessibleColors[i % accessibleColors.length]
            ),
            borderColor: chartData.map(
              (d, i) => accessibleColors[i % accessibleColors.length]
            ),
            borderWidth: 1,
            barThickness: barThickness,
            maxBarThickness: maxBarThickness,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
            labels: {
              font: {
                family: "'Century Gothic', 'Segoe UI', 'Roboto', 'Arial', sans-serif",
                size: 13,
                weight: "bold",
              },
              color: "#2c3e50",
              usePointStyle: true,
            },
          },
          tooltip: {
            callbacks: {
              // UPDATED: Use target_name in tooltip title
              title: function (context) {
                const dataPoint = chartData[context[0].dataIndex];
                return dataPoint.target_name || dataPoint.target_class || "Unknown";
              },
              label: function (context) {
                const dataPoint = chartData[context.dataIndex];
                return [
                  `Target: ${dataPoint.target_name || "Unknown"}`,
                  `Class: ${dataPoint.target_class || "N/A"}`,
                  `Total Count: ${context.parsed.y}`,
                  `Avg Score: ${dataPoint.avg_score?.toFixed(2) || "N/A"}`,
                ];
              },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Total Count",
              font: {
                family: "'Century Gothic', 'Segoe UI', 'Roboto', 'Arial', sans-serif",
                size: 12,
                weight: "bold",
              },
            },
          },
          x: {
            title: {
              display: true,
              text: "Target Name",
              font: {
                family: "'Century Gothic', 'Segoe UI', 'Roboto', 'Arial', sans-serif",
                size: 12,
                weight: "bold",
              },
            },
          },
        },
      },
    });
  }

  // ==================== FIXED COG RENDERING ====================

  /**
   * Fixed COG layer configuration
   */
  async function updateRasterLayers(imageId) {
    console.log(`🔄 Updating raster layers for: ${imageId}`);

    // Enhanced XYZ source configuration
    const xyzSource = new XYZ({
      url: `/tiles/${imageId}/{z}/{x}/{y}.png`,
      crossOrigin: "anonymous",
      transition: 250,
      minZoom: 12,
      maxZoom: 20,
    });

    xyzLayer.setSource(xyzSource);
    xyzLayer.setVisible(true);
    xyzLayer.setOpacity(parseFloat(opacitySlider?.value || 1));

    // COG detection and configuration - FIXED VERSION
    const cogExtensions = [".tiff", ".tif"];
    let cogSource = null;
    let cogUrl = null;

    for (const ext of cogExtensions) {
      const testUrl = `/cogs/${imageId}${ext}`;
      try {
        const response = await fetch(testUrl, {
          method: "HEAD",
          cache: "no-cache",
          headers: { "Cache-Control": "no-cache" },
        });

        if (response.ok) {
          const contentLength = response.headers.get("content-length");

          if (contentLength && parseInt(contentLength) > 1000) {
            const imgResponse = await fetch(testUrl, {
              method: "GET",
              headers: {
                Range: "bytes=0-1000",
                "Cache-Control": "no-cache",
              },
            });

            if (imgResponse.ok) {
              const buffer = await imgResponse.arrayBuffer();
              const header = new Uint8Array(buffer);

              const isTIFF =
                (header[0] === 0x49 && header[1] === 0x49) ||
                (header[0] === 0x4d && header[1] === 0x4d);

              if (isTIFF) {
                cogUrl = testUrl;
                console.log(`✅ Valid COG found at: ${cogUrl}`);
                break;
              }
            }
          }
        }
      } catch (error) {
        console.log(`COG not found at: ${testUrl}:`, error.message);
      }
    }

    if (cogUrl) {
      try {
        // FIXED COG source configuration - removed problematic options
        cogSource = new GeoTIFFSource({
          sources: [
            {
              url: cogUrl,
              forceXHR: true,
              maxRanges: 10,
            },
          ],
          convertToRGB: true,
          normalize: true,
          wrapX: true,
          interpolate: true,
          maxZoom: 18,
          minZoom: 0,
          transition: 250,
        });

        // Error handling
        cogSource.on("error", (error) => {
          console.error(`❌ COG source error for ${imageId}:`, error);
          fallbackToXYZ();
        });

        cogLayer.setSource(cogSource);
        cogLayer.setOpacity(parseFloat(opacitySlider?.value || 1));

        // Update layer controls
        const cogRadio = document.querySelector('input[value="cog"]');
        if (cogRadio) {
          cogRadio.disabled = false;
          cogRadio.parentElement.style.opacity = "1";
          cogRadio.parentElement.title = "COG imagery available";
        }

        console.log(`✅ COG layer configured for: ${imageId}`);
      } catch (cogError) {
        console.error(`❌ COG layer creation failed for ${imageId}:`, cogError);
        fallbackToXYZ();
      }
    } else {
      console.warn(`❌ No valid COG found for: ${imageId}`);
      fallbackToXYZ();
    }

    function fallbackToXYZ() {
      const cogRadio = document.querySelector('input[value="cog"]');
      const xyzRadio = document.querySelector('input[value="xyz"]');

      if (cogRadio) {
        cogRadio.disabled = true;
        cogRadio.parentElement.style.opacity = "0.6";
        cogRadio.parentElement.title = "COG imagery not available";
      }

      if (xyzRadio && !xyzRadio.checked) {
        xyzRadio.checked = true;
      }

      cogLayer.setVisible(false);
      xyzLayer.setVisible(true);

      console.log(`🔄 Fallback to XYZ tiles for ${imageId}`);
    }
  }

  /**
   * Enhanced layer switching
   */
  function setupLayerControls() {
    document.querySelectorAll('input[name="layer"]').forEach((radio) => {
      radio.addEventListener("change", (e) => {
        const isCog = e.target.value === "cog";
        const cogHasSource = cogLayer.getSource() !== null;

        if (isCog && cogHasSource) {
          console.log("🔄 Switching to COG layer");
          cogLayer.setVisible(true);
          xyzLayer.setVisible(false);

          // Refresh view
          setTimeout(() => {
            map.getView().setZoom(map.getView().getZoom());
          }, 100);
        } else {
          console.log("🔄 Switching to XYZ layer");
          cogLayer.setVisible(false);
          xyzLayer.setVisible(true);
        }
      });
    });
  }

  // Initialize layer controls
  setupLayerControls();

  // ==================== EXISTING FUNCTIONS ====================

  async function loadReportData(imageId) {
    try {
      showReportLoading(true);
      const res = await fetch(`/api/reports/${imageId}.txt`);
      if (!res.ok) throw new Error("Report not found");
      const reportText = await res.text();
      reportContent.innerHTML = marked(reportText);
    } catch (error) {
      console.error("Failed to load report:", error);
      reportContent.innerHTML =
        '<div class="error-message">Report not available for this image.</div>';
    } finally {
      showReportLoading(false);
    }
  }

  // ==================== UPDATED FILTER MANAGEMENT ====================

  async function loadFilterOptions(imageId) {
    try {
      console.log("🎛️ Loading filter options for:", imageId);
      const res = await fetch(`/api/filter-options/${imageId}`);
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      const options = await res.json();

      console.log("🎛️ Filter options received:", options);

      const classFilter = document.getElementById("classFilter");
      if (classFilter) {
        classFilter.innerHTML =
          '<option value="">All Classes</option>' +
          (options.target_classes && Array.isArray(options.target_classes)
            ? options.target_classes
                .map((cls) => `<option value="${cls}">${cls}</option>`)
                .join("")
            : "");
        console.log("🎛️ Class filter populated");
      }

      // UPDATED: Use target_names for the name filter
      const nameFilter = document.getElementById("nameFilter");
      if (nameFilter) {
        nameFilter.innerHTML =
          '<option value="">All Names</option>' +
          (options.target_names && Array.isArray(options.target_names)
            ? options.target_names
                .map((name) => `<option value="${name}">${name}</option>`)
                .join("")
            : "");
        console.log("🎛️ Name filter populated with target_names");
      }

      const scoreRange = document.getElementById("scoreRange");
      const scoreValue = document.getElementById("scoreValue");
      if (scoreRange && scoreValue && options.score_range) {
        scoreRange.min = options.score_range.min || 0;
        scoreRange.max = options.score_range.max || 1;
        scoreRange.value = options.score_range.min || 0;
        scoreValue.textContent = (options.score_range.min || 0).toFixed(1);
        console.log("🎛️ Score range configured");
      }
    } catch (error) {
      console.error("Failed to load filter options:", error);
    }
  }

  function getCurrentFilters() {
    const filters = {};
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");

    // UPDATED: Use target_name as primary filter
    if (nameFilter && nameFilter.value) {
      filters.target_name = [nameFilter.value];
    } else if (classFilter && classFilter.value) {
      filters.target_class = [classFilter.value]; // Fallback
    }
    
    if (scoreRange && parseFloat(scoreRange.value) > 0) {
      filters.min_score = parseFloat(scoreRange.value);
    }

    console.log("🎛️ Current filters:", filters);
    return filters;
  }

  function resetFilters() {
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");
    const scoreValue = document.getElementById("scoreValue");

    if (classFilter) classFilter.value = "";
    if (nameFilter) nameFilter.value = "";
    if (scoreRange) {
      scoreRange.value = scoreRange.min;
      scoreValue.textContent = parseFloat(scoreRange.min).toFixed(1);
    }

    console.log("🎛️ Filters reset");
  }

  // ==================== UI STATE MANAGEMENT ====================

  function updateSelectionStatus(message) {
    if (selectionStatus) {
      selectionStatus.textContent = message;
      selectionStatus.title = message; // Add tooltip for overflow
    }
  }

  function updateLoadButtonState() {
    const hasAllSelections =
      currentSelections.country &&
      currentSelections.targetType &&
      currentSelections.imageId;
    if (loadDataBtn) {
      loadDataBtn.disabled = !hasAllSelections;
    }
  }

  function showLoadingState(selectorType, message) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = true;
      selector.innerHTML = `<option value="">${message}</option>`;
    }
  }

  function hideLoadingState(selectorType) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = false;
      console.log(`✅ ${selectorType} selector enabled`);
    }
  }

  function showMainLoading(show) {
    const mapLoading = document.getElementById("mapLoading");
    const chartLoading = document.getElementById("chartLoading");
    if (mapLoading) mapLoading.style.display = show ? "flex" : "none";
    if (chartLoading) chartLoading.style.display = show ? "flex" : "none";
  }

  function showReportLoading(show) {
    const reportLoading = document.getElementById("reportLoading");
    if (reportLoading) reportLoading.style.display = show ? "flex" : "none";
  }

  function clearAllData() {
    currentSelections = { country: null, targetType: null, imageId: null };
    currentFilters = {};

    // Reset dropdowns
    countrySelector.value = "";
    targetTypeSelector.innerHTML =
      '<option value="">Select Country First</option>';
    targetTypeSelector.disabled = true;
    imageIdSelector.innerHTML =
      '<option value="">Select Target Type First</option>';
    imageIdSelector.disabled = true;

    // Clear data displays
    vectorSource.clear();
    if (barChart) {
      barChart.destroy();
      barChart = null;
    }
    reportContent.innerHTML = `
            <div class="report-placeholder">
                <div class="placeholder-icon">📊</div>
                <p>Select a country, target type, and image ID to view the analysis report.</p>
            </div>
        `;

    // Reset map view
    map.getView().setCenter(fromLonLat([8.55, 50.04]));
    map.getView().setZoom(12);

    // Reset filters
    resetFilters();

    // Update UI states
    updateLoadButtonState();
    fitToDataBtn.disabled = true;
    updateSelectionStatus("Ready to load data");
  }

  // ==================== EVENT HANDLERS ====================

  // Country selection
  countrySelector.addEventListener("change", (e) => {
    const country = e.target.value;
    currentSelections.country = country;
    currentSelections.targetType = null;
    currentSelections.imageId = null;

    // Reset dependent dropdowns
    targetTypeSelector.innerHTML =
      '<option value="">Select Target Name</option>';
    targetTypeSelector.disabled = !country;
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = true;

    if (country) {
      loadTargetTypes(country);
    } else {
      updateSelectionStatus("Select a country to continue");
    }
    updateLoadButtonState();
  });

  // Target type selection
  targetTypeSelector.addEventListener("change", (e) => {
    const targetName = e.target.value;
    currentSelections.targetType = targetName;
    currentSelections.imageId = null;

    // Reset image ID dropdown
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = !targetName;

    if (targetName && currentSelections.country) {
      loadImageIds(currentSelections.country, targetName);
    }
    updateLoadButtonState();
  });

  // Image ID selection
  imageIdSelector.addEventListener("change", (e) => {
    currentSelections.imageId = e.target.value;
    updateLoadButtonState();
    if (currentSelections.imageId) {
      updateSelectionStatus(`Ready to load: ${currentSelections.imageId}`);
    }
  });

  // Load data button
  loadDataBtn.addEventListener("click", () => {
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  });

  // Filter buttons
  const applyFiltersBtn = document.getElementById("applyFilters");
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener("click", () => {
      if (currentSelections.imageId) {
        currentFilters = getCurrentFilters();
        loadUnifiedData(currentSelections.imageId, currentFilters);
      }
    });
  }

  const resetFiltersBtn = document.getElementById("resetFilters");
  if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener("click", () => {
      resetFilters();
      if (currentSelections.imageId) {
        currentFilters = {};
        loadUnifiedData(currentSelections.imageId);
      }
    });
  }

  // Quick actions
  if (fitToDataBtn) {
    fitToDataBtn.addEventListener("click", () => {
      if (vectorSource.getFeatures().length > 0) {
        console.log("🎯 Fitting map to data extent");
        map.getView().fit(vectorSource.getExtent(), {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 1000,
        });
      } else {
        console.log("⚠️ No features to fit to");
      }
    });
  }

  if (clearDataBtn) {
    clearDataBtn.addEventListener("click", clearAllData);
  }

  // Layer and opacity controls
  if (opacitySlider) {
    opacitySlider.addEventListener("input", () => {
      const opacity = parseFloat(opacitySlider.value);
      cogLayer.setOpacity(opacity);
      xyzLayer.setOpacity(opacity);
    });
  }

  // Helper function
  function getColorForClass(targetClass) {
    const colorMap = {
      aircraft: "#3366CC",
      service_vehicle: "#DC3912",
      commercial_airliner: "#FF9900",
      cargo_aircraft: "#109618",
      passenger_airliner: "#990099",
    };
    return colorMap[targetClass] || "#666666";
  }

  // ==================== INITIALIZATION ====================
  await loadCountries();
});
```

# FULL UPDATED `styles.css`

```css
/* ==================== BASE STYLES ==================== */
/* Fix Open Props import path for Vite HMR */
@import '/node_modules/open-props/open-props.min.css';

:root {
  --gap: 16px;
  --sidebar-width: 280px;
  --card-radius: 8px;
  --shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  --header-height: 70px;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: var(--font-system-ui);
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  color: var(--gray-12);
  min-height: 100vh;
  position: relative;
  overflow-x: hidden;
}

/* ==================== HEADER STYLES ==================== */
.app-header {
  background: rgba(255, 255, 255, 0.98);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(226, 232, 240, 0.8);
  padding: 0 var(--gap);
  height: var(--header-height);
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  z-index: 1000;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

.header-content {
  display: flex;
  align-items: center;
  gap: var(--gap);
  width: 100%;
  max-width: 1400px;
  margin: 0 auto;
}

.logo {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 1.5rem;
  font-weight: 800;
  color: var(--indigo-9);
}

.logo-image {
  height: 40px;
  width: auto;
  transition: transform 0.3s ease;
}

.logo-image:hover {
  transform: scale(1.05);
}

.logo-text {
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-weight: 700;
  background: linear-gradient(135deg, var(--indigo-7), var(--purple-6));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.app-title {
  font-size: 1.25rem;
  font-weight: 600;
  color: var(--gray-12);
  margin: 0;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
}

/* ==================== FIXED MAIN APP LAYOUT ==================== */
.app-layout {
  display: grid;
  grid-template-columns: var(--sidebar-width) 1fr;
  grid-template-rows: 1fr auto;
  height: calc(100vh - var(--header-height));
  gap: var(--gap);
  padding: var(--gap);
  max-width: 1400px;
  margin: 0 auto;
}

/* ==================== ENHANCED SIDEBAR STYLES ==================== */
.sidebar {
  background: rgba(255, 255, 255, 0.98);
  backdrop-filter: blur(20px);
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  display: flex;
  flex-direction: column;
  gap: 20px;
  overflow-y: auto;
}

/* Enhanced hierarchical selectors */
.hierarchical-selectors {
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  border-radius: 10px;
  padding: 18px;
  border: 1px solid rgba(226, 232, 240, 0.8);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.05);
}

.hierarchical-selectors h4 {
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 1.1rem;
  font-weight: 700;
  color: #1a202c;
  margin-bottom: 16px;
  border-bottom: 2px solid var(--indigo-5);
  padding-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* Professional select styling */
.hierarchical-select,
.filter-select {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  background: white;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 0.95rem;
  font-weight: 500;
  color: #2d3748;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  appearance: none;
  background-image: url("data:image/svg+xml;charset=US-ASCII,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'><path fill='%23666' d='M2 0L0 2h4zm0 5L0 3h4z'/></svg>");
  background-repeat: no-repeat;
  background-position: right 16px center;
  background-size: 12px;
}

.hierarchical-select:focus,
.filter-select:focus {
  outline: none;
  border-color: var(--indigo-5);
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1), 0 4px 16px rgba(0, 0, 0, 0.1);
  transform: translateY(-1px);
}

.hierarchical-select:hover,
.filter-select:hover {
  border-color: #cbd5e0;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

/* Enhanced option styling */
.hierarchical-select option,
.filter-select option {
  padding: 12px;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 0.9rem;
  word-wrap: break-word;
  white-space: normal;
  max-width: 100%;
  border-bottom: 1px solid #f7fafc;
}

/* Text wrapping for long image IDs */
.hierarchical-select option:checked {
  background: linear-gradient(135deg, var(--indigo-5), var(--indigo-6));
  color: white;
}

/* Enhanced selection status */
.selection-status {
  margin-top: 16px;
  padding: 16px;
  background: linear-gradient(135deg, #ffffff 0%, #f7fafc 100%);
  border-radius: 8px;
  border-left: 4px solid var(--indigo-5);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  border: 1px solid rgba(226, 232, 240, 0.6);
}

.status-info {
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 0.9rem;
  color: #4a5568;
  line-height: 1.5;
  margin-bottom: 12px;
  word-break: break-word;
  white-space: normal;
  font-weight: 500;
}

/* Enhanced load data button */
#loadDataBtn {
  width: 100%;
  padding: 14px 20px;
  font-weight: 700;
  font-size: 1rem;
  border-radius: 8px;
  background: linear-gradient(135deg, var(--indigo-6), var(--indigo-7));
  color: white;
  border: none;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.3);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

#loadDataBtn:not(:disabled):hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
  background: linear-gradient(135deg, var(--indigo-7), var(--indigo-8));
}

#loadDataBtn:disabled {
  background: #a0aec0;
  box-shadow: none;
  transform: none;
  cursor: not-allowed;
}

/* ==================== ENHANCED FILTER SECTIONS ==================== */
.filter-section {
  background: linear-gradient(135deg, #f8fafc 0%, #edf2f7 100%);
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;
  border: 1px solid rgba(226, 232, 240, 0.8);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.05);
}

.filter-section h4 {
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 1.1rem;
  font-weight: 700;
  color: #1a202c;
  margin-bottom: 16px;
  border-bottom: 2px solid var(--orange-5);
  padding-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* ==================== FIXED SLIDER STYLING ==================== */
.score-range-group,
.opacity-control {
  position: relative;
  margin-bottom: 24px;
  padding: 16px;
  background: white;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
}

.score-range-group label,
.opacity-control label {
  display: block;
  margin-bottom: 12px;
  font-weight: 600;
  color: #2d3748;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 0.95rem;
}

/* Enhanced slider containers */
.range-container {
  position: relative;
  margin: 20px 0 8px 0;
}

/* Proper slider value positioning */
.range-labels {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 12px;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 0.85rem;
  color: #718096;
  font-weight: 500;
}

.range-value {
  position: absolute;
  top: -30px;
  font-weight: 700;
  color: var(--indigo-7);
  background: white;
  padding: 4px 8px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #e2e8f0;
  font-size: 0.9rem;
  min-width: 40px;
  text-align: center;
}

/* Current value display */
#scoreValue,
#opacityValue {
  font-weight: 700;
  color: var(--indigo-7);
  font-size: 1rem;
}

/* Enhanced slider styling */
.filter-slider,
.opacity-slider {
  width: 100%;
  margin: 8px 0;
  -webkit-appearance: none;
  height: 6px;
  background: linear-gradient(90deg, #e2e8f0, var(--indigo-5));
  border-radius: 3px;
  outline: none;
  position: relative;
}

.filter-slider::-webkit-slider-thumb,
.opacity-slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 20px;
  height: 20px;
  background: white;
  border: 2px solid var(--indigo-6);
  border-radius: 50%;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease;
}

.filter-slider::-webkit-slider-thumb:hover,
.opacity-slider::-webkit-slider-thumb:hover {
  transform: scale(1.2);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
  border-color: var(--indigo-7);
}

.filter-slider::-moz-range-thumb,
.opacity-slider::-moz-range-thumb {
  width: 20px;
  height: 20px;
  background: white;
  border: 2px solid var(--indigo-6);
  border-radius: 50%;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

/* ==================== LAYER CONTROLS ==================== */
.layer-controls {
  background: var(--gray-1);
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
  border: 1px solid var(--gray-4);
}

.layer-controls h4 {
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 1rem;
  font-weight: 600;
  color: var(--gray-12);
  margin-bottom: 12px;
  border-bottom: 2px solid var(--green-5);
  padding-bottom: 6px;
}

.layer-options {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.layer-option {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border: 2px solid transparent;
  border-radius: 6px;
  cursor: pointer;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  background: white;
}

.layer-option input[type="radio"] {
  display: none;
}

.radio-custom {
  width: 18px;
  height: 18px;
  border: 2px solid var(--gray-5);
  border-radius: 50%;
  position: relative;
}

.layer-option input[type="radio"]:checked+.radio-custom {
  border-color: var(--green-6);
  background: var(--green-6);
}

.layer-option input[type="radio"]:checked+.radio-custom::after {
  content: '';
  width: 8px;
  height: 8px;
  background: white;
  border-radius: 50%;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

/* ==================== OPACITY CONTROL ==================== */
.opacity-control {
  padding: 12px;
  background: var(--gray-1);
  border-radius: 6px;
  margin-bottom: 16px;
}

.opacity-control label {
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
  color: var(--gray-11);
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
}

.opacity-slider {
  width: 100%;
  margin: 8px 0;
}

/* ==================== QUICK ACTIONS ==================== */
.quick-actions {
  background: var(--gray-1);
  border-radius: 8px;
  padding: 16px;
  border: 1px solid var(--gray-4);
}

.quick-actions h4 {
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 1rem;
  font-weight: 600;
  color: var(--gray-12);
  margin-bottom: 12px;
  border-bottom: 2px solid var(--blue-5);
  padding-bottom: 6px;
}

.quick-actions .btn-secondary {
  width: 100%;
  margin-bottom: 8px;
}

/* ==================== FIXED MAP CONTAINER HEIGHT ==================== */
.main-content {
  display: flex;
  flex-direction: column;
  gap: var(--gap);
  min-height: 0;
  height: 100%;
}

.map-container {
  flex: 1;
  min-height: 400px;
  position: relative;
  width: 100%;
}

.map {
  width: 100%;
  height: 100%;
  border-radius: var(--card-radius);
  overflow: hidden;
  box-shadow: var(--shadow);
  border: 1px solid var(--gray-3);
  background: #1a2b39 !important;
}

/* ==================== FIXED BOTTOM ROW HEIGHT ==================== */
.bottom-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--gap);
  height: 300px;
  min-height: 300px;
  flex-shrink: 0;
}

.card {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: var(--card-radius);
  padding: 16px;
  box-shadow: var(--shadow);
  overflow: auto;
  border: 1px solid var(--gray-3);
  height: 100%;
}

/* ==================== CHART STYLES ==================== */
.chart-container {
  height: calc(100% - 40px);
  position: relative;
}

/* ==================== REPORT STYLES ==================== */
.report-content {
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 0.9rem;
  line-height: 1.6;
  height: calc(100% - 40px);
  overflow: auto;
  color: var(--gray-11);
}

.report-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: var(--gray-8);
  text-align: center;
  padding: 20px;
}

/* ==================== ENHANCED TOOLTIP STYLING ==================== */
.map-tooltip {
  position: relative;
  background: rgba(26, 32, 44, 0.98);
  color: white;
  padding: 14px;
  border-radius: 8px;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 12px;
  line-height: 1.4;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
  max-width: 300px;
  pointer-events: none;
  z-index: 10000;
  display: none;
}

.tooltip-content {
  max-width: 280px;
}

.tooltip-content strong {
  color: #fff;
  font-size: 1.1em;
  margin-bottom: 8px;
  display: block;
  border-bottom: 1px solid rgba(255,255,255,0.3);
  padding-bottom: 6px;
}

.tooltip-details {
  font-size: 0.9em;
  line-height: 1.5;
}

.tooltip-label {
  color: #cbd5e0;
  font-weight: 600;
}

/* ==================== MAP CONTROLS VISIBILITY ==================== */
.ol-control {
  background: rgba(255, 255, 255, 0.95) !important;
  border-radius: 8px !important;
}

.ol-control button {
  background: rgba(255, 255, 255, 0.95) !important;
  color: #333 !important;
}

.ol-scale-line {
  background: rgba(255, 255, 255, 0.9) !important;
  color: #333 !important;
  border-radius: 6px !important;
}

/* ==================== ENHANCED FOOTER STYLING ==================== */
.app-footer {
  background: linear-gradient(135deg, #1a202c 0%, #2d3748 100%);
  color: white;
  padding: 24px 0;
  margin-top: auto;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.footer-content {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 var(--gap);
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.footer-links {
  display: flex;
  justify-content: center;
  gap: 32px;
  flex-wrap: wrap;
}

.footer-link {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  color: white;
  text-decoration: none;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-weight: 600;
  font-size: 0.95rem;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(10px);
}

.footer-link:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
  border-color: rgba(255, 255, 255, 0.3);
}

.link-icon {
  font-size: 1.2rem;
  filter: brightness(0) invert(1);
}

.link-text {
  white-space: nowrap;
}

.footer-info {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 24px;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 0.85rem;
  color: #a0aec0;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding-top: 16px;
}

.version {
  background: var(--indigo-6);
  padding: 4px 8px;
  border-radius: 4px;
  font-weight: 600;
  font-size: 0.8rem;
}

.copyright {
  font-weight: 500;
}

/* ==================== RESPONSIVE DESIGN ==================== */
@media (max-width: 768px) {
  .app-layout {
    grid-template-columns: 1fr;
    grid-template-rows: auto 1fr auto;
  }

  .sidebar {
    order: 1;
  }

  .main-content {
    order: 2;
  }

  .bottom-row {
    order: 3;
    grid-template-columns: 1fr;
    height: auto;
  }

  .map-container {
    min-height: 300px;
  }

  .footer-links {
    gap: 16px;
  }

  .footer-link {
    padding: 10px 16px;
    font-size: 0.9rem;
  }

  .footer-info {
    flex-direction: column;
    gap: 12px;
    text-align: center;
  }
}

/* ==================== UTILITY CLASSES ==================== */
.btn-primary,
.btn-secondary {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  font-family: 'Century Gothic', 'Segoe UI', sans-serif;
  font-size: 0.9rem;
  cursor: pointer;
  flex: 1;
}

.btn-primary {
  background: var(--indigo-6);
  color: white;
}

.btn-secondary {
  background: var(--gray-3);
  color: var(--gray-11);
}

.filter-actions {
  display: flex;
  gap: 8px;
  margin-top: 8px;
}

.control-group,
.filter-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

/* Loading states */
.loading-indicator {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 6px;
  font-family: 'Century Gothic', sans-serif;
}

.spinner {
  width: 20px;
  height: 20px;
  border: 2px solid #e2e8f0;
  border-top: 2px solid var(--indigo-6);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.error-message {
  background: #fed7d7;
  color: #c53030;
  padding: 12px;
  border-radius: 6px;
  border-left: 4px solid #fc8181;
  font-family: 'Century Gothic', sans-serif;
}
```

## 🎯 **KEY UPDATES IN THESE FILES:**

### **main.js Updates:**
1. **✅ Target Name Hierarchy**: All hierarchical dropdowns now use descriptive `target_name`
2. **✅ Enhanced Tooltips**: Show `target_name` in title, `target_class` in details
3. **✅ Transparent Bounding Boxes**: Fill only appears on hover
4. **✅ Updated Chart Labels**: Use `target_name` for bar chart labels and tooltips
5. **✅ Improved Filter Management**: Prioritize `target_name` over `target_class`

### **styles.css Updates:**
1. **✅ Fixed Open Props Import**: Correct local import path for Vite HMR
2. **✅ Enhanced Tooltip Styling**: Better visual hierarchy for target names vs classes
3. **✅ Professional UI Components**: Century Gothic typography throughout
4. **✅ Responsive Design**: Mobile-friendly layouts
5. **✅ Modern Visual Design**: Gradients, shadows, and smooth transitions

Both files are now fully synchronized with the latest backend changes and provide a professional, user-friendly experience with descriptive target names! 🚀

---

# FULL UPDATED `api-docs.html`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Documentation - Geospatial Intelligence</title>
    <link rel="stylesheet" href="/src/styles.css">
    <style>
        .api-docs-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        .api-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .api-endpoints {
            display: grid;
            gap: 24px;
        }
        
        .endpoint-group {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
        }
        
        .endpoint-group h2 {
            color: var(--indigo-7);
            margin-bottom: 16px;
            font-family: 'Century Gothic', sans-serif;
            border-bottom: 2px solid var(--indigo-5);
            padding-bottom: 8px;
        }
        
        .endpoint-item {
            background: #f7fafc;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 12px;
            border-left: 4px solid var(--indigo-5);
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .endpoint-header {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        
        .endpoint-method {
            display: inline-block;
            background: var(--indigo-6);
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 700;
            margin-right: 8px;
        }
        
        .endpoint-path {
            font-family: 'Monaco', 'Menlo', monospace;
            font-weight: 600;
            color: #2d3748;
            flex: 1;
        }
        
        .endpoint-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            background: var(--green-6);
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .endpoint-link:hover {
            background: var(--green-7);
            transform: translateY(-1px);
        }
        
        .endpoint-description {
            color: #4a5568;
            font-size: 0.9rem;
            line-height: 1.5;
        }
        
        .back-home {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: var(--indigo-6);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            margin-bottom: 24px;
            transition: all 0.3s ease;
        }
        
        .back-home:hover {
            background: var(--indigo-7);
            transform: translateY(-2px);
        }
        
        .link-icon {
            font-size: 0.9rem;
        }

        .parameter-info {
            margin-top: 8px;
            padding: 8px 12px;
            background: #edf2f7;
            border-radius: 4px;
            font-size: 0.85rem;
        }

        .parameter-name {
            font-weight: 600;
            color: #2d3748;
        }

        .parameter-type {
            color: #718096;
            font-style: italic;
        }

        .response-example {
            margin-top: 8px;
            padding: 12px;
            background: #1a202c;
            color: #e2e8f0;
            border-radius: 6px;
            font-family: 'Monaco', 'Menlo', monospace;
            font-size: 0.8rem;
            overflow-x: auto;
        }

        .endpoint-notes {
            margin-top: 8px;
            padding: 8px 12px;
            background: #fffaf0;
            border-left: 3px solid #ed8936;
            border-radius: 4px;
            font-size: 0.85rem;
            color: #744210;
        }
    </style>
</head>
<body>
    <div class="api-docs-container">
        <a href="/" class="back-home">
            ← Back to Dashboard
        </a>
        
        <div class="api-header">
            <h1>API Documentation</h1>
            <p>Complete reference for all available endpoints in the Geospatial Intelligence Dashboard</p>
        </div>
        
        <div class="api-endpoints">
            <div class="endpoint-group">
                <h2>Hierarchical Navigation</h2>
                
                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/countries</span>
                        <a href="/api/countries" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Retrieve all available countries from the database. Used as the first step in the hierarchical navigation system.
                    </div>
                    <div class="response-example">
// Response: Array of country names<br/>
["Germany", "France", "Italy"]
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/target-types/&lt;country&gt;</span>
                        <a href="/api/target-types/Germany" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get target names for a specific country. Returns descriptive names like "Frankfurt_Airport_Aircraft_1" instead of generic classes.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">country</span> <span class="parameter-type">(string)</span> - Name of the country from the countries list
                    </div>
                    <div class="response-example">
// Response: Array of target names<br/>
["Frankfurt_Airport_Aircraft_1", "Frankfurt_Airport_Service_1"]
                    </div>
                    <div class="endpoint-notes">
                        💡 <strong>Updated:</strong> Now returns descriptive target names instead of generic target classes for better user experience.
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/image-ids/&lt;country&gt;/&lt;target_name&gt;</span>
                        <a href="/api/image-ids/Germany/Frankfurt_Airport_Aircraft_1" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get image IDs for a specific country and target name. Returns available imagery for the selected target.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">country</span> <span class="parameter-type">(string)</span> - Name of the country<br/>
                        <span class="parameter-name">target_name</span> <span class="parameter-type">(string)</span> - Descriptive target name from target-types list
                    </div>
                    <div class="response-example">
// Response: Array of image IDs<br/>
["IX200925XPESSCX1X77G7X_gcr", "IX251024XPESSCX1X77G7X_gcr"]
                    </div>
                </div>
            </div>
            
            <div class="endpoint-group">
                <h2>Data Retrieval & Visualization</h2>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/unified-data/&lt;image_id&gt;</span>
                        <a href="/api/unified-data/IX200925XPESSCX1X77G7X_gcr" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get unified vector and chart data with synchronized filtering. This ensures map features and charts stay perfectly synchronized.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">image_id</span> <span class="parameter-type">(string)</span> - Image ID from image-ids list<br/>
                        <span class="parameter-name">target_name</span> <span class="parameter-type">(string, optional)</span> - Filter by target name<br/>
                        <span class="parameter-name">target_class</span> <span class="parameter-type">(string, optional)</span> - Filter by target class<br/>
                        <span class="parameter-name">min_score</span> <span class="parameter-type">(float, optional)</span> - Minimum confidence score (0.0-1.0)<br/>
                        <span class="parameter-name">max_score</span> <span class="parameter-type">(float, optional)</span> - Maximum confidence score (0.0-1.0)
                    </div>
                    <div class="response-example">
// Response: Unified vector and chart data<br/>
{<br/>
  "vector_data": {<br/>
    "type": "FeatureCollection",<br/>
    "features": [...]<br/>
  },<br/>
  "chart_data": [<br/>
    {<br/>
      "target_name": "Frankfurt_Airport_Aircraft_1",<br/>
      "target_class": "aircraft",<br/>
      "total_count": 5,<br/>
      "avg_score": 0.92<br/>
    }<br/>
  ]<br/>
}
                    </div>
                    <div class="endpoint-notes">
                        💡 <strong>Enhanced:</strong> Now includes both target_name and target_class for better data representation.
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/data/&lt;image_id&gt;</span>
                        <a href="/api/data/IX200925XPESSCX1X77G7X_gcr" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get geospatial vector data in GeoJSON format for map visualization. Includes both geometry and target properties.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">image_id</span> <span class="parameter-type">(string)</span> - Image ID from image-ids list
                    </div>
                    <div class="response-example">
// Response: GeoJSON FeatureCollection<br/>
{<br/>
  "type": "FeatureCollection",<br/>
  "features": [<br/>
    {<br/>
      "type": "Feature",<br/>
      "geometry": {...},<br/>
      "properties": {<br/>
        "target_name": "Frankfurt_Airport_Aircraft_1",<br/>
        "target_class": "aircraft",<br/>
        "score": 0.95<br/>
      }<br/>
    }<br/>
  ]<br/>
}
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/charts/&lt;image_id&gt;/target_class</span>
                        <a href="/api/charts/IX200925XPESSCX1X77G7X_gcr/target_class" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get chart data for target class visualization. Used for generating bar charts and statistics.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">image_id</span> <span class="parameter-type">(string)</span> - Image ID from image-ids list
                    </div>
                    <div class="response-example">
// Response: Chart data array<br/>
[<br/>
  {<br/>
    "label": "aircraft",<br/>
    "value": 3<br/>
  }<br/>
]
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/historical-data</span>
                        <a href="/api/historical-data" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get time series data for historical deployment analysis. Used for timeline charts and trend analysis.
                    </div>
                    <div class="response-example">
// Response: Time series data<br/>
[<br/>
  {<br/>
    "date": "2024-10-25",<br/>
    "target_class": "aircraft",<br/>
    "total_count": 5<br/>
  }<br/>
]
                    </div>
                </div>
            </div>
            
            <div class="endpoint-group">
                <h2>Filtering & Reports</h2>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/filtered-data/&lt;image_id&gt;</span>
                        <a href="/api/filtered-data/IX200925XPESSCX1X77G7X_gcr" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get filtered data based on query parameters. Advanced filtering for target classes, names, and confidence scores.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">image_id</span> <span class="parameter-type">(string)</span> - Image ID from image-ids list<br/>
                        <span class="parameter-name">target_name</span> <span class="parameter-type">(string[], optional)</span> - Filter by target names<br/>
                        <span class="parameter-name">target_class</span> <span class="parameter-type">(string[], optional)</span> - Filter by target classes<br/>
                        <span class="parameter-name">min_score</span> <span class="parameter-type">(float, optional)</span> - Minimum confidence score<br/>
                        <span class="parameter-name">max_score</span> <span class="parameter-type">(float, optional)</span> - Maximum confidence score
                    </div>
                    <div class="response-example">
// Response: Filtered chart data<br/>
[<br/>
  {<br/>
    "target_class": "aircraft",<br/>
    "target_name": "aircraft",<br/>
    "total_count": 2,<br/>
    "avg_score": 0.89<br/>
  }<br/>
]
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/filter-options/&lt;image_id&gt;</span>
                        <a href="/api/filter-options/IX200925XPESSCX1X77G7X_gcr" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get available filter options for a specific image. Returns target names, classes, and score ranges for the filter UI.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">image_id</span> <span class="parameter-type">(string)</span> - Image ID from image-ids list
                    </div>
                    <div class="response-example">
// Response: Available filter options<br/>
{<br/>
  "target_names": ["Frankfurt_Airport_Aircraft_1", ...],<br/>
  "target_classes": ["aircraft", ...],<br/>
  "score_range": {<br/>
    "min": 0.45,<br/>
    "max": 0.98<br/>
  }<br/>
}
                    </div>
                    <div class="endpoint-notes">
                        💡 <strong>Enhanced:</strong> Now provides target_names as the primary filter option with descriptive names.
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/reports</span>
                        <a href="/api/reports" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        List all available analysis reports. Returns filenames of generated analysis reports.
                    </div>
                    <div class="response-example">
// Response: Array of report filenames<br/>
["IX200925XPESSCX1X77G7X_gcr.txt", "IX251024XPESSCX1X77G7X_gcr.txt"]
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api/reports/&lt;filename&gt;</span>
                        <a href="/api/reports/IX200925XPESSCX1X77G7X_gcr.txt" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Get specific analysis report content. Returns the full text content of the requested report.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">filename</span> <span class="parameter-type">(string)</span> - Report filename from reports list (must end with .txt)
                    </div>
                    <div class="response-example">
// Response: Plain text report content<br/>
"Analysis Report for IX200925XPESSCX1X77G7X_gcr\n\nTarget Summary:\n- Aircraft: 3 detections\n- Service Vehicles: 2 detections\n..."
                    </div>
                </div>
            </div>
            
            <div class="endpoint-group">
                <h2>System & Monitoring</h2>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/health</span>
                        <a href="/health" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Check system health status and component availability. Returns database connectivity, file system status, and resource counts.
                    </div>
                    <div class="response-example">
// Response: Health status object<br/>
{<br/>
  "status": "healthy",<br/>
  "timestamp": "2024-01-15T10:30:00Z",<br/>
  "version": "1.0.0-rc.3",<br/>
  "database": "connected",<br/>
  "tiles_dir": "exists",<br/>
  "tiles_dir_layer_count": 3,<br/>
  "cogs_dir": "exists",<br/>
  "cogs_dir_file_count": 2,<br/>
  "reports_dir": "exists",<br/>
  "reports_dir_file_count": 5<br/>
}
                    </div>
                    <div class="endpoint-notes">
                        💡 <strong>Enhanced:</strong> Now counts image_id directories (layers) instead of individual tile files for more meaningful metrics.
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/health-page</span>
                        <a href="/health-page" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            View Page
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Modern health status dashboard with visual indicators and real-time monitoring. Status.io-themed interface.
                    </div>
                    <div class="endpoint-notes">
                        🆕 <strong>New:</strong> Interactive health dashboard with auto-refresh and component status visualization.
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api</span>
                        <a href="/api" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            View Page
                        </a>
                    </div>
                    <div class="endpoint-description">
                        This API documentation endpoint. Returns the interactive documentation page you're currently viewing.
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/api-list</span>
                        <a href="/api-list" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            Test Endpoint
                        </a>
                    </div>
                    <div class="endpoint-description">
                        List all available API endpoints programmatically. Returns all registered routes with their methods and paths.
                    </div>
                    <div class="response-example">
// Response: Array of endpoint objects<br/>
[<br/>
  {<br/>
    "endpoint": "get_countries",<br/>
    "methods": ["GET", "HEAD", "OPTIONS"],<br/>
    "path": "/api/countries"<br/>
  }<br/>
]
                    </div>
                </div>
            </div>

            <div class="endpoint-group">
                <h2>Static Assets & Pages</h2>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/basemap</span>
                        <a href="/basemap" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            View Page
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Vector basemap viewer page. Dedicated interface for exploring different basemap layers (Vector, Satellite, Terrain).
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/historical-deployment</span>
                        <a href="/historical-deployment" target="_blank" class="endpoint-link">
                            <span class="link-icon">🔗</span>
                            View Page
                        </a>
                    </div>
                    <div class="endpoint-description">
                        Historical deployment analysis page. Interactive time series charts and statistics for trend analysis.
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/tiles/&lt;image_id&gt;/&lt;z&gt;/&lt;x&gt;/&lt;y&gt;.png</span>
                    </div>
                    <div class="endpoint-description">
                        Serve XYZ map tiles for imagery visualization. Used by the map component to display raster imagery.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">image_id</span> <span class="parameter-type">(string)</span> - Image ID<br/>
                        <span class="parameter-name">z</span> <span class="parameter-type">(integer)</span> - Zoom level<br/>
                        <span class="parameter-name">x</span> <span class="parameter-type">(integer)</span> - Tile X coordinate<br/>
                        <span class="parameter-name">y</span> <span class="parameter-type">(integer)</span> - Tile Y coordinate
                    </div>
                </div>

                <div class="endpoint-item">
                    <div class="endpoint-header">
                        <span class="endpoint-method">GET</span>
                        <span class="endpoint-path">/cogs/&lt;filename&gt;</span>
                    </div>
                    <div class="endpoint-description">
                        Serve COG (Cloud Optimized GeoTIFF) files for direct raster access. Used for COG layer visualization in the map.
                    </div>
                    <div class="parameter-info">
                        <span class="parameter-name">filename</span> <span class="parameter-type">(string)</span> - COG filename (must end with .tiff or .tif)
                    </div>
                </div>
            </div>
        </div>

        <div style="margin-top: 40px; padding: 20px; background: #f7fafc; border-radius: 8px;">
            <h3 style="color: #2d3748; margin-bottom: 12px;">API Usage Notes</h3>
            <ul style="color: #4a5568; line-height: 1.6;">
                <li>All endpoints return JSON responses unless otherwise specified</li>
                <li>Use the hierarchical navigation endpoints in sequence: countries → target-types → image-ids</li>
                <li>The unified-data endpoint is recommended for most use cases as it synchronizes map and chart data</li>
                <li>Filter parameters can be combined for advanced querying</li>
                <li>All image_id values must match the pattern: <code>^IX[a-zA-Z0-9_]+$</code></li>
                <li>Health endpoint provides comprehensive system monitoring with layer-based tile counting</li>
            </ul>
        </div>
    </div>
</body>
</html>
```

## 🎯 **KEY ENHANCEMENTS IN API DOCS:**

### **1. Interactive Endpoint Testing**
- **✅ Clickable "Test Endpoint" buttons** for all major API routes
- **✅ Real example URLs** with sample data (Germany, Frankfurt_Airport_Aircraft_1, etc.)
- **✅ Direct testing capability** without leaving the documentation

### **2. Comprehensive Parameter Documentation**
- **✅ Detailed parameter descriptions** with types and constraints
- **✅ Required vs optional parameters** clearly indicated
- **✅ Query parameter examples** for filtering endpoints

### **3. Enhanced Response Examples**
- **✅ Realistic JSON responses** with actual data structures
- **✅ Updated to reflect target_name changes** throughout the system
- **✅ Health endpoint now shows layer counting** instead of tile counting

### **4. Visual Enhancements**
- **✅ Color-coded method badges** (GET, POST, etc.)
- **✅ Syntax-highlighted code blocks** for response examples
- **✅ Informational notes** highlighting recent changes and enhancements
- **✅ Parameter info boxes** with type annotations

### **5. Complete Endpoint Coverage**
- **✅ All hierarchical endpoints** with updated target_name focus
- **✅ Data retrieval endpoints** including the unified-data synchronized approach
- **✅ Filtering & reporting endpoints** with parameter details
- **✅ System monitoring endpoints** including the new health dashboard
- **✅ Static asset endpoints** for tiles and COG files

### **6. User-Friendly Features**
- **✅ Back to Dashboard navigation** for seamless user flow
- **✅ Responsive design** that works on all screen sizes
- **✅ Clear endpoint grouping** by functionality
- **✅ Usage notes section** with best practices

The API documentation now serves as both comprehensive reference and interactive testing tool, making it easy for developers to understand and use the geospatial intelligence API! 🚀

---
