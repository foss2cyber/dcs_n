### Fixing Time Sync on Air-Gapped Windows Client

While your air-gapped network and dead CMOS battery create a challenging situation, you can use Windows features to automatically synchronize time at startup. This should resolve the incorrect timestamps in your logs.

### ⚙️ Automatically Sync Time on Startup via Task Scheduler
Since your computer cannot hold the correct time without a CMOS battery, you can configure it to automatically synchronize with a time source every time it boots. Here is how to set it up:

1.  **Open Task Scheduler**: Press `Win + R`, type `taskschd.msc`, and press Enter.
2.  **Create a Basic Task**: In the right-hand **Actions** pane, click **"Create Basic Task..."**.
3.  **Name the Task**: Give it a clear name, such as "Time Sync on Startup".
4.  **Set the Trigger**: Choose **"When the computer starts"** as the trigger.
5.  **Set the Action**: Select **"Start a program"** as the action.
6.  **Configure the Program**:
    *   In the **"Program/script"** field, type: `w32tm`.
    *   In the **"Add arguments (optional)"** field, type: `/resync`.

Once created, this task will run the time resynchronization command every time your system starts up.

### 💡 Finding a Time Source and Other Considerations
The solution above requires a time source to sync with. On an air-gapped network, you have a few options:

*   **Use the Network Share's Time**: If the computer hosting the main network drive is on the same isolated network and maintains the correct time, you can use it as a time source. You would need to configure the Windows Time service to point to that machine's IP address. The command would be `w32tm /config /syncfromflags:manual /manualpeerlist:"IP_ADDRESS"` (run in an elevated Command Prompt), where `IP_ADDRESS` is replaced by the IP of the host computer.
*   **Designate an Internal Time Server**: If possible, configure one machine on your air-gapped network (perhaps the most stable one) as an authoritative time source for others.
*   **Verify Service is Running**: The `w32tm /resync` command requires the **Windows Time** service. To check it, press `Win + R`, type `services.msc`, and locate the **Windows Time** service. Ensure its **Startup type** is set to **Automatic**.
*   **Manual Time Setting as a Last Resort**: If no network time source is available, you might need a secondary, automated script that simply sets the time to a predetermined value on startup. This is less ideal but can ensure consistency if your work does not require absolute real-world time.

### 🔁 Temporary Steps Until a Permanent Fix is Possible
The solutions above are workarounds. For long-term stability, the CMOS battery should be replaced when circumstances allow. A failing or dead CMOS battery causes the symptoms you're seeing: the system loses track of time and date when powered off, and BIOS settings can reset.

I hope these steps help you restore accurate timestamps for your development work. If you can share more about the other machines on your isolated network, I might be able to offer more specific guidance on configuring an internal time source.

---
