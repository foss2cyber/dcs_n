# GeoDoxy Project Memory Log

## Project Overview
**Project Name**: GeoDoxy - Geospatial Intelligence Dashboard  
**Core Goal**: Develop a robust Flask + Vite web application with PostgreSQL/PostGIS backend for geospatial intelligence analysis, deployed in air-gapped Windows environments with optimized static asset server architecture.

## Current Status - 🚀 PRODUCTION READY
**Latest Achievement**: Successfully resolved production deployment architecture. System is now ready for air-gapped Windows network deployment with single-entry-point access via Traefik reverse proxy.

**Key Milestone**: Eliminated development-only Vite server, established clear production routing through Traefik on port 8081.

## Key Technical Decisions & Architecture

### 1. Production Architecture (Final)
**Decision**: Single entry point via Traefik with intelligent routing
**Why**: Simplified client access, better security, air-gapped compatibility
**Implementation**:
```
Client Browser → http://localhost:8081/ (Traefik)
                     ↓
           /api/*    → Flask (:5000) - API + HTML pages
           /tiles/*  → NGINX (:8080) - Map tiles  
           /cogs/*   → NGINX (:8080) - GeoTIFF files
           /*        → Flask (:5000) - HTML pages (built Vite frontend)
```

### 2. Static Asset Server Optimization
**Decision**: Hybrid NGINX configuration with smart caching
**Why**: Performance optimization for different file types, security hardening
**Key Features**:
- Vector tiles (.pbf): 6-hour cache
- Images (.png,.jpg): 1-year cache (immutable)
- Large files (.tiff): 24-hour cache
- Disabled directory listing for security

### 3. Database Schema (PostgreSQL + PostGIS)
```sql
-- Core tables maintained
findings (id, image_id, target_class, score, target_geom)
target (id, target_type, target_name, country_name, target_geom)  
sql_scat_query2 (precomputed results with scores)
comprehensive_query (aggregation view)
```

### 4. Frontend Build Strategy
**Decision**: Flask serves built Vite frontend in production
**Why**: Eliminates dev server dependency, simplifies deployment
**Build Process**: `VITE_ASSET_SERVER= npm run build` → Flask serves `/dist/`

## Critical Code Configurations (Latest)

### Production Routing (dynamic.yml)
```yaml
http:
  routers:
    # Static assets - HIGH PRIORITY (100)
    tiles-router: { rule: "PathPrefix(`/tiles`)", service: nginx-static, priority: 100 }
    cogs-router: { rule: "PathPrefix(`/cogs`)", service: nginx-static, priority: 100 }
    # ... other static routes
    
    # API routes - MEDIUM PRIORITY (50)  
    api-router: { rule: "PathPrefix(`/api`)", service: flask-app, priority: 50 }
    
    # Catch-all - LOWEST PRIORITY (1)
    app-router: { rule: "PathPrefix(`/)", service: flask-app, priority: 1 }
```

### Asset URL Management (config.js)
```javascript
export const CONFIG = {
  ASSET_SERVER: import.meta.env.VITE_ASSET_SERVER || "", // Relative paths in production
  API_BASE: "/api",
  TILES_BASE: "/tiles", // Traefik routes to NGINX
  // ... other base paths
};

export function getAssetUrl(path) {
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  return CONFIG.ASSET_SERVER ? `${CONFIG.ASSET_SERVER}/${cleanPath}` : `/${cleanPath}`;
}
```

### Flask Production Serving (app.py)
```python
@app.route('/')
@app.route('/<path:path>')
def serve_frontend(path='index.html'):
    # Serve built Vite frontend from dist directory
    try:
        return send_from_directory('dist', path)
    except:
        return send_from_directory('dist', 'index.html')
```

## Current Problem & Next Immediate Step

### Just Resolved ✅
**Problem**: Confusion between development (Vite :5173) and production (Traefik :8081) architectures
**Solution**: 
- Clarified that Vite dev server is development-only
- Established Flask as production frontend server
- Configured Traefik as single entry point
- Updated all configurations for relative paths

### Next Immediate Step 🚀
**Action**: Deploy and test complete system on air-gapped Windows network
**Deployment Process**:
```batch
# 1. Build frontend
VITE_ASSET_SERVER= npm run build

# 2. Copy to shared drive
xcopy /E /I /Y dist\* D:\shared-drive\geodoxy-app\
xcopy /E /I /Y static-asset-server\* D:\shared-drive\geodoxy-app\

# 3. Run on client machines
cd D:\shared-drive\geodoxy-app
start-geodoxy.bat
```

**Test Sequence**:
1. Access `http://localhost:8081/` - Main dashboard
2. Test map tiles load (`/tiles/`)
3. Verify API endpoints (`/api/countries`)
4. Check static assets (`/icons/`, `/reports/`)
5. Validate health endpoints (`/health`, `/nginx-health`)

## Open Questions & Considerations

### 1. Windows-Specific Deployment
- **Status**: READY - Batch files created
- **Consideration**: Need admin rights for port binding
- **Solution**: `start-geodoxy.bat` with administrative privileges

### 2. Asset Synchronization
- **Status**: MANUAL - Copy process
- **Future Consideration**: Automated sync script for updates
- **Current**: Manual xcopy deployment sufficient for initial release

### 3. Production Security
- **Implemented**: 
  - Disabled directory listing in NGINX
  - Removed server tokens
  - Proper CORS scoping
- **Future**: Basic auth for admin endpoints if needed

## Deployment Architecture Summary

### Port Configuration (Final)
- **Traefik**: `8081` (Client access point)
- **Flask**: `5000` (API + HTML, internal)
- **NGINX**: `8080` (Static assets, internal)
- **Vite Dev**: `5173` (Development only, eliminated in production)

### Client Access Flow
```
Windows Client → start-geodoxy.bat → Services start → Browser → localhost:8081
    ↓
Traefik routes:
  /tiles/*, /cogs/*, /icons/* → NGINX:8080
  /api/*, /* → Flask:5000
    ↓
Flask serves built Vite frontend + handles APIs
NGINX serves static geospatial assets
```

## Critical Configuration Files (Current Versions)

### 1. Environment (.env)
```bash
ASSET_SERVER=              # Empty for relative paths
VITE_ASSET_SERVER=         # Empty for relative paths
DB_HOST=localhost
DB_PORT=5432
DB_NAME=postgres
DB_USER=postgres
DB_PASSWORD=postgres
```

### 2. Vite Build (vite.config.js)
```javascript
base: "/",                    // Production-relative paths
// server section REMOVED    // No dev server in production
```

### 3. NGINX (nginx.conf)
```nginx
listen 8080;                 // Internal static asset server
autoindex off;               // Security
location ~* \.(tiff|geojson) {
    expires 24h;             // Smart caching
    add_header CORS...       // Scoped CORS
}
```

## Quick Resume Commands

### Development Mode
```bash
# Development (separate servers)
npm run dev                 # Vite :5173 (frontend)
python app.py              # Flask :5000 (backend)

# Access: http://localhost:5173
```

### Production Mode  
```bash
# Production build & deploy
VITE_ASSET_SERVER= npm run build
cp -r dist/* static-asset-server/assets/

# Production run
./start-geodoxy.bat        # Or start-services.sh
# Access: http://localhost:8081
```

### Windows Deployment
```batch
# On each client machine
cd D:\shared-drive\geodoxy-app
start-geodoxy.bat
# Opens http://localhost:8081 automatically
```

## Recent Breakthroughs & Solutions

### 1. Production Architecture Clarity
**Problem**: Development vs production confusion
**Solution**: Clear separation with Traefik as single entry point

### 2. Asset Path Resolution
**Problem**: Hardcoded URLs breaking deployment
**Solution**: Relative paths with Traefik routing

### 3. Windows Compatibility
**Problem**: Linux-specific configurations
**Solution**: Batch files and Windows-optimized NGINX config

## Status: READY FOR DEPLOYMENT 🎯

The application is now production-ready for air-gapped Windows network deployment. All components are configured for the final architecture with Traefik as the single access point, proper routing priorities, and optimized static asset delivery.

**Next Action**: Deploy to shared network drive and test on first client machine.
