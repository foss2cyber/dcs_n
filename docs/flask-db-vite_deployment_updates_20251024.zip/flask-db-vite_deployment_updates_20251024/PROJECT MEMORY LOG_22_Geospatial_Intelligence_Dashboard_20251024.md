# 🗂️ GeoDoxy - Geospatial Intelligence Platform  
## 🧠 Final Project Memory Log — Production-Ready, Air-Gapped Architecture

---

### 🎯 Core Project Goal & Current Status

**Project Goal**: Build a production-ready, self-contained geospatial intelligence platform for AI-based target detection analysis with hierarchical data navigation, real-time filtering, and multiple visualization modes — **fully operational in air-gapped environments**.

**Current Status**: ✅ **PRODUCTION-READY (v1.0.0-rc.4)**  
- All core features implemented and tested  
- **Simplified, robust architecture**: NGINX as central router (port 80)  
- **Clear separation**: Core app (Git) vs. Assets (local disk)  
- **Zero external CDN dependencies** — 100% offline capable  
- **All tooltips consistently show**: `target_name → target_class → target_type → score → centroid`

---

### 🔧 Key Technical Decisions & Architecture

#### **Database Schema (Final & Verified)**
```sql
-- ONLY these physical tables exist
target (id, target_type, target_name, country_name, target_geom)        -- ✅ Contains target_type
sql_scat_query2 (country_name, target_name, image_id, image_date, target_class, score, st_x, st_y) -- ✅ Has score
findings (id, image_id, image_date, target_class, score, target_geom)  -- ✅ Base detections
comprehensive_query → VIEW (no score column)                           -- ❌ Not used for data/chart endpoints
```
> ✅ **`target_type` sourced from `target` table via `target_name` join**  
> ❌ **`comprehensive_query` is ONLY used in `/api/countries` — never for data/chart endpoints**

#### **Library & Tool Choices**
| Layer | Technology | Why |
|------|-----------|-----|
| **Backend** | Flask + PostGIS | Lightweight, excellent geospatial support |
| **Frontend** | OpenLayers + Chart.js | Professional mapping, interactive charts |
| **Build** | Vite | Fast builds, multi-page support |
| **Serving** | Waitress (prod) / Flask dev server | Reliable WSGI |
| **Static Assets** | **NGINX (Windows/Linux)** | Central router, CORS middleware, native support |
| **Versioning** | Git + custom scripts | Air-gapped friendly |

#### **Architecture Highlights**
- **Separation of Concerns**:  
  - **`geodoxy-core/`**: Git-tracked code (Flask + Vite)  
  - **`D:\geodoxy-assets\`**: Terabyte-scale static assets (not in Git)  
- **NGINX as Central Router** (port 80):  
  - `/` → Flask (core app + API)  
  - `/tiles/`, `/cogs/`, `/reports/` → Local disk  
- **Frontend uses relative paths** (`/tiles/...`) — no asset server config needed

---

### 📋 Latest Critical Updates & Fixes

#### ✅ **1. Final `app.py` — Corrected Data Endpoints**
- **Removed all `comprehensive_query` usage in data/chart endpoints**
- **Vector/chart data sourced from `sql_scat_query2`** (has `score`)
- **`/api/unified-data` returns**:  
  ```json
  {
    "target_name": "Frankfurt_Airport_Aircraft_1",
    "target_class": "FR-AF-CGAA-1",
    "target_type": "airfield",
    "score": 0.95,
    "centroid": [8.551, 50.039]
  }
  ```

#### ✅ **2. Simplified Frontend — No Asset Proxying**
- **Deleted `src/config.js`** — no more `VITE_ASSET_SERVER`
- **All asset paths are relative**:  
  ```js
  // main.js & basemap.js
  const xyzSource = new XYZ({ url: `/tiles/${imageId}/{z}/{x}/{y}.png` });
  const res = await fetch(`/reports/${imageId}.txt`);
  ```

#### ✅ **3. NGINX Config — Windows-Optimized**
```nginx
# nginx.conf
server {
    listen 80;
    location / { proxy_pass http://127.0.0.1:5000; }  # Flask
    location /tiles/ { alias D:/geodoxy-assets/tiles/; }   # ← Trailing slash required
    location /cogs/ { alias D:/geodoxy-assets/cogs/; }
    location /reports/ { alias D:/geodoxy-assets/reports/; }
    # ... CORS headers for all assets
}
```

#### ✅ **4. Unified Tooltips (Map + Chart)**
Both `main.js` and `basemap.js` display:
```
Frankfurt_Airport_Aircraft_1
Class: FR-AF-CGAA-1
Type: airfield
Score: 95.0%
Centroid: 8.551000, 50.039000
```

#### ✅ **5. Basemap Auto-Load & Zoom-to-Imagery**
- **Auto-load** triggered on image ID selection
- **Zooms to vector data extent** (proxy for imagery coverage)
- Serves `.pbf` → `.geojson` → OpenLayers seamlessly

---

### 🚀 Current Active Development Focus

#### **Problem Just Solved**
✅ **Eliminated asset proxy confusion** by:
- Removing all frontend asset server configs (`src/config.js`, `VITE_ASSET_SERVER`)
- Using **relative paths** (`/tiles/...`) served by NGINX
- **Decoupling code (Git) from assets (local disk)**

#### **Very Next Step To Take**
➡️ **Deploy to air-gapped Windows system**:
1. Place assets in `D:\geodoxy-assets\`
2. Build core app: `npm run build`
3. Start Flask: `python run.py`
4. Start NGINX: `nginx.exe`
5. Access via `http://your-server-ip/`

---

### 🎯 Key Features Currently Working

| Feature | Status |
|--------|--------|
| **Hierarchical Navigation** | Country → Target Name → Image ID (auto-loads) |
| **Real-time Filtering** | Dynamic score slider, class/name filters |
| **Visualization** | OpenLayers map + Chart.js bar/line charts |
| **Specialized Pages** | Basemap, Historical, API Docs, Health |
| **Asset Sharing** | NGINX serves COGs/tiles/reports to all systems |
| **Offline Operation** | Zero internet dependency |

---

### ⚠️ Open Questions & Considerations

| Area | Consideration |
|------|---------------|
| **Security** | Add IP whitelisting in NGINX for air-gapped network |
| **Performance** | Enable NGINX caching for frequently accessed tiles |
| **Maintenance** | Automate asset sync from source to shared drive |
| **Scalability** | Monitor NGINX under high concurrent load (10+ clients) |
| **Backup** | Implement asset versioning (e.g., `assets_v1/`, `assets_v2/`) |

---

### 🔄 Quick Restart Commands

#### **Development**
```bash
# Backend
python app.py                    # http://localhost:5000

# Frontend
npm run dev                     # http://localhost:5173
```

#### **Production**
```bash
# Build & run
npm run build && python run.py  # http://localhost:5000

# Static asset server (Windows)
cd nginx-1.28.0
nginx.exe
```

#### **Git Baseline**
```bash
# Windows
provision-git-baseline.bat

# Linux/macOS
chmod +x provision-git-baseline.sh && ./provision-git-baseline.sh
```

---

### 📞 Seamless Continuation Guide

To resume work in a new conversation:

1. **Reference this memory log** for current architecture
2. **Use final `app.py`** (joins `target` table, no `comprehensive_query` in data endpoints)
3. **Test tooltips** — must show `target_name → target_class → target_type → score → centroid`
4. **Verify NGINX** serves assets at `http://your-server-ip/tiles/...`
5. **Check version** — health endpoint returns `1.0.0-rc.4`

> The system is **fully production-ready** for air-gapped deployment with **simplified, maintainable architecture**. 🚀
