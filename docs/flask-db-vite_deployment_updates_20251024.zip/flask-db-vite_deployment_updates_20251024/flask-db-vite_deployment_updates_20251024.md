Please give me the full, corrected files for app.py, config.py, .env, config.js, basemap.js, vite.config.js, etc. after anlysing the following static-asset-server:

```text
Both versions have ......
	............both original versions.
```

Based on your analysis, I'll provide the corrected files with the optimized hybrid architecture. Here are the complete, updated configurations:

## 1. Updated Flask App (`app.py`)

```python
import os
import re
import json
import datetime
import logging
from flask import Flask, jsonify, request, send_file, send_from_directory
import psycopg2
from psycopg2.extras import RealDictCursor
from config import Config

app = Flask(__name__,
    static_folder='public',
    static_url_path=''
)
app.config.from_object(Config)
os.makedirs(app.config['REPORTS_DIR'], exist_ok=True)

def get_db():
    return psycopg2.connect(
        dsn=app.config['DB_URL'],
        cursor_factory=RealDictCursor
    )

# ==================== HEALTH CHECK (UPDATED) ====================
@app.route('/health')
def health_check():
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'version': '1.0.0-rc.4'
    }
    
    # Database check
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT 1')
        health_status['database'] = 'connected'
    except Exception as e:
        health_status['database'] = 'disconnected'
        health_status['status'] = 'unhealthy'
        health_status['database_error'] = str(e)

    # Check external asset server
    try:
        import requests
        response = requests.get(f"{app.config['ASSET_SERVER']}/nginx-health", timeout=5)
        health_status['asset_server'] = 'connected' if response.status_code == 200 else 'unreachable'
    except Exception as e:
        health_status['asset_server'] = 'disconnected'
        health_status['status'] = 'degraded'

    # Asset locations (now external)
    health_status['asset_locations'] = {
        'tiles': f"{app.config['TILES_BASE_URL']}",
        'cogs': f"{app.config['COGS_BASE_URL']}",
        'reports': f"{app.config['REPORTS_BASE_URL']}",
        'basemaps': f"{app.config['BASEMAPS_BASE_URL']}",
        'icons': f"{app.config['ICONS_BASE_URL']}"
    }

    status_code = 200 if health_status['status'] == 'healthy' else 503
    return jsonify(health_status), status_code

# ==================== HIERARCHICAL DROPDOWN ENDPOINTS ====================
@app.route('/api/countries')
def get_countries():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT country_name 
                    FROM sql_scat_query2 
                    WHERE country_name IS NOT NULL 
                    ORDER BY country_name
                """)
                countries = [row['country_name'] for row in cur.fetchall()]
                if not countries:
                    cur.execute("""
                        SELECT DISTINCT country_name 
                        FROM target 
                        WHERE country_name IS NOT NULL 
                        ORDER BY country_name
                    """)
                    countries = [row['country_name'] for row in cur.fetchall()]
        return jsonify(countries)
    except Exception as e:
        app.logger.error(f"Countries query failed: {e}")
        return jsonify([])

@app.route('/api/target-types/<country>')
def get_target_types(country):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.target_name 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name IS NOT NULL 
                    ORDER BY sq.target_name
                """, (country,))
                target_names = [row['target_name'] for row in cur.fetchall()]
        return jsonify(target_names)
    except Exception as e:
        app.logger.error(f"Target names query failed for {country}: {e}")
        return jsonify([])

@app.route('/api/image-ids/<country>/<target_name>')
def get_image_ids(country, target_name):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.image_id 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name = %s 
                    AND sq.image_id IS NOT NULL 
                    ORDER BY sq.image_id
                """, (country, target_name))
                image_ids = [row['image_id'] for row in cur.fetchall()]
        return jsonify(image_ids)
    except Exception as e:
        app.logger.error(f"Image IDs query failed for {country}/{target_name}: {e}")
        return jsonify([])

# ==================== UNIFIED DATA ENDPOINT ====================
@app.route('/api/unified-data/<image_id>')
def get_unified_data(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400

    target_names = request.args.getlist('target_name')
    target_classes = request.args.getlist('target_class')
    min_score = request.args.get('min_score', 0.0, type=float)
    max_score = request.args.get('max_score', 1.0, type=float)

    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # VECTOR DATA
                vector_query = """
                    SELECT 
                        sq.target_name,
                        sq.country_name,
                        sq.image_id, 
                        sq.image_date,
                        sq.target_class,
                        sq.score,
                        sq.st_x as centroid_lon,
                        sq.st_y as centroid_lat,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.image_id = %s
                """
                vector_params = [image_id]
                vector_conditions = []
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    vector_conditions.append(f"sq.target_name IN ({placeholders})")
                    vector_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    vector_conditions.append(f"sq.target_class IN ({placeholders})")
                    vector_params.extend(target_classes)
                if min_score > 0:
                    vector_conditions.append("sq.score >= %s")
                    vector_params.append(min_score)
                if max_score < 1.0:
                    vector_conditions.append("sq.score <= %s")
                    vector_params.append(max_score)
                if vector_conditions:
                    vector_query += " AND " + " AND ".join(vector_conditions)

                cur.execute(vector_query, vector_params)
                vector_rows = cur.fetchall()

                vector_features = []
                for row in vector_rows:
                    geometry_data = {
                        "type": "Polygon",
                        "coordinates": [[
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001]
                        ]]
                    }
                    vector_features.append({
                        "type": "Feature",
                        "geometry": geometry_data,
                        "properties": {
                            "id": f"{row['image_id']}_{row['target_class']}",
                            "target_class": row["target_class"],
                            "target_name": row["target_name"],
                            "target_type": row["target_type"],
                            "country_name": row["country_name"],
                            "score": float(row["score"]) if row["score"] is not None else None,
                            "centroid": [float(row["centroid_lon"]), float(row["centroid_lat"])]
                        }
                    })

                # CHART DATA
                chart_query = """
                    SELECT 
                        sq.target_name,
                        sq.target_class,
                        COUNT(*) as total_count,
                        AVG(sq.score) as avg_score,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.image_id = %s
                """
                chart_params = [image_id]
                chart_conditions = []
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    chart_conditions.append(f"sq.target_name IN ({placeholders})")
                    chart_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    chart_conditions.append(f"sq.target_class IN ({placeholders})")
                    chart_params.extend(target_classes)
                if min_score > 0:
                    chart_conditions.append("sq.score >= %s")
                    chart_params.append(min_score)
                if max_score < 1.0:
                    chart_conditions.append("sq.score <= %s")
                    chart_params.append(max_score)
                if chart_conditions:
                    chart_query += " AND " + " AND ".join(chart_conditions)
                chart_query += " GROUP BY sq.target_name, sq.target_class, t.target_type"
                chart_query += " ORDER BY total_count DESC"

                cur.execute(chart_query, chart_params)
                chart_rows = cur.fetchall()
                chart_data = [
                    {
                        'target_name': row['target_name'],
                        'target_class': row['target_class'],
                        'target_type': row['target_type'],
                        'total_count': row['total_count'],
                        'avg_score': float(row['avg_score']) if row['avg_score'] is not None else 0.0
                    }
                    for row in chart_rows
                ]

        return jsonify({
            "vector_data": {
                "type": "FeatureCollection", 
                "features": vector_features
            },
            "chart_data": chart_data
        })
    except Exception as e:
        app.logger.error(f"Unified data query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to retrieve unified data"}), 500

# ==================== REMOVED LOCAL ASSET ENDPOINTS ====================
# All static assets are now served by NGINX

# ==================== PAGE ROUTES ====================
@app.route('/api')
def api_documentation_page():
    return send_from_directory('.', 'api-docs.html')

@app.route('/health-page')
def health_page():
    return send_from_directory('.', 'health.html')

@app.route('/basemap')
def basemap_page():
    return send_from_directory('.', 'basemap.html')

@app.route('/historical-deployment')  
def historical_deployment_page():
    return send_from_directory('.', 'historical.html')

@app.route('/')
@app.route('/<path:path>')
def serve_frontend(path='index.html'):
    if os.path.exists(f"dist/{path}"):
        return send_from_directory('dist', path)
    else:
        return send_from_directory('dist', 'index.html')

# ==================== ERROR HANDLING ====================
@app.errorhandler(500)
def handle_internal_error(e):
    app.logger.error(f"Internal error: {str(e)}")
    return jsonify({"error": "Internal server error"}), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found"}), 404

@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY' 
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    app.run(host='127.0.0.1', port=5000, debug=False)  # debug=False for production
```

## 2. Updated Flask Config (`config.py`)

```python
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Database Configuration
    DB_URL = (
        f"postgresql://{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}"
        f"@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '5432')}"
        f"/{os.getenv('DB_NAME')}"
    )
    REPORTS_DIR = os.getenv('REPORTS_DIR', './reports')
    
    # Static Asset Server Configuration (UPDATED PORTS)
    ASSET_SERVER = os.getenv('ASSET_SERVER', 'http://localhost:8080')  # NGINX on 8080
    
    # Asset paths on the static server
    TILES_BASE_URL = f"{ASSET_SERVER}/tiles"
    COGS_BASE_URL = f"{ASSET_SERVER}/cogs" 
    REPORTS_BASE_URL = f"{ASSET_SERVER}/reports"
    BASEMAPS_BASE_URL = f"{ASSET_SERVER}/basemaps"
    ICONS_BASE_URL = f"{ASSET_SERVER}/icons"
    IMAGES_BASE_URL = f"{ASSET_SERVER}/images"
    
    # Security and Performance
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file upload
```

## 3. Updated Environment File (`.env`)

```bash
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=postgres
DB_USER=postgres
DB_PASSWORD=postgres
REPORTS_DIR=./reports

# Static Asset Server Configuration (UPDATED)
ASSET_SERVER=http://localhost:8080  # NGINX on port 8080
VITE_ASSET_SERVER=http://localhost:8080

# Optional: Connection pooling
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20

# Flask Configuration
FLASK_ENV=production
FLASK_DEBUG=0
```

## 4. Updated Vite Config (`vite.config.js`)

```javascript
import { defineConfig } from "vite";

export default defineConfig({
  optimizeDeps: {
    include: ["ol", "geotiff", "chart.js", "proj4"],
  },
  root: "./",
  base: "./",
  publicDir: "public",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    assetsDir: "assets",
    rollupOptions: {
      input: {
        main: "index.html",
        apiDocs: "api-docs.html",
        basemap: "basemap.html",
        historical: "historical.html",
        health: "health.html",
      },
      output: {
        assetFileNames: (assetInfo) => {
          let extType = assetInfo.name.split('.')[1];
          if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(extType)) {
            extType = 'images';
          }
          return `assets/${extType}/[name]-[hash][extname]`;
        },
        chunkFileNames: 'assets/js/[name]-[hash].js',
        entryFileNames: 'assets/js/[name]-[hash].js',
      },
    },
  },
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:5000",
      "/health": "http://localhost:5000",
      "/health-page": "http://localhost:5000",
      "/basemap": "http://localhost:5000",
      "/historical-deployment": "http://localhost:5000",
    },
    cors: true,
  },
  define: {
    "import.meta.env.VITE_ASSET_SERVER": JSON.stringify(
      process.env.VITE_ASSET_SERVER || "http://localhost:8080"  // UPDATED PORT
    ),
  },
});
```

## 5. Updated Frontend Config (`src/config.js`)

```javascript
export const CONFIG = {
  ASSET_SERVER: import.meta.env.VITE_ASSET_SERVER || "http://localhost:8080",  // UPDATED PORT
  API_BASE: "/api",
  TILES_BASE: "/tiles",
  COGS_BASE: "/cogs",
  REPORTS_BASE: "/reports",
  BASEMAPS_BASE: "/basemaps",
  ICONS_BASE: "/icons",
  IMAGES_BASE: "/images",
};

export function getAssetUrl(path) {
  // Remove leading slash if present to avoid double slashes
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  return `${CONFIG.ASSET_SERVER}/${cleanPath}`;
}

export async function checkAssetServer() {
  try {
    const response = await fetch(`${CONFIG.ASSET_SERVER}/nginx-health`, { 
      method: "GET",
      timeout: 5000 
    });
    return response.ok;
  } catch (error) {
    console.warn("Asset server not accessible:", error);
    return false;
  }
}
```

## 6. Updated Basemap.js Tile Loading

In `src/basemap.js`, update the tile loading function:

```javascript
async function loadImageryData(imageId) {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    document.getElementById(
      "basemapStatus"
    ).textContent = `Loading imagery for ${imageId}...`;

    const xyzSource = new XYZ({
      url: `${getAssetUrl(`tiles/${imageId}/{z}/{x}/{y}.png`)}`,
      crossOrigin: "anonymous",
      transition: 250,
    });

    imageryLayer.setSource(xyzSource);

    console.log("✅ Loaded XYZ imagery from asset server:", imageId);
    document.getElementById(
      "basemapStatus"
    ).textContent = `Imagery loaded: ${imageId}`;
  } catch (error) {
    console.error("Failed to load imagery:", error);
    document.getElementById("basemapStatus").textContent =
      "Error loading imagery - using basemap only";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}
```

## 7. Optimized NGINX Configuration (`nginx.conf`)

```nginx
worker_processes auto;
error_log logs/error.log warn;
pid logs/nginx.pid;

events {
    worker_connections 1024;
    use select;  # Better for Windows
}

http {
    include mime.types;
    default_type application/octet-stream;
    
    # Performance optimizations
    sendfile on;
    sendfile_max_chunk 512k;
    tcp_nopush on;
    directio 4m;
    
    # Buffer optimizations
    output_buffers 2 1m;
    postpone_output 1460;
    
    keepalive_timeout 30;
    client_max_body_size 100M;

    # Logging
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    access_log logs/access.log main;

    server {
        listen 8080;  # NGINX on 8080
        server_name localhost;
        
        # Security headers
        server_tokens off;
        
        # Root directory for static assets
        root ./assets;
        autoindex off;  # Security: disable directory listing
        
        # Default location - serve static files
        location / {
            try_files $uri $uri/ =404;
            
            # Smart caching based on file types
            location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
                expires 1y;
                add_header Cache-Control "public, immutable";
            }
            
            location ~* \.(json|geojson|pbf)$ {
                expires 6h;
                add_header Cache-Control "public, must-revalidate";
            }
            
            # Large files - different caching strategy
            location ~* \.(tiff|tif|cog)$ {
                expires 24h;
                add_header Cache-Control "public, must-revalidate";
                directio 8m;
                output_buffers 3 2m;
            }
        }

        # CORS for specific geospatial file types only
        location ~* \.(tiff|tif|geojson|json|pbf|cog)$ {
            add_header 'Access-Control-Allow-Origin' '*' always;
            add_header 'Access-Control-Allow-Methods' 'GET, HEAD, OPTIONS' always;
            add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range' always;
            add_header 'Access-Control-Expose-Headers' 'Content-Length,Content-Range' always;
            add_header 'Access-Control-Max-Age' 86400 always;
            
            # Handle OPTIONS preflight
            if ($request_method = 'OPTIONS') {
                add_header 'Access-Control-Allow-Origin' '*';
                add_header 'Access-Control-Allow-Methods' 'GET, HEAD, OPTIONS';
                add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
                add_header 'Access-Control-Max-Age' 86400;
                add_header 'Content-Length' 0;
                add_header 'Content-Type' 'text/plain; charset=utf-8';
                return 204;
            }
        }

        # Health check endpoint
        location /nginx-health {
            access_log off;
            return 200 "healthy\n";
            add_header Content-Type text/plain;
        }

        # Error pages
        error_page 404 /404.html;
        error_page 500 502 503 504 /50x.html;
        
        location = /50x.html {
            root html;
        }
    }
}
```

## 8. Updated Traefik Configuration

**traefik.yml**:
```yaml
global:
  checkNewVersion: false
  sendAnonymousUsage: false

log:
  level: INFO

entryPoints:
  web:
    address: ":8081"  # Traefik web on 8081

api:
  dashboard: true
  insecure: true

providers:
  file:
    filename: "dynamic.yml"
    watch: true
```

**dynamic.yml**:
```yaml
http:
  routers:
    # Static assets - HIGH PRIORITY
    tiles-router:
      rule: "PathPrefix(`/tiles`)"
      service: nginx-static
      priority: 100
      
    cogs-router:
      rule: "PathPrefix(`/cogs`)"
      service: nginx-static
      priority: 100
      
    basemaps-router:
      rule: "PathPrefix(`/basemaps`)"
      service: nginx-static
      priority: 100
      
    icons-router:
      rule: "PathPrefix(`/icons`)"
      service: nginx-static
      priority: 100
      
    reports-router:
      rule: "PathPrefix(`/reports`)"
      service: nginx-static
      priority: 100

    # API routes - MEDIUM PRIORITY
    api-router:
      rule: "PathPrefix(`/api`)"
      service: flask-app
      priority: 50
      
    # Health checks
    health-router:
      rule: "Path(`/health`, `/nginx-health`)"
      service: nginx-static
      priority: 200

    # Dashboard
    dashboard:
      rule: "PathPrefix(`/dashboard`) || PathPrefix(`/api`)"
      service: api@internal
      entryPoints:
        - web

    # Catch-all for frontend app - LOWEST PRIORITY
    app-router:
      rule: "PathPrefix(`/`)"
      service: flask-app
      priority: 1

  services:
    nginx-static:
      loadBalancer:
        servers:
          - url: "http://127.0.0.1:8080"  # NGINX on 8080
        healthCheck:
          path: /nginx-health
          interval: 30s
          timeout: 5s

    flask-app:
      loadBalancer:
        servers:
          - url: "http://127.0.0.1:5000"  # Flask on 5000
        healthCheck:
          path: /health
          interval: 30s
          timeout: 5s
```

## Key Changes Summary:

1. **Port Optimization**: NGINX on 8080, Traefik on 8081, Flask on 5000
2. **Smart Caching**: Different strategies per file type
3. **Security**: Disabled directory listing, proper CORS scoping
4. **Health Checks**: Both Flask and NGINX have health endpoints
5. **Performance**: Optimized buffers and file handling for geospatial data
6. **Routing Priority**: Static assets > API > Frontend app

This hybrid architecture provides the best performance and security while maintaining your air-gapped deployment requirements.

### But what about the  node+Vite app being derved on :5173 earlier, with the Flask backend at :5000 - now being forwarded to nginx by traefik? How does this work out? How would I access the main app (after being deployed on the shared network drive/air-gapped network to the various clients on it) then?

You've identified a critical architectural question! Let me clarify the production deployment architecture and how clients will access the application.

## Current Architecture Clarification

**Development Setup:**
- Vite Dev Server: `:5173` (hot reload, development only)
- Flask API: `:5000` (backend API)
- **This goes away in production**

**Production Setup:**
- Traefik: `:8081` (main entry point for clients)
- Flask App: `:5000` (serves HTML pages + API, **not directly exposed**)
- NGINX: `:8080` (serves static assets, **not directly exposed**)

## How Clients Access the Deployed App

### For Air-Gapped Network Clients:

**Single Access Point:** `http://server-ip:8081`

**What clients see:**
```
Client Browser → http://192.168.1.100:8081/ (Traefik)
                     ↓
           /api/*    → Flask (:5000) - API calls
           /tiles/*  → NGINX (:8080) - Map tiles  
           /cogs/*   → NGINX (:8080) - GeoTIFF files
           /*        → Flask (:5000) - HTML pages
```

### Updated Deployment Architecture

```bash
# PRODUCTION (what clients access)
http://server-ip:8081/           ← Clients only hit this port
    ↓
Traefik (:8081) - Reverse Proxy
    ├── /api/* → Flask App (:5000) - API + HTML pages
    ├── /tiles/* → NGINX (:8080) - Static assets
    ├── /cogs/* → NGINX (:8080) - Static assets
    └── /* → Flask App (:5000) - HTML pages

# DEVELOPMENT (internal only, not exposed to clients)
Vite (:5173) - Dev server (build time only)
```

## Required Configuration Updates

### 1. Update Flask App to Serve Built Frontend

**Replace** the Vite dev server proxy with static file serving in `app.py`:

```python
# ==================== FRONTEND SERVING (PRODUCTION) ====================
@app.route('/')
@app.route('/<path:path>')
def serve_frontend(path='index.html'):
    # Serve the built Vite frontend from dist directory
    try:
        return send_from_directory('dist', path)
    except:
        return send_from_directory('dist', 'index.html')

# Remove all Vite dev server proxy routes - they're not needed in production
```

### 2. Update Vite Configuration for Production

**vite.config.js:**
```javascript
import { defineConfig } from "vite";

export default defineConfig({
  optimizeDeps: {
    include: ["ol", "geotiff", "chart.js", "proj4"],
  },
  root: "./",
  base: "/",  // Changed from "./" for production
  publicDir: "public",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    assetsDir: "assets",
    rollupOptions: {
      input: {
        main: "index.html",
        apiDocs: "api-docs.html", 
        basemap: "basemap.html",
        historical: "historical.html",
        health: "health.html",
      },
    },
  },
  // REMOVE the entire server section - not needed in production
  // server: {
  //   port: 5173,
  //   proxy: { ... }
  // },
  define: {
    "import.meta.env.VITE_ASSET_SERVER": JSON.stringify(
      process.env.VITE_ASSET_SERVER || "/"  // Relative paths in production
    ),
  },
});
```

### 3. Update Frontend Config for Production

**src/config.js:**
```javascript
export const CONFIG = {
  // Use relative paths in production since everything goes through Traefik
  ASSET_SERVER: import.meta.env.VITE_ASSET_SERVER || "",
  API_BASE: "/api",
  TILES_BASE: "/tiles",      // Traefik routes these to NGINX
  COGS_BASE: "/cogs",        // Traefik routes these to NGINX
  REPORTS_BASE: "/reports",  // Traefik routes these to NGINX
  BASEMAPS_BASE: "/basemaps",// Traefik routes these to NGINX
  ICONS_BASE: "/icons",      // Traefik routes these to NGINX
  IMAGES_BASE: "/images",    // Traefik routes these to NGINX
};

export function getAssetUrl(path) {
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  if (CONFIG.ASSET_SERVER) {
    return `${CONFIG.ASSET_SERVER}/${cleanPath}`;
  } else {
    return `/${cleanPath}`;
  }
}
```

### 4. Update Environment Variables

**.env:**
```bash
# Production Configuration
ASSET_SERVER=  # Empty - use relative paths
VITE_ASSET_SERVER=  # Empty - use relative paths

# Keep existing DB config
DB_HOST=localhost
DB_PORT=5432
DB_NAME=postgres
DB_USER=postgres
DB_PASSWORD=postgres
REPORTS_DIR=./reports
```

## Deployment Process for Shared Network Drive

### 1. Build for Production
```bash
# Build the frontend with relative paths
VITE_ASSET_SERVER= npm run build

# Deploy to shared drive
cp -r dist/ /mnt/shared-drive/geodoxy-app/
cp -r static-asset-server/ /mnt/shared-drive/geodoxy-app/
```

### 2. Client Access Instructions

**For each Windows client on the air-gapped network:**

```batch
# On each client machine
cd D:\shared-drive\geodoxy-app

# Start services (run as administrator)
start nginx -p static-asset-server/ -c conf/nginx.conf
start python app.py
start traefik --configFile=traefik.yml

# Access application at:
# http://localhost:8081
```

### 3. Windows Batch File for Easy Startup

**start-geodoxy.bat:**
```batch
@echo off
echo Starting GeoDoxy Application...

cd /d "D:\shared-drive\geodoxy-app"

echo Starting NGINX static asset server...
start /B nginx -p static-asset-server/ -c conf/nginx.conf

echo Starting Flask API server...
start /B python app.py

echo Starting Traefik reverse proxy...
start /B traefik --configFile=traefik.yml

echo.
echo GeoDoxy is starting up...
echo Access the application at: http://localhost:8081
echo API Documentation: http://localhost:8081/api
echo Health Dashboard: http://localhost:8081/health-page

timeout /t 5
start http://localhost:8081
```

## Summary: Client Experience

**Each air-gapped client:**
1. Navigates to shared drive `D:\shared-drive\geodoxy-app\`
2. Runs `start-geodoxy.bat` 
3. Opens browser to `http://localhost:8081`
4. **Everything works** - maps, tiles, APIs, all through single port 8081

**Key Benefits:**
- ✅ Single entry point for clients
- ✅ No port conflicts (only 8081 exposed)
- ✅ Static assets served efficiently via NGINX
- ✅ APIs handled by Flask
- ✅ Easy deployment via shared drive
- ✅ Works completely air-gapped

The Vite dev server on `:5173` is completely eliminated in production - it was only for development hot-reloading. In production, Flask serves the built frontend HTML files directly.

