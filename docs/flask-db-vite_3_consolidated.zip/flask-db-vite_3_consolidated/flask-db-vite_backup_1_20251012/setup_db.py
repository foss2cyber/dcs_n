# setup_db.py
"""
Automated DB setup for air-gapped deployment.
- Creates postgres (if not exists)
- Enables PostGIS
- Loads schema + sample data

Run as: python setup_db.py
Requires: psycopg2, superuser access (or pre-created DB)
"""

import os
import sys
import psycopg2
from psycopg2 import sql

# DB connection for admin (to create DB)
ADMIN_DB_URL = "postgresql://postgres:postgres@localhost:5432/postgres"
TARGET_DB = "postgres"
TARGET_DB_URL = "postgresql://postgres:postgres@localhost:5432/postgres"

def create_database():
    """Create postgres if it doesn't exist."""
    conn = psycopg2.connect(ADMIN_DB_URL)
    conn.autocommit = True
    cur = conn.cursor()
    try:
        cur.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(TARGET_DB)))
        print(f"✅ Created database: {TARGET_DB}")
    except psycopg2.errors.DuplicateDatabase:
        print(f"ℹ️  Database '{TARGET_DB}' already exists.")
    finally:
        cur.close()
        conn.close()

def execute_sql_file(db_url, filepath):
    """Execute a .sql file against a database."""
    with psycopg2.connect(db_url) as conn:
        with conn.cursor() as cur:
            with open(filepath, 'r', encoding='utf-8') as f:
                cur.execute(f.read())
            conn.commit()
    print(f"✅ Executed: {filepath}")

def main():
    if not os.path.exists('init_db.sql') or not os.path.exists('sample_data.sql'):
        print("❌ Missing SQL files. Ensure init_db.sql and sample_data.sql are in the current directory.")
        sys.exit(1)

    print("🔧 Setting up geospatial database...")
    create_database()
    execute_sql_file(TARGET_DB_URL, 'init_db.sql')
    execute_sql_file(TARGET_DB_URL, 'sample_data.sql')
    print("\n🎉 Database setup complete!")
    print(f"   - DB: {TARGET_DB}")
    print(f"   - Tables: findings, target, comprehensive_query")
    print(f"   - Sample  3 image IDs loaded")

if __name__ == '__main__':
    main()