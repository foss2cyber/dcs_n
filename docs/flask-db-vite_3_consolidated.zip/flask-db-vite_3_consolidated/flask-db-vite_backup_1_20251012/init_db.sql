-- init_db.sql
-- Active: 1758729831760@@localhost@5432@postgres@public
-- init_db.sql - Corrected schema for geospatial app
-- Enable PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS sql_scat_query2 CASCADE;

DROP TABLE IF EXISTS comprehensive_query CASCADE;

DROP TABLE IF EXISTS findings CASCADE;

DROP TABLE IF EXISTS target CASCADE;

-- Table: findings (exact schema from your sample)
CREATE TABLE findings (
    id INTEGER PRIMARY KEY,
    image_id CHARACTER VARYING(100) NOT NULL,
    image_date DATE,
    target_class CHARACTER VARYING(30),
    score DOUBLE PRECISION,
    target_geom GEOMETRY (POLYGON, 4326)
);

-- Table: target (exact schema from your sample)
CREATE TABLE target (
    id INTEGER PRIMARY KEY,
    target_type CHARACTER VARYING(50),
    target_name CHARACTER VARYING(50),
    country_name CHARACTER VARYING(25),
    target_geom GEOMETRY (POLYGON, 4326)
);

-- Table: comprehensive_query (exact schema from your sample)
CREATE TABLE comprehensive_query (
    target_name CHARACTER VARYING(50) PRIMARY KEY,
    country_name CHARACTER VARYING(25),
    image_id CHARACTER VARYING(100) NOT NULL,
    image_date DATE,
    target_class CHARACTER VARYING(30),
    total_count BIGINT
);

-- Table: sql_scat_query2 (CORRECTED - removed invalid PRIMARY KEY constraint)
CREATE TABLE sql_scat_query2 (
    id SERIAL PRIMARY KEY, -- Added auto-incrementing primary key
    country_name CHARACTER VARYING(25),
    target_name CHARACTER VARYING(50),
    image_id CHARACTER VARYING(100) NOT NULL,
    image_date DATE,
    target_class CHARACTER VARYING(30),
    score DOUBLE PRECISION,
    st_x DOUBLE PRECISION,
    st_y DOUBLE PRECISION
);

-- Create spatial indexes for performance
CREATE INDEX IF NOT EXISTS idx_findings_geom ON findings USING GIST (target_geom);

CREATE INDEX IF NOT EXISTS idx_findings_image_id ON findings (image_id);

CREATE INDEX IF NOT EXISTS idx_target_geom ON target USING GIST (target_geom);

CREATE INDEX IF NOT EXISTS idx_comprehensive_query_image_id ON comprehensive_query (image_id);

CREATE INDEX IF NOT EXISTS idx_sql_scat_query2_image_id ON sql_scat_query2 (image_id);

-- Clear existing data
DELETE FROM sql_scat_query2;

DELETE FROM comprehensive_query;

DELETE FROM findings;

DELETE FROM target;

-- Insert your exact sample data for IX200925XPESSCX1X77G7X_gcr
INSERT INTO
    findings (
        id,
        image_id,
        image_date,
        target_class,
        score,
        target_geom
    )
VALUES (
        1,
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'aircraft',
        0.95,
        ST_GeomFromText (
            'POLYGON((8.550 50.040, 8.552 50.040, 8.552 50.038, 8.550 50.038, 8.550 50.040))',
            4326
        )
    ),
    (
        2,
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'service_vehicle',
        0.89,
        ST_GeomFromText (
            'POLYGON((8.553 50.041, 8.555 50.041, 8.555 50.039, 8.553 50.039, 8.553 50.041))',
            4326
        )
    );

INSERT INTO
    comprehensive_query (
        target_name,
        country_name,
        image_id,
        image_date,
        target_class,
        total_count
    )
VALUES (
        'Frankfurt_Airport_Aircraft_1',
        'Germany',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'aircraft',
        1
    ),
    (
        'Frankfurt_Airport_Service_1',
        'Germany',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'service_vehicle',
        1
    );

INSERT INTO
    sql_scat_query2 (
        country_name,
        target_name,
        image_id,
        image_date,
        target_class,
        score,
        st_x,
        st_y
    )
VALUES (
        'Germany',
        'Frankfurt_Airport_Aircraft_1',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'aircraft',
        0.95,
        8.551,
        50.039
    ),
    (
        'Germany',
        'Frankfurt_Airport_Service_1',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'service_vehicle',
        0.89,
        8.554,
        50.040
    );

-- Optional: Verify the data was inserted correctly
SELECT 'findings' AS table_name, COUNT(*) AS row_count
FROM findings
UNION ALL
SELECT 'comprehensive_query', COUNT(*)
FROM comprehensive_query
UNION ALL
SELECT 'sql_scat_query2', COUNT(*)
FROM sql_scat_query2;