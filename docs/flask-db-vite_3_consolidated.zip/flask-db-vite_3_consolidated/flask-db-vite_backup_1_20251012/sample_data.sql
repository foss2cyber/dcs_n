-- sample_data.sql
-- Inserts synthetic aircraft & vehicle detections for 3 image IDs

-- Clear existing data (idempotent)
DELETE FROM comprehensive_query;

DELETE FROM target;

DELETE FROM findings;

-- 1. IX251024XPESSCX1X77G7X_gcr (2024-10-25)
INSERT INTO
    findings (
        image_id,
        target_class,
        target_geom,
        image_date
    )
VALUES (
        'IX251024XPESSCX1X77G7X_gcr',
        'aircraft',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5700, 50.0350),
                        ST_Point (8.5706, 50.0350),
                        ST_Point (8.5706, 50.0344),
                        ST_Point (8.5700, 50.0344),
                        ST_Point (8.5700, 50.0350)
                    ]
                )
            ),
            4326
        ),
        '2024-10-25'
    ),
    (
        'IX251024XPESSCX1X77G7X_gcr',
        'service_vehicle',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5710, 50.0360),
                        ST_Point (8.5713, 50.0360),
                        ST_Point (8.5713, 50.0357),
                        ST_Point (8.5710, 50.0357),
                        ST_Point (8.5710, 50.0360)
                    ]
                )
            ),
            4326
        ),
        '2024-10-25'
    );

INSERT INTO
    target (
        image_id,
        target_type,
        target_geom,
        country_name
    )
VALUES (
        'IX251024XPESSCX1X77G7X_gcr',
        'commercial_airliner',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5700, 50.0350),
                        ST_Point (8.5706, 50.0350),
                        ST_Point (8.5706, 50.0344),
                        ST_Point (8.5700, 50.0344),
                        ST_Point (8.5700, 50.0350)
                    ]
                )
            ),
            4326
        ),
        'Germany'
    ),
    (
        'IX251024XPESSCX1X77G7X_gcr',
        'ground_support',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5710, 50.0360),
                        ST_Point (8.5713, 50.0360),
                        ST_Point (8.5713, 50.0357),
                        ST_Point (8.5710, 50.0357),
                        ST_Point (8.5710, 50.0360)
                    ]
                )
            ),
            4326
        ),
        'Germany'
    );

INSERT INTO
    comprehensive_query (
        image_id,
        target_class,
        target_type,
        image_date,
        total_count,
        score
    )
VALUES (
        'IX251024XPESSCX1X77G7X_gcr',
        'aircraft',
        'commercial_airliner',
        '2024-10-25',
        1,
        0.96
    ),
    (
        'IX251024XPESSCX1X77G7X_gcr',
        'service_vehicle',
        'ground_support',
        '2024-10-25',
        1,
        0.89
    );

-- 2. IX261024XPESSCX1X77G7X_gcr (2024-10-26)
INSERT INTO
    findings (
        image_id,
        target_class,
        target_geom,
        image_date
    )
VALUES (
        'IX261024XPESSCX1X77G7X_gcr',
        'aircraft',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5720, 50.0330),
                        ST_Point (8.5726, 50.0330),
                        ST_Point (8.5726, 50.0324),
                        ST_Point (8.5720, 50.0324),
                        ST_Point (8.5720, 50.0330)
                    ]
                )
            ),
            4326
        ),
        '2024-10-26'
    );

INSERT INTO
    target (
        image_id,
        target_type,
        target_geom,
        country_name
    )
VALUES (
        'IX261024XPESSCX1X77G7X_gcr',
        'cargo_aircraft',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5720, 50.0330),
                        ST_Point (8.5726, 50.0330),
                        ST_Point (8.5726, 50.0324),
                        ST_Point (8.5720, 50.0324),
                        ST_Point (8.5720, 50.0330)
                    ]
                )
            ),
            4326
        ),
        'Germany'
    );

INSERT INTO
    comprehensive_query (
        image_id,
        target_class,
        target_type,
        image_date,
        total_count,
        score
    )
VALUES (
        'IX261024XPESSCX1X77G7X_gcr',
        'aircraft',
        'cargo_aircraft',
        '2024-10-26',
        1,
        0.92
    );

-- 3. IX271024XPESSCX1X77G7X_gcr (2024-10-27)
INSERT INTO
    findings (
        image_id,
        target_class,
        target_geom,
        image_date
    )
VALUES (
        'IX271024XPESSCX1X77G7X_gcr',
        'aircraft',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5680, 50.0370),
                        ST_Point (8.5686, 50.0370),
                        ST_Point (8.5686, 50.0364),
                        ST_Point (8.5680, 50.0364),
                        ST_Point (8.5680, 50.0370)
                    ]
                )
            ),
            4326
        ),
        '2024-10-27'
    ),
    (
        'IX271024XPESSCX1X77G7X_gcr',
        'aircraft',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5690, 50.0380),
                        ST_Point (8.5696, 50.0380),
                        ST_Point (8.5696, 50.0374),
                        ST_Point (8.5690, 50.0374),
                        ST_Point (8.5690, 50.0380)
                    ]
                )
            ),
            4326
        ),
        '2024-10-27'
    );

INSERT INTO
    target (
        image_id,
        target_type,
        target_geom,
        country_name
    )
VALUES (
        'IX271024XPESSCX1X77G7X_gcr',
        'passenger_airliner',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5680, 50.0370),
                        ST_Point (8.5686, 50.0370),
                        ST_Point (8.5686, 50.0364),
                        ST_Point (8.5680, 50.0364),
                        ST_Point (8.5680, 50.0370)
                    ]
                )
            ),
            4326
        ),
        'Germany'
    ),
    (
        'IX271024XPESSCX1X77G7X_gcr',
        'passenger_airliner',
        ST_SetSRID (
            ST_MakePolygon (
                ST_MakeLine (
                    ARRAY[
                        ST_Point (8.5690, 50.0380),
                        ST_Point (8.5696, 50.0380),
                        ST_Point (8.5696, 50.0374),
                        ST_Point (8.5690, 50.0374),
                        ST_Point (8.5690, 50.0380)
                    ]
                )
            ),
            4326
        ),
        'Germany'
    );

INSERT INTO
    comprehensive_query (
        image_id,
        target_class,
        target_type,
        image_date,
        total_count,
        score
    )
VALUES (
        'IX271024XPESSCX1X77G7X_gcr',
        'aircraft',
        'passenger_airliner',
        '2024-10-27',
        2,
        0.97
    );