#!/bin/bash
set -e  # Exit on error

# === CONFIG ===
IMAGE_ID="IX200925XPESSCX1X77G7X_gcr"
COG_PATH="./public/cogs/${IMAGE_ID}.tiff"
TILE_DIR="./public/tiles/${IMAGE_ID}"
VRT_PATH="./public/tiles/${IMAGE_ID}.vrt"

# Create output dirs
mkdir -p "$(dirname "$VRT_PATH")" "$TILE_DIR"

# === STEP 1: Get stats to auto-detect min/max ===
echo "📊 Analyzing raster statistics..."
gdalinfo -stats "$COG_PATH" > /tmp/gdalinfo.txt

# Extract min/max for first 3 bands (RGB)
# Assumes bands are in order: Red, Green, Blue
BAND1_MIN=$(grep -A10 "Band 1" /tmp/gdalinfo.txt | grep "STATISTICS_MINIMUM" | cut -d'=' -f2 | xargs)
BAND1_MAX=$(grep -A10 "Band 1" /tmp/gdalinfo.txt | grep "STATISTICS_MAXIMUM" | cut -d'=' -f2 | xargs)
BAND2_MIN=$(grep -A10 "Band 2" /tmp/gdalinfo.txt | grep "STATISTICS_MINIMUM" | cut -d'=' -f2 | xargs)
BAND2_MAX=$(grep -A10 "Band 2" /tmp/gdalinfo.txt | grep "STATISTICS_MAXIMUM" | cut -d'=' -f2 | xargs)
BAND3_MIN=$(grep -A10 "Band 3" /tmp/gdalinfo.txt | grep "STATISTICS_MINIMUM" | cut -d'=' -f2 | xargs)
BAND3_MAX=$(grep -A10 "Band 3" /tmp/gdalinfo.txt | grep "STATISTICS_MAXIMUM" | cut -d'=' -f2 | xargs)

# Fallback if stats missing (e.g., no -stats run before)
if [[ -z "$BAND1_MIN" || "$BAND1_MIN" == "nan" ]]; then
  echo "⚠️  No stats found. Computing now (may take a moment)..."
  gdalinfo -stats "$COG_PATH" >/dev/null
  # Re-extract
  BAND1_MIN=$(grep -A10 "Band 1" /tmp/gdalinfo.txt | grep "STATISTICS_MINIMUM" | cut -d'=' -f2 | xargs)
  BAND1_MAX=$(grep -A10 "Band 1" /tmp/gdalinfo.txt | grep "STATISTICS_MAXIMUM" | cut -d'=' -f2 | xargs)
  BAND2_MIN=$(grep -A10 "Band 2" /tmp/gdalinfo.txt | grep "STATISTICS_MINIMUM" | cut -d'=' -f2 | xargs)
  BAND2_MAX=$(grep -A10 "Band 2" /tmp/gdalinfo.txt | grep "STATISTICS_MAXIMUM" | cut -d'=' -f2 | xargs)
  BAND3_MIN=$(grep -A10 "Band 3" /tmp/gdalinfo.txt | grep "STATISTICS_MINIMUM" | cut -d'=' -f2 | xargs)
  BAND3_MAX=$(grep -A10 "Band 3" /tmp/gdalinfo.txt | grep "STATISTICS_MAXIMUM" | cut -d'=' -f2 | xargs)
fi

echo "RGBO Stats:"
echo "  Band 1 (Red):   $BAND1_MIN → $BAND1_MAX"
echo "  Band 2 (Green): $BAND2_MIN → $BAND2_MAX"
echo "  Band 3 (Blue):  $BAND3_MIN → $BAND3_MAX"

# Optional: Apply slight contrast enhancement (e.g., clip 2% tails)
# For now, we use full range. Replace with percentiles if needed.

# === STEP 2: Create 8-bit VRT with auto-scaled bands ===
echo "🖼️  Creating 8-bit VRT..."
gdal_translate \
  -of VRT \
  -ot Byte \
  -b 1 -b 2 -b 3 \
  -scale_1 "$BAND1_MIN" "$BAND1_MAX" 0 255 \
  -scale_2 "$BAND2_MIN" "$BAND2_MAX" 0 255 \
  -scale_3 "$BAND3_MIN" "$BAND3_MAX" 0 255 \
  -colorinterp red,green,blue \
  "$COG_PATH" \
  "$VRT_PATH"

# === STEP 3: Generate XYZ tiles ===
echo "🗺️  Generating XYZ tiles (zoom 10–14)..."
gdal2tiles.py \
  --profile=mercator \
  --zoom=10-14 \
  --resampling=near \
  --processes=4 \
  --xyz \
  "$VRT_PATH" \
  "$TILE_DIR"

# === STEP 4: Cleanup ===
rm -f /tmp/gdalinfo.txt
# Optional: keep VRT for debugging, or remove:
# rm "$VRT_PATH"

echo "✅ Tiles generated at: $TILE_DIR"
echo "🌐 Use URL pattern: /tiles/${IMAGE_ID}/{z}/{x}/{y}.png"

# After gdal_translate to VRT, apply histogram stretch via gdal_contrast_stretch (if available)
# Or use: gdal_translate -scale with percentiles (requires custom script)