-- Clear existing data
DELETE FROM sql_scat_query2;

DELETE FROM comprehensive_query;

DELETE FROM findings;

DELETE FROM target;

-- Sample data for IX200925XPESSCX1X77G7X_gcr with new target classes
INSERT INTO
    findings (
        id,
        image_id,
        image_date,
        target_class,
        score,
        target_geom
    )
VALUES (
        1,
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AF-CGAA-1',
        0.95,
        ST_GeomFromText (
            'POLYGON((8.550 50.040, 8.552 50.040, 8.552 50.038, 8.550 50.038, 8.550 50.040))',
            4326
        )
    ),
    (
        2,
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AP-CGSV-1',
        0.89,
        ST_GeomFromText (
            'POLYGON((8.553 50.041, 8.555 50.041, 8.555 50.039, 8.553 50.039, 8.553 50.041))',
            4326
        )
    );

INSERT INTO
    target (
        id,
        target_type,
        target_name,
        country_name,
        target_geom
    )
VALUES (
        1,
        'airfield',
        'Frankfurt_Airport_Aircraft_1',
        'Germany',
        ST_GeomFromText (
            'POLYGON((8.550 50.040, 8.552 50.040, 8.552 50.038, 8.550 50.038, 8.550 50.040))',
            4326
        )
    ),
    (
        2,
        'airport',
        'Frankfurt_Airport_Service_1',
        'Germany',
        ST_GeomFromText (
            'POLYGON((8.553 50.041, 8.555 50.041, 8.555 50.039, 8.553 50.039, 8.553 50.041))',
            4326
        )
    );

INSERT INTO
    comprehensive_query (
        target_name,
        country_name,
        image_id,
        image_date,
        target_class,
        total_count,
        score
    )
VALUES (
        'Frankfurt_Airport_Aircraft_1',
        'Germany',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AF-CGAA-1',
        1,
        0.95
    ),
    (
        'Frankfurt_Airport_Service_1',
        'Germany',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AP-CGSV-1',
        1,
        0.89
    );

INSERT INTO
    sql_scat_query2 (
        country_name,
        target_name,
        image_id,
        image_date,
        target_class,
        score,
        st_x,
        st_y
    )
VALUES (
        'Germany',
        'Frankfurt_Airport_Aircraft_1',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AF-CGAA-1',
        0.95,
        8.551,
        50.039
    ),
    (
        'Germany',
        'Frankfurt_Airport_Service_1',
        'IX200925XPESSCX1X77G7X_gcr',
        '2025-09-20',
        'FR-AP-CGSV-1',
        0.89,
        8.554,
        50.040
    );

-- Additional sample data with new target classes
INSERT INTO
    findings (
        id,
        image_id,
        image_date,
        target_class,
        score,
        target_geom
    )
VALUES (
        3,
        'IX251024XPESSCX1X77G7X_gcr',
        '2024-10-25',
        'FR-AF-CPA-2',
        0.92,
        ST_GeomFromText (
            'POLYGON((8.5700 50.0350, 8.5706 50.0350, 8.5706 50.0344, 8.5700 50.0344, 8.5700 50.0350))',
            4326
        )
    ),
    (
        4,
        'IX251024XPESSCX1X77G7X_gcr',
        '2024-10-25',
        'FR-AP-CMV-2',
        0.87,
        ST_GeomFromText (
            'POLYGON((8.5710 50.0360, 8.5713 50.0360, 8.5713 50.0357, 8.5710 50.0357, 8.5710 50.0360))',
            4326
        )
    );

INSERT INTO
    target (
        id,
        target_type,
        target_name,
        country_name,
        target_geom
    )
VALUES (
        3,
        'airfield',
        'Frankfurt_Airport_Aircraft_2',
        'Germany',
        ST_GeomFromText (
            'POLYGON((8.5700 50.0350, 8.5706 50.0350, 8.5706 50.0344, 8.5700 50.0344, 8.5700 50.0350))',
            4326
        )
    ),
    (
        4,
        'airport',
        'Frankfurt_Airport_Service_2',
        'Germany',
        ST_GeomFromText (
            'POLYGON((8.5710 50.0360, 8.5713 50.0360, 8.5713 50.0357, 8.5710 50.0357, 8.5710 50.0360))',
            4326
        )
    );

INSERT INTO
    comprehensive_query (
        target_name,
        country_name,
        image_id,
        image_date,
        target_class,
        total_count,
        score
    )
VALUES (
        'Frankfurt_Airport_Aircraft_2',
        'Germany',
        'IX251024XPESSCX1X77G7X_gcr',
        '2024-10-25',
        'FR-AF-CPA-2',
        1,
        0.92
    ),
    (
        'Frankfurt_Airport_Service_2',
        'Germany',
        'IX251024XPESSCX1X77G7X_gcr',
        '2024-10-25',
        'FR-AP-CMV-2',
        1,
        0.87
    );

INSERT INTO
    sql_scat_query2 (
        country_name,
        target_name,
        image_id,
        image_date,
        target_class,
        score,
        st_x,
        st_y
    )
VALUES (
        'Germany',
        'Frankfurt_Airport_Aircraft_2',
        'IX251024XPESSCX1X77G7X_gcr',
        '2024-10-25',
        'FR-AF-CPA-2',
        0.92,
        8.5703,
        50.0347
    ),
    (
        'Germany',
        'Frankfurt_Airport_Service_2',
        'IX251024XPESSCX1X77G7X_gcr',
        '2024-10-25',
        'FR-AP-CMV-2',
        0.87,
        8.57115,
        50.03585
    );