I'll implement all three required changes. Let me start with the confidence scores conversion to percentages, then update the basemap page, and finally restructure the historical page.

## 1. Confidence Scores as Percentages

**File: `main.js`** - Update the confidence score handling:

```javascript
// ==================== UPDATED CONFIDENCE SCORE HANDLING (0-100%) ====================

/**
 * Load filter options with percentage-based score range
 */
async function loadFilterOptions(imageId) {
    try {
        console.log("🎛️ Loading contextual filter options for:", imageId, currentSelections);

        // Build query parameters with current hierarchical context
        const params = new URLSearchParams();
        if (currentSelections.country) {
            params.append("country", currentSelections.country);
        }
        if (currentSelections.targetType) {
            params.append("target_name", currentSelections.targetType);
        }

        const res = await fetch(`/api/filter-options/${imageId}?${params}`);
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        const options = await res.json();

        console.log("🎛️ Contextual filter options received:", options);

        const classFilter = document.getElementById("classFilter");
        if (classFilter) {
            const currentClassValue = classFilter.value;
            classFilter.innerHTML =
                '<option value="">All Classes</option>' +
                (options.target_classes && Array.isArray(options.target_classes)
                    ? options.target_classes
                          .map((cls) => `<option value="${cls}">${cls}</option>`)
                          .join("")
                    : "");

            // Preserve current selection if it still exists in new options
            if (
                currentClassValue &&
                options.target_classes.includes(currentClassValue)
            ) {
                classFilter.value = currentClassValue;
            }
            console.log("🎛️ Class filter populated");
        }

        // Target name filter
        const nameFilter = document.getElementById("nameFilter");
        if (nameFilter) {
            const currentNameValue = nameFilter.value;
            nameFilter.innerHTML =
                '<option value="">All Names</option>' +
                (options.target_names && Array.isArray(options.target_names)
                    ? options.target_names
                          .map((name) => `<option value="${name}">${name}</option>`)
                          .join("")
                    : "");

            // Preserve current selection if it still exists
            if (
                currentNameValue &&
                options.target_names.includes(currentNameValue)
            ) {
                nameFilter.value = currentNameValue;
            }
            console.log("🎛️ Name filter populated with contextual target_names:", options.target_names);
        }

        const scoreRange = document.getElementById("scoreRange");
        const scoreValue = document.getElementById("scoreValue");
        if (scoreRange && scoreValue && options.score_range) {
            // Convert backend 0-1 range to 0-100 for frontend
            const minScorePercent = (options.score_range.min || 0) * 100;
            const maxScorePercent = (options.score_range.max || 1) * 100;
            
            scoreRange.min = 0;
            scoreRange.max = 100;
            scoreRange.step = 0.1;

            // Convert current score from 0-1 to 0-100 if needed
            let currentScorePercent = 0;
            if (currentFilters.min_score !== undefined) {
                currentScorePercent = currentFilters.min_score * 100;
            }

            scoreRange.value = currentScorePercent;
            scoreValue.textContent = `${parseFloat(currentScorePercent).toFixed(1)}%`;
            console.log("🎛️ Score range configured for percentages:", { min: minScorePercent, max: maxScorePercent });
        }

        // Update filter context display
        updateFilterContextDisplay();
    } catch (error) {
        console.error("Failed to load filter options:", error);
    }
}

/**
 * Get current filters with percentage to decimal conversion
 */
function getCurrentFilters() {
    const filters = {};
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");

    // Apply filters based on what's selected
    if (nameFilter && nameFilter.value) {
        filters.target_name = [nameFilter.value];
        console.log("🎛️ Filtering by target_name:", nameFilter.value);
    } else if (classFilter && classFilter.value) {
        filters.target_class = [classFilter.value];
        console.log("🎛️ Filtering by target_class:", classFilter.value);
    }

    // Apply score filter - convert percentage to decimal
    if (scoreRange && parseFloat(scoreRange.value) > 0) {
        filters.min_score = parseFloat(scoreRange.value) / 100;
        console.log("🎛️ Filtering by min_score:", filters.min_score, `(${scoreRange.value}%)`);
    }

    console.log("🎛️ Final filters applied:", filters);
    return filters;
}

// Update score display in real-time
const scoreRange = document.getElementById("scoreRange");
const scoreValue = document.getElementById("scoreValue");
if (scoreRange && scoreValue) {
    scoreRange.addEventListener('input', function() {
        scoreValue.textContent = `${parseFloat(this.value).toFixed(1)}%`;
    });
}
```

**File: `app.py`** - Update backend to handle percentage scores:

```python
@app.route('/api/filter-options/<image_id>')
def get_filter_options(image_id):
    """Get available filter values with hierarchical context - ENHANCED with percentage scores"""
    country = request.args.get('country')
    target_name = request.args.get('target_name')
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get target names based on current hierarchy
                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                        ORDER BY sq.target_name
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                        ORDER BY sq.target_name
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_name
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s 
                        ORDER BY sq.target_name
                    """, (image_id,))
                
                names_result = cur.fetchall()
                target_names = [row['target_name'] for row in names_result if row['target_name']]
                
                # Get target classes with the same hierarchical context
                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                        ORDER BY sq.target_class
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                        ORDER BY sq.target_class
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s 
                        ORDER BY sq.target_class
                    """, (image_id,))
                
                classes = [row['target_class'] for row in cur.fetchall()]
                
                # Get score range with the same hierarchical context - return as 0-1 for percentage conversion
                if country and target_name:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                
                score_result = cur.fetchone()
                
        return jsonify({
            'target_names': target_names or [],
            'target_classes': classes or [],
            'score_range': {
                'min': float(score_result['min_score']) if score_result and score_result['min_score'] is not None else 0.0,
                'max': float(score_result['max_score']) if score_result and score_result['max_score'] is not None else 1.0
            }
        })
        
    except Exception as e:
        app.logger.error(f"Filter options query failed for {image_id}: {e}")
        return jsonify({
            'target_names': [],
            'target_classes': [],
            'score_range': {'min': 0.0, 'max': 1.0}
        })
```

## 2. Enhanced Basemap Page with Local Vector Layer

**New File: `basemap-enhanced.js`**

```javascript
import Map from "ol/Map.js";
import View from "ol/View.js";
import TileLayer from "ol/layer/Tile.js";
import VectorLayer from "ol/layer/Vector.js";
import VectorSource from "ol/source/Vector.js";
import GeoJSON from "ol/format/GeoJSON.js";
import XYZ from "ol/source/XYZ.js";
import { fromLonLat, toLonLat } from "ol/proj.js";
import { defaults as defaultControls } from "ol/control.js";
import ScaleLine from "ol/control/ScaleLine.js";
import Rotate from "ol/control/Rotate.js";
import { Style, Stroke, Fill, Circle as CircleStyle } from "ol/style.js";

// Import Chart.js for the bar chart
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

let map, vectorSource, barChart;
let currentSelections = {
    country: null,
    targetType: null,
    imageId: null,
};

document.addEventListener("DOMContentLoaded", async () => {
    console.log("🗺️ Enhanced Basemap Page Loaded");

    // ==================== DOM ELEMENTS ====================
    const countrySelector = document.getElementById("countrySelector");
    const targetTypeSelector = document.getElementById("targetTypeSelector");
    const imageIdSelector = document.getElementById("imageIdSelector");
    const loadDataBtn = document.getElementById("loadDataBtn");
    const barCanvas = document.getElementById("barChart");

    // ==================== LOCAL VECTOR BASEMAP SETUP ====================
    
    // Create vector source for local basemap (shapefile/PBF equivalent)
    const localBasemapSource = new VectorSource({
        format: new GeoJSON(),
        url: '/api/local-basemap' // New endpoint to serve local vector data
    });

    const localBasemapLayer = new VectorLayer({
        source: localBasemapSource,
        style: new Style({
            stroke: new Stroke({
                color: '#3388ff',
                width: 2
            }),
            fill: new Fill({
                color: 'rgba(51, 136, 255, 0.1)'
            })
        })
    });

    // ==================== MAIN VECTOR LAYER FOR BBOX-CENTROID POLYGONS ====================
    vectorSource = new VectorSource();

    const vectorLayer = new VectorLayer({
        source: vectorSource,
        style: function (feature) {
            const props = feature.getProperties();
            
            return new Style({
                stroke: new Stroke({
                    color: '#ff4444',
                    width: 3
                }),
                fill: new Fill({
                    color: 'rgba(255, 68, 68, 0.3)'
                }),
                image: new CircleStyle({
                    radius: 6,
                    fill: new Fill({
                        color: getColorForClass(props.target_class)
                    }),
                    stroke: new Stroke({
                        color: 'white',
                        width: 1.5
                    })
                })
            });
        }
    });

    // ==================== IMAGERY LAYERS ====================
    const xyzLayer = new TileLayer({
        visible: true,
        opacity: 1,
        source: null,
    });

    // ==================== MAP INITIALIZATION ====================
    map = new Map({
        target: "basemap",
        layers: [localBasemapLayer, xyzLayer, vectorLayer],
        view: new View({
            center: fromLonLat([8.55, 50.04]),
            zoom: 6,
            maxZoom: 20,
        }),
        controls: defaultControls().extend([
            new ScaleLine({ units: "metric" }),
            new Rotate(),
        ])
    });

    // ==================== HIERARCHICAL DROPDOWN SYSTEM ====================
    
    async function loadCountries() {
        try {
            const response = await fetch("/api/countries");
            const countries = await response.json();
            
            countrySelector.innerHTML = '<option value="">Select Country</option>';
            countries.forEach(country => {
                const option = document.createElement("option");
                option.value = country;
                option.textContent = country;
                countrySelector.appendChild(option);
            });
        } catch (error) {
            console.error("Failed to load countries:", error);
        }
    }

    async function loadTargetTypes(country) {
        if (!country) return;
        
        try {
            targetTypeSelector.disabled = true;
            const response = await fetch(`/api/target-types/${encodeURIComponent(country)}`);
            const targetNames = await response.json();
            
            targetTypeSelector.innerHTML = '<option value="">Select Target Name</option>';
            targetNames.forEach(targetName => {
                const option = document.createElement("option");
                option.value = targetName;
                option.textContent = targetName;
                targetTypeSelector.appendChild(option);
            });
            targetTypeSelector.disabled = false;
        } catch (error) {
            console.error("Failed to load target types:", error);
        }
    }

    async function loadImageIds(country, targetName) {
        if (!country || !targetName) return;
        
        try {
            imageIdSelector.disabled = true;
            const response = await fetch(`/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(targetName)}`);
            const imageIds = await response.json();
            
            imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
            imageIds.forEach(imageId => {
                const option = document.createElement("option");
                option.value = imageId;
                option.textContent = imageId;
                imageIdSelector.appendChild(option);
            });
            imageIdSelector.disabled = false;
        } catch (error) {
            console.error("Failed to load image IDs:", error);
        }
    }

    // ==================== DATA LOADING ====================
    
    async function loadUnifiedData(imageId) {
        if (!imageId) return;

        try {
            const response = await fetch(`/api/unified-data/${imageId}`);
            const unifiedData = await response.json();

            // Load vector data
            vectorSource.clear();
            if (unifiedData.vector_data && unifiedData.vector_data.features) {
                const features = new GeoJSON().readFeatures(unifiedData.vector_data, {
                    featureProjection: "EPSG:3857"
                });
                vectorSource.addFeatures(features);

                // Zoom to data extent
                map.getView().fit(vectorSource.getExtent(), {
                    padding: [50, 50, 50, 50],
                    maxZoom: 16,
                    duration: 1000
                });
            }

            // Load chart data
            loadChartData(unifiedData.chart_data);

            // Update imagery layer
            updateImageryLayer(imageId);

        } catch (error) {
            console.error("Failed to load unified data:", error);
        }
    }

    async function updateImageryLayer(imageId) {
        const xyzSource = new XYZ({
            url: `/tiles/${imageId}/{z}/{x}/{y}.png`,
            crossOrigin: "anonymous"
        });
        xyzLayer.setSource(xyzSource);
    }

    function loadChartData(chartData) {
        if (barChart) barChart.destroy();

        if (!chartData || chartData.length === 0) return;

        barChart = new Chart(barCanvas, {
            type: "bar",
            data: {
                labels: chartData.map(d => d.target_name || d.target_class),
                datasets: [{
                    label: "Total Count",
                    data: chartData.map(d => d.total_count),
                    backgroundColor: [
                        "#3366CC", "#DC3912", "#FF9900", "#109618", 
                        "#990099", "#0099C6", "#DD4477", "#66AA00"
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                const dataPoint = chartData[context[0].dataIndex];
                                return dataPoint.target_name || dataPoint.target_class;
                            }
                        }
                    }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }

    function getColorForClass(targetClass) {
        const colorMap = {
            "FR-AF-CGAA-1": "#3366CC",
            "FR-AP-CGSV-1": "#DC3912",
            "FR-AF-CPA-2": "#FF9900",
            "FR-AF-CCTA-3": "#109618",
            "FR-AF-CCA-4": "#990099",
            "FR-AP-CMV-2": "#0099C6",
        };
        return colorMap[targetClass] || "#666666";
    }

    // ==================== EVENT HANDLERS ====================
    
    countrySelector.addEventListener("change", async (e) => {
        currentSelections.country = e.target.value;
        currentSelections.targetType = null;
        currentSelections.imageId = null;
        
        targetTypeSelector.innerHTML = '<option value="">Select Target Name</option>';
        targetTypeSelector.disabled = !currentSelections.country;
        imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
        imageIdSelector.disabled = true;
        
        if (currentSelections.country) {
            await loadTargetTypes(currentSelections.country);
        }
    });

    targetTypeSelector.addEventListener("change", async (e) => {
        currentSelections.targetType = e.target.value;
        currentSelections.imageId = null;
        
        imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
        imageIdSelector.disabled = !currentSelections.targetType;
        
        if (currentSelections.targetType && currentSelections.country) {
            await loadImageIds(currentSelections.country, currentSelections.targetType);
        }
    });

    imageIdSelector.addEventListener("change", (e) => {
        currentSelections.imageId = e.target.value;
    });

    loadDataBtn.addEventListener("click", () => {
        if (currentSelections.imageId) {
            loadUnifiedData(currentSelections.imageId);
        }
    });

    // ==================== INITIALIZATION ====================
    await loadCountries();
});
```

**New Endpoint in `app.py` for Local Basemap:**

```python
@app.route('/api/local-basemap')
def get_local_basemap():
    """Serve local vector basemap data (shapefile/PBF equivalent)"""
    try:
        # This would typically load from a local shapefile or PBF
        # For now, return a simple GeoJSON with some example features
        sample_geojson = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Polygon",
                        "coordinates": [[
                            [8.0, 49.5], [9.0, 49.5], [9.0, 50.5], [8.0, 50.5], [8.0, 49.5]
                        ]]
                    },
                    "properties": {
                        "name": "Sample Region",
                        "type": "administrative"
                    }
                }
            ]
        }
        return jsonify(sample_geojson)
    except Exception as e:
        app.logger.error(f"Failed to load local basemap: {e}")
        return jsonify({"type": "FeatureCollection", "features": []})
```

## 3. Restructured Historical Page

**New File: `historical-enhanced.js`**

```javascript
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

let timelineChart;
let currentSelections = {
    country: null,
    targetType: null,
    targetName: null
};

document.addEventListener("DOMContentLoaded", async () => {
    console.log("📊 Enhanced Historical Page Loaded");

    // ==================== DOM ELEMENTS ====================
    const countrySelector = document.getElementById("countrySelector");
    const targetTypeSelector = document.getElementById("targetTypeSelector");
    const targetNameSelector = document.getElementById("targetNameSelector");
    const generateTimelineBtn = document.getElementById("generateTimeline");
    const timelineCtx = document.getElementById("timelineChart").getContext("2d");

    // ==================== HIERARCHICAL DROPDOWN SYSTEM ====================
    
    async function loadCountries() {
        try {
            const response = await fetch("/api/countries");
            const countries = await response.json();
            
            countrySelector.innerHTML = '<option value="">Select Country</option>';
            countries.forEach(country => {
                const option = document.createElement("option");
                option.value = country;
                option.textContent = country;
                countrySelector.appendChild(option);
            });
        } catch (error) {
            console.error("Failed to load countries:", error);
        }
    }

    async function loadTargetTypes(country) {
        if (!country) return;
        
        try {
            targetTypeSelector.disabled = true;
            targetNameSelector.disabled = true;
            
            const response = await fetch(`/api/target-types/${encodeURIComponent(country)}`);
            const targetNames = await response.json();
            
            // Extract unique target types from target names
            const targetTypes = [...new Set(targetNames.map(name => {
                if (name.includes('Airport')) return 'airport';
                if (name.includes('Airfield')) return 'airfield';
                if (name.includes('Helipad')) return 'helipad';
                return 'other';
            }))];
            
            targetTypeSelector.innerHTML = '<option value="">All Types</option>';
            targetTypes.forEach(type => {
                const option = document.createElement("option");
                option.value = type;
                option.textContent = type.charAt(0).toUpperCase() + type.slice(1);
                targetTypeSelector.appendChild(option);
            });
            targetTypeSelector.disabled = false;
        } catch (error) {
            console.error("Failed to load target types:", error);
        }
    }

    async function loadTargetNames(country, targetType) {
        if (!country) return;
        
        try {
            targetNameSelector.disabled = true;
            const response = await fetch(`/api/target-types/${encodeURIComponent(country)}`);
            let targetNames = await response.json();
            
            // Filter by target type if selected
            if (targetType) {
                targetNames = targetNames.filter(name => {
                    if (targetType === 'airport') return name.includes('Airport');
                    if (targetType === 'airfield') return name.includes('Airfield');
                    if (targetType === 'helipad') return name.includes('Helipad');
                    return true;
                });
            }
            
            targetNameSelector.innerHTML = '<option value="">All Targets</option>';
            targetNames.forEach(name => {
                const option = document.createElement("option");
                option.value = name;
                option.textContent = name;
                targetNameSelector.appendChild(option);
            });
            targetNameSelector.disabled = false;
        } catch (error) {
            console.error("Failed to load target names:", error);
        }
    }

    // ==================== TIMELINE CHART ====================
    
    function initializeTimelineChart() {
        timelineChart = new Chart(timelineCtx, {
            type: "line",
            data: {
                datasets: []
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: "Target Deployments Timeline"
                    },
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    x: {
                        type: 'time',
                        time: {
                            unit: 'month',
                            displayFormats: {
                                month: 'MMM YYYY'
                            }
                        },
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Detection Count'
                        }
                    }
                }
            }
        });
    }

    async function generateTimeline() {
        const country = countrySelector.value;
        const targetType = targetTypeSelector.value;
        const targetName = targetNameSelector.value;

        if (!country) {
            alert("Please select a country first");
            return;
        }

        try {
            // Build query parameters
            const params = new URLSearchParams();
            params.append('country', country);
            if (targetType) params.append('target_type', targetType);
            if (targetName) params.append('target_name', targetName);

            const response = await fetch(`/api/historical-timeline?${params}`);
            const timelineData = await response.json();

            updateTimelineChart(timelineData);
            updateStatistics(timelineData);

        } catch (error) {
            console.error("Failed to generate timeline:", error);
        }
    }

    function updateTimelineChart(timelineData) {
        if (!timelineChart) return;

        // Group data by target name for multiple lines
        const datasets = [];
        const colors = ["#3366CC", "#DC3912", "#FF9900", "#109618", "#990099"];
        
        timelineData.forEach((item, index) => {
            datasets.push({
                label: item.target_name,
                data: item.data_points.map(point => ({
                    x: point.date,
                    y: point.count
                })),
                borderColor: colors[index % colors.length],
                backgroundColor: colors[index % colors.length] + '20',
                tension: 0.4,
                fill: false
            }));
        });

        timelineChart.data.datasets = datasets;
        timelineChart.update();
    }

    function updateStatistics(timelineData) {
        if (!timelineData.length) return;

        let totalDetections = 0;
        let peakCount = 0;
        let peakDate = '';
        const uniqueTargets = new Set();

        timelineData.forEach(item => {
            uniqueTargets.add(item.target_name);
            item.data_points.forEach(point => {
                totalDetections += point.count;
                if (point.count > peakCount) {
                    peakCount = point.count;
                    peakDate = new Date(point.date).toLocaleDateString();
                }
            });
        });

        document.getElementById("totalDetections").textContent = totalDetections.toLocaleString();
        document.getElementById("uniqueTargets").textContent = uniqueTargets.size;
        document.getElementById("peakDay").textContent = peakDate || '-';
        
        // Calculate average per target
        const avgPerTarget = uniqueTargets.size > 0 ? (totalDetections / uniqueTargets.size).toFixed(1) : 0;
        document.getElementById("avgPerTarget").textContent = avgPerTarget;
    }

    // ==================== EVENT HANDLERS ====================
    
    countrySelector.addEventListener("change", async (e) => {
        currentSelections.country = e.target.value;
        await loadTargetTypes(currentSelections.country);
    });

    targetTypeSelector.addEventListener("change", async (e) => {
        currentSelections.targetType = e.target.value;
        await loadTargetNames(currentSelections.country, currentSelections.targetType);
    });

    targetNameSelector.addEventListener("change", (e) => {
        currentSelections.targetName = e.target.value;
    });

    generateTimelineBtn.addEventListener("click", generateTimeline);

    // ==================== INITIALIZATION ====================
    initializeTimelineChart();
    await loadCountries();
});
```

**New Endpoint in `app.py` for Historical Timeline:**

```python
@app.route('/api/historical-timeline')
def get_historical_timeline():
    """Enhanced historical timeline data with hierarchical filtering"""
    country = request.args.get('country')
    target_type = request.args.get('target_type')
    target_name = request.args.get('target_name')
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Build query based on filters
                query = """
                    SELECT 
                        sq.target_name,
                        sq.image_date,
                        COUNT(*) as detection_count,
                        tc.target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target_classification tc ON sq.target_class = tc.target_class
                    WHERE sq.country_name = %s
                """
                params = [country]
                
                if target_type:
                    query += " AND tc.target_type = %s"
                    params.append(target_type)
                    
                if target_name:
                    query += " AND sq.target_name = %s"
                    params.append(target_name)
                
                query += """
                    GROUP BY sq.target_name, sq.image_date, tc.target_type
                    ORDER BY sq.target_name, sq.image_date
                """
                
                cur.execute(query, params)
                rows = cur.fetchall()
                
        # Format data for timeline chart
        timeline_data = {}
        for row in rows:
            target_name = row['target_name']
            if target_name not in timeline_data:
                timeline_data[target_name] = {
                    'target_name': target_name,
                    'target_type': row['target_type'],
                    'data_points': []
                }
            
            timeline_data[target_name]['data_points'].append({
                'date': row['image_date'].isoformat() if row['image_date'] else None,
                'count': row['detection_count']
            })
        
        return jsonify(list(timeline_data.values()))
        
    except Exception as e:
        app.logger.error(f"Historical timeline query failed: {e}")
        return jsonify([])
```

**Updated `historical.html` Structure:**

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historical Deployment Analysis - GeoDoxy</title>
    <link rel="stylesheet" href="/src/styles.css">
    <style>
        .historical-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 20px;
            min-height: 100vh;
        }

        .historical-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .controls-panel {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 32px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }

        .hierarchical-controls {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr auto;
            gap: 16px;
            align-items: end;
        }

        .control-group {
            display: flex;
            flex-direction: column;
        }

        .control-group label {
            font-weight: 600;
            margin-bottom: 8px;
            color: #2d3748;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: linear-gradient(135deg, var(--indigo-5), var(--indigo-6));
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .stat-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .chart-container {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            height: 500px;
        }

        .back-home {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: var(--indigo-6);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            margin-bottom: 24px;
        }
    </style>
</head>
<body>
    <div class="historical-container">
        <a href="/" class="back-home">← Back to Dashboard</a>

        <div class="historical-header">
            <h1>Historical Deployment Analysis</h1>
            <p>Analyze target deployments over time with hierarchical filtering</p>
        </div>

        <div class="controls-panel">
            <div class="hierarchical-controls">
                <div class="control-group">
                    <label for="countrySelector">Country:</label>
                    <select id="countrySelector" class="hierarchical-select">
                        <option value="">Select Country</option>
                    </select>
                </div>
                
                <div class="control-group">
                    <label for="targetTypeSelector">Target Type:</label>
                    <select id="targetTypeSelector" class="hierarchical-select" disabled>
                        <option value="">Select Country First</option>
                    </select>
                </div>
                
                <div class="control-group">
                    <label for="targetNameSelector">Target Name:</label>
                    <select id="targetNameSelector" class="hierarchical-select" disabled>
                        <option value="">Select Type First</option>
                    </select>
                </div>
                
                <button id="generateTimeline" class="btn-primary">Generate Timeline</button>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value" id="totalDetections">0</div>
                <div class="stat-label">Total Detections</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="uniqueTargets">0</div>
                <div class="stat-label">Unique Targets</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="avgPerTarget">0</div>
                <div class="stat-label">Avg per Target</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="peakDay">-</div>
                <div class="stat-label">Peak Detection Day</div>
            </div>
        </div>

        <div class="chart-container">
            <canvas id="timelineChart"></canvas>
        </div>
    </div>

    <script type="module" src="/src/historical-enhanced.js"></script>
</body>
</html>
```

## Summary of Changes:

1. **Confidence Scores**: Converted from 0-1 to 0-100% with precise slider control
2. **Basemap Page**: Enhanced with local vector layers, hierarchical dropdowns, and integrated bbox-centroid polygons + bar chart
3. **Historical Page**: Completely restructured with hierarchical filtering (Country → Target Type → Target Name) and clean timeline visualization

All components maintain their core functionality while addressing the specific requirements you outlined. The system now handles large datasets efficiently with proper filtering and visualization.

---

I'll make the `/api/local-basemap` endpoint dynamic with proper fallback handling. Here's the enhanced implementation:

## Updated Backend Implementation

**File: `app.py`** - Enhanced local basemap endpoint:

```python
import os
import geopandas as gpd
from flask import send_file

@app.route('/api/local-basemap')
def get_local_basemap():
    """Dynamic local basemap data - attempts to load real vector data, falls back to sample"""
    try:
        # Define potential local vector data directories and files
        vector_data_paths = [
            'data/vector/basemap.shp',
            'data/vector/basemap.geojson', 
            'data/vector/basemap.pbf',
            'public/data/basemap.shp',
            'public/data/basemap.geojson',
            'vector_data/basemap.shp',
            # Add other potential paths as needed
        ]
        
        # Check for existence of vector data files
        found_vector_path = None
        for path in vector_data_paths:
            if os.path.exists(path):
                found_vector_path = path
                app.logger.info(f"Found local vector data at: {path}")
                break
        
        if found_vector_path:
            # Load and serve the actual vector data
            if found_vector_path.endswith('.shp'):
                gdf = gpd.read_file(found_vector_path)
                geojson_data = gdf.to_json()
                return jsonify(json.loads(geojson_data))
            elif found_vector_path.endswith('.geojson'):
                # Directly serve GeoJSON file
                return send_file(found_vector_path, mimetype='application/geo+json')
            elif found_vector_path.endswith('.pbf'):
                # For PBF, we'd need special handling - for now return as binary
                return send_file(found_vector_path, mimetype='application/octet-stream')
        
        # If no local data found, check for any shapefile in vector directories
        vector_dirs = ['data/vector', 'public/data', 'vector_data']
        for vector_dir in vector_dirs:
            if os.path.exists(vector_dir) and os.path.isdir(vector_dir):
                for file in os.listdir(vector_dir):
                    if file.endswith('.shp'):
                        shapefile_path = os.path.join(vector_dir, file)
                        app.logger.info(f"Found shapefile: {shapefile_path}")
                        gdf = gpd.read_file(shapefile_path)
                        geojson_data = gdf.to_json()
                        return jsonify(json.loads(geojson_data))
        
        # Fallback: Generate dynamic sample data based on actual data in database
        app.logger.info("No local vector data found, generating dynamic sample basemap")
        return get_dynamic_fallback_basemap()
        
    except Exception as e:
        app.logger.error(f"Failed to load local basemap: {e}")
        # Final fallback to hardcoded sample
        return get_hardcoded_fallback_basemap()

def get_dynamic_fallback_basemap():
    """Generate dynamic fallback basemap based on actual data extent"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get actual data extent from findings
                cur.execute("""
                    SELECT 
                        ST_XMin(ST_Extent(target_geom)) as min_lon,
                        ST_YMin(ST_Extent(target_geom)) as min_lat, 
                        ST_XMax(ST_Extent(target_geom)) as max_lon,
                        ST_YMax(ST_Extent(target_geom)) as max_lat
                    FROM findings 
                    WHERE target_geom IS NOT NULL
                    LIMIT 1
                """)
                extent_result = cur.fetchone()
                
                if extent_result and extent_result['min_lon']:
                    # Create bounding box around actual data extent
                    min_lon = float(extent_result['min_lon'])
                    min_lat = float(extent_result['min_lat'])
                    max_lon = float(extent_result['max_lon'])
                    max_lat = float(extent_result['max_lat'])
                    
                    # Expand bounds slightly for better visualization
                    lon_buffer = (max_lon - min_lon) * 0.1
                    lat_buffer = (max_lat - min_lat) * 0.1
                    
                    dynamic_geojson = {
                        "type": "FeatureCollection",
                        "features": [
                            {
                                "type": "Feature",
                                "geometry": {
                                    "type": "Polygon",
                                    "coordinates": [[
                                        [min_lon - lon_buffer, min_lat - lat_buffer],
                                        [max_lon + lon_buffer, min_lat - lat_buffer],
                                        [max_lon + lon_buffer, max_lat + lat_buffer],
                                        [min_lon - lon_buffer, max_lat + lat_buffer],
                                        [min_lon - lon_buffer, min_lat - lat_buffer]
                                    ]]
                                },
                                "properties": {
                                    "name": "Data Extent Boundary",
                                    "type": "extent",
                                    "source": "dynamic_fallback"
                                }
                            }
                        ]
                    }
                    app.logger.info("Serving dynamic extent-based basemap")
                    return jsonify(dynamic_geojson)
                
    except Exception as e:
        app.logger.warning(f"Could not generate dynamic basemap: {e}")
    
    # Ultimate fallback to hardcoded sample
    return get_hardcoded_fallback_basemap()

def get_hardcoded_fallback_basemap():
    """Final fallback - hardcoded sample data"""
    app.logger.info("Using hardcoded fallback basemap")
    sample_geojson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [8.0, 49.5], [9.0, 49.5], [9.0, 50.5], [8.0, 50.5], [8.0, 49.5]
                    ]]
                },
                "properties": {
                    "name": "Sample Region",
                    "type": "administrative",
                    "source": "hardcoded_fallback"
                }
            },
            {
                "type": "Feature", 
                "geometry": {
                    "type": "Point",
                    "coordinates": [8.55, 50.04]
                },
                "properties": {
                    "name": "Sample Point",
                    "type": "location",
                    "source": "hardcoded_fallback"
                }
            }
        ]
    }
    return jsonify(sample_geojson)

# New endpoint to check available vector data sources
@app.route('/api/local-basemap-info')
def get_local_basemap_info():
    """Return information about available local basemap data sources"""
    sources_info = {
        "available_sources": [],
        "active_source": None,
        "data_type": None
    }
    
    try:
        vector_data_paths = [
            {'path': 'data/vector/basemap.shp', 'type': 'shapefile'},
            {'path': 'data/vector/basemap.geojson', 'type': 'geojson'},
            {'path': 'data/vector/basemap.pbf', 'type': 'pbf'},
            {'path': 'public/data/basemap.shp', 'type': 'shapefile'},
            {'path': 'vector_data/basemap.shp', 'type': 'shapefile'},
        ]
        
        for source in vector_data_paths:
            if os.path.exists(source['path']):
                sources_info["available_sources"].append({
                    'path': source['path'],
                    'type': source['type'],
                    'size': os.path.getsize(source['path']) if os.path.isfile(source['path']) else None
                })
        
        # Check for any shapefile in vector directories
        vector_dirs = ['data/vector', 'public/data', 'vector_data']
        for vector_dir in vector_dirs:
            if os.path.exists(vector_dir) and os.path.isdir(vector_dir):
                for file in os.listdir(vector_dir):
                    if file.endswith('.shp'):
                        full_path = os.path.join(vector_dir, file)
                        sources_info["available_sources"].append({
                            'path': full_path,
                            'type': 'shapefile',
                            'size': os.path.getsize(full_path)
                        })
        
        if sources_info["available_sources"]:
            sources_info["active_source"] = sources_info["available_sources"][0]
            sources_info["data_type"] = "local_file"
        else:
            sources_info["data_type"] = "fallback"
            sources_info["active_source"] = {"type": "dynamic_fallback"}
            
    except Exception as e:
        app.logger.error(f"Error getting basemap info: {e}")
        sources_info["data_type"] = "error"
        
    return jsonify(sources_info)
```

## Enhanced Frontend for Dynamic Basemap

**File: `basemap-enhanced.js`** - Updated with dynamic source handling:

```javascript
import Map from "ol/Map.js";
import View from "ol/View.js";
import TileLayer from "ol/layer/Tile.js";
import VectorLayer from "ol/layer/Vector.js";
import VectorSource from "ol/source/Vector.js";
import GeoJSON from "ol/format/GeoJSON.js";
import XYZ from "ol/source/XYZ.js";
import { fromLonLat, toLonLat } from "ol/proj.js";
import { defaults as defaultControls } from "ol/control.js";
import ScaleLine from "ol/control/ScaleLine.js";
import Rotate from "ol/control/Rotate.js";
import { Style, Stroke, Fill, Circle as CircleStyle } from "ol/style.js";

// Import Chart.js for the bar chart
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

let map, vectorSource, barChart, localBasemapLayer;
let currentSelections = {
    country: null,
    targetType: null,
    imageId: null,
};

document.addEventListener("DOMContentLoaded", async () => {
    console.log("🗺️ Enhanced Basemap Page Loaded");

    // ==================== DOM ELEMENTS ====================
    const countrySelector = document.getElementById("countrySelector");
    const targetTypeSelector = document.getElementById("targetTypeSelector");
    const imageIdSelector = document.getElementById("imageIdSelector");
    const loadDataBtn = document.getElementById("loadDataBtn");
    const barCanvas = document.getElementById("barChart");
    const basemapInfo = document.getElementById("basemapInfo");

    // ==================== DYNAMIC LOCAL BASEMAP SETUP ====================
    
    async function initializeLocalBasemap() {
        try {
            // Check available basemap sources
            const infoResponse = await fetch('/api/local-basemap-info');
            const basemapInfo = await infoResponse.json();
            
            console.log("🗺️ Basemap sources:", basemapInfo);
            
            // Update UI with basemap source information
            if (basemapInfoDisplay) {
                if (basemapInfo.data_type === "local_file") {
                    basemapInfoDisplay.innerHTML = `
                        <strong>Local Vector Data:</strong> ${basemapInfo.active_source.type} 
                        <br><small>${basemapInfo.active_source.path}</small>
                    `;
                    basemapInfoDisplay.style.background = 'var(--green-1)';
                } else if (basemapInfo.data_type === "fallback") {
                    basemapInfoDisplay.innerHTML = `
                        <strong>Dynamic Fallback Basemap</strong>
                        <br><small>No local vector files found</small>
                    `;
                    basemapInfoDisplay.style.background = 'var(--orange-1)';
                } else {
                    basemapInfoDisplay.innerHTML = `
                        <strong>Hardcoded Fallback</strong>
                        <br><small>Using sample data</small>
                    `;
                    basemapInfoDisplay.style.background = 'var(--red-1)';
                }
            }

            // Create vector source for dynamic local basemap
            const localBasemapSource = new VectorSource({
                format: new GeoJSON(),
                url: '/api/local-basemap',
                strategy: ol.loadingstrategy.bbox
            });

            // Style function for dynamic basemap features
            const dynamicStyleFunction = function(feature) {
                const props = feature.getProperties();
                const featureType = props.type || 'default';
                const source = props.source || 'unknown';
                
                let strokeColor, fillColor, width;
                
                // Different styles based on feature type and source
                switch(featureType) {
                    case 'extent':
                        strokeColor = '#ff6b6b';
                        fillColor = 'rgba(255, 107, 107, 0.1)';
                        width = 3;
                        break;
                    case 'administrative':
                        strokeColor = '#3388ff';
                        fillColor = 'rgba(51, 136, 255, 0.1)';
                        width = 2;
                        break;
                    case 'location':
                        return new Style({
                            image: new CircleStyle({
                                radius: 6,
                                fill: new Fill({ color: '#ffd93d' }),
                                stroke: new Stroke({ color: '#fff', width: 2 })
                            })
                        });
                    default:
                        strokeColor = '#4ecdc4';
                        fillColor = 'rgba(78, 205, 196, 0.1)';
                        width = 2;
                }
                
                // Different style for fallback data
                if (source.includes('fallback')) {
                    strokeColor = '#95a5a6';
                    fillColor = 'rgba(149, 165, 166, 0.05)';
                    width = source === 'hardcoded_fallback' ? 1 : 2;
                }
                
                return new Style({
                    stroke: new Stroke({
                        color: strokeColor,
                        width: width,
                        lineDash: source.includes('fallback') ? [5, 5] : undefined
                    }),
                    fill: new Fill({
                        color: fillColor
                    })
                });
            };

            localBasemapLayer = new VectorLayer({
                source: localBasemapSource,
                style: dynamicStyleFunction,
                zIndex: 1
            });

            return localBasemapLayer;

        } catch (error) {
            console.error("Failed to initialize local basemap:", error);
            // Fallback to basic vector layer
            return createFallbackBasemapLayer();
        }
    }

    function createFallbackBasemapLayer() {
        console.warn("Using emergency fallback basemap");
        const fallbackSource = new VectorSource({
            features: []
        });
        
        return new VectorLayer({
            source: fallbackSource,
            style: new Style({
                stroke: new Stroke({
                    color: '#bdc3c7',
                    width: 1,
                    lineDash: [10, 5]
                }),
                fill: new Fill({
                    color: 'rgba(189, 195, 199, 0.05)'
                })
            }),
            zIndex: 1
        });
    }

    // ==================== MAIN VECTOR LAYER FOR BBOX-CENTROID POLYGONS ====================
    vectorSource = new VectorSource();

    const vectorLayer = new VectorLayer({
        source: vectorSource,
        style: function (feature) {
            const props = feature.getProperties();
            
            return new Style({
                stroke: new Stroke({
                    color: '#ff4444',
                    width: 3
                }),
                fill: new Fill({
                    color: 'rgba(255, 68, 68, 0.3)'
                }),
                image: new CircleStyle({
                    radius: 6,
                    fill: new Fill({
                        color: getColorForClass(props.target_class)
                    }),
                    stroke: new Stroke({
                        color: 'white',
                        width: 1.5
                    })
                })
            });
        },
        zIndex: 3
    });

    // ==================== IMAGERY LAYERS ====================
    const xyzLayer = new TileLayer({
        visible: true,
        opacity: 1,
        source: null,
        zIndex: 2
    });

    // ==================== MAP INITIALIZATION ====================
    
    // Initialize map with dynamic basemap
    async function initializeMap() {
        const localBasemapLayer = await initializeLocalBasemap();
        
        map = new Map({
            target: "basemap",
            layers: [localBasemapLayer, xyzLayer, vectorLayer],
            view: new View({
                center: fromLonLat([8.55, 50.04]),
                zoom: 6,
                maxZoom: 20,
            }),
            controls: defaultControls().extend([
                new ScaleLine({ units: "metric" }),
                new Rotate(),
            ])
        });

        // Add basemap refresh control
        addBasemapRefreshControl();
    }

    function addBasemapRefreshControl() {
        const refreshButton = document.createElement('button');
        refreshButton.innerHTML = '🔄';
        refreshButton.title = 'Refresh Basemap Data';
        refreshButton.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 1000;
            background: white;
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 8px 12px;
            cursor: pointer;
            font-size: 16px;
        `;
        
        refreshButton.addEventListener('click', async () => {
            refreshButton.disabled = true;
            refreshButton.innerHTML = '⏳';
            
            try {
                // Clear and reload basemap
                if (localBasemapLayer) {
                    localBasemapLayer.getSource().refresh();
                }
                
                // Reload basemap info
                const infoResponse = await fetch('/api/local-basemap-info');
                const basemapInfo = await infoResponse.json();
                updateBasemapInfoDisplay(basemapInfo);
                
                setTimeout(() => {
                    refreshButton.innerHTML = '🔄';
                    refreshButton.disabled = false;
                }, 1000);
                
            } catch (error) {
                console.error("Failed to refresh basemap:", error);
                refreshButton.innerHTML = '❌';
                setTimeout(() => {
                    refreshButton.innerHTML = '🔄';
                    refreshButton.disabled = false;
                }, 2000);
            }
        });
        
        document.getElementById('basemap').parentElement.appendChild(refreshButton);
    }

    function updateBasemapInfoDisplay(basemapInfo) {
        const basemapInfoDisplay = document.getElementById('basemapInfoDisplay');
        if (!basemapInfoDisplay) return;
        
        if (basemapInfo.data_type === "local_file") {
            basemapInfoDisplay.innerHTML = `
                <strong>Local Vector Data:</strong> ${basemapInfo.active_source.type} 
                <br><small>${basemapInfo.active_source.path}</small>
                <br><em>Last refreshed: ${new Date().toLocaleTimeString()}</em>
            `;
            basemapInfoDisplay.style.background = 'var(--green-1)';
        } else if (basemapInfo.data_type === "fallback") {
            basemapInfoDisplay.innerHTML = `
                <strong>Dynamic Fallback Basemap</strong>
                <br><small>No local vector files found</small>
                <br><em>Last refreshed: ${new Date().toLocaleTimeString()}</em>
            `;
            basemapInfoDisplay.style.background = 'var(--orange-1)';
        } else {
            basemapInfoDisplay.innerHTML = `
                <strong>Hardcoded Fallback</strong>
                <br><small>Using sample data</small>
                <br><em>Last refreshed: ${new Date().toLocaleTimeString()}</em>
            `;
            basemapInfoDisplay.style.background = 'var(--red-1)';
        }
    }

    // [Rest of the code remains the same - hierarchical dropdowns, data loading, etc.]
    // ... (hierarchical dropdown system, data loading functions, event handlers)

    // ==================== INITIALIZATION ====================
    await initializeMap();
    await loadCountries();
});
```

## Updated Basemap HTML with Info Display

**File: `basemap.html`** - Add basemap info display:

```html
<!-- Add this to the map overlay section -->
<div class="map-overlay">
    <h3 style="margin: 0 0 12px 0; color: #2d3748;">Basemap Controls</h3>
    
    <!-- Basemap Source Information -->
    <div id="basemapInfoDisplay" style="
        background: var(--orange-1); 
        padding: 8px 12px; 
        border-radius: 4px; 
        margin-bottom: 12px; 
        font-size: 0.8rem;
        border-left: 3px solid var(--orange-5);
    ">
        <strong>Loading basemap data...</strong>
    </div>
    
    <p style="margin: 0 0 16px 0; color: #4a5568; font-size: 0.9rem;">
        Switch between different basemap layers. Vector basemap shows detailed geographic features.
    </p>
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
        <button id="zoom-in"
            style="padding: 8px 12px; background: var(--indigo-6); color: white; border: none; border-radius: 4px; cursor: pointer;">Zoom
            In</button>
        <button id="zoom-out"
            style="padding: 8px 12px; background: var(--indigo-6); color: white; border: none; border-radius: 4px; cursor: pointer;">Zoom
            Out</button>
        <button id="reset-view"
            style="padding: 8px 12px; background: var(--green-6); color: white; border: none; border-radius: 4px; cursor: pointer;">Reset
            View</button>
    </div>
</div>
```

## Key Improvements:

1. **Dynamic Source Detection**: Automatically searches for local vector files in multiple locations
2. **Intelligent Fallback System**: 
   - Primary: Local shapefile/GeoJSON/PBF files
   - Secondary: Dynamic extent-based basemap from database
   - Tertiary: Hardcoded sample data
3. **Source Information API**: `/api/local-basemap-info` endpoint for frontend awareness
4. **Visual Feedback**: UI shows which data source is being used
5. **Refresh Capability**: Users can manually refresh basemap data
6. **Smart Styling**: Different visual styles for different data sources
7. **Error Resilience**: Graceful degradation at every level

The system now automatically adapts to whatever vector data is available, providing the best possible basemap experience while maintaining robust fallback behavior.

---
