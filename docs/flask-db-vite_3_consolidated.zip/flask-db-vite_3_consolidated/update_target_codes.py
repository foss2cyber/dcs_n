# update_target_codes.py
import psycopg2

def update_database():
    """Update target classifications and sample data with new codes"""
    conn = psycopg2.connect("postgresql://postgres:postgres@localhost:5432/postgres")
    cur = conn.cursor()
    
    try:
        # Update target_classification table
        print("🔄 Updating target classifications...")
        cur.execute("DELETE FROM target_classification;")
        cur.execute("""
            INSERT INTO target_classification (target_class, target_name, target_type, category, description) VALUES
            ('FR-AF-CGAA-1', 'Frankfurt_Airport_Aircraft_1', 'airfield', 'commercial', 'General aviation aircraft'),
            ('FR-AP-CGSV-1', 'Frankfurt_Airport_Service_1', 'airport', 'commercial', 'Ground service vehicle'),
            ('FR-AF-CPA-2', 'Frankfurt_Airport_Aircraft_2', 'airfield', 'commercial', 'Passenger aircraft'),
            ('FR-AF-CCTA-3', 'Frankfurt_Airport_Aircraft_3', 'airfield', 'commercial', 'Cargo transport aircraft'),
            ('FR-AF-CCA-4', 'Frankfurt_Airport_Aircraft_4', 'airfield', 'commercial', 'Commercial airliner'),
            ('FR-AP-CMV-2', 'Frankfurt_Airport_Service_2', 'airport', 'commercial', 'Maintenance vehicle');
        """)
        
        # Update sample data with new target classes
        print("🔄 Updating sample data...")
        
        # Update findings table
        cur.execute("UPDATE findings SET target_class = 'FR-AF-CGAA-1' WHERE target_class = 'aircraft';")
        cur.execute("UPDATE findings SET target_class = 'FR-AP-CGSV-1' WHERE target_class = 'service_vehicle';")
        cur.execute("UPDATE findings SET target_class = 'FR-AF-CPA-2' WHERE target_class = 'commercial_airliner';")
        cur.execute("UPDATE findings SET target_class = 'FR-AP-CMV-2' WHERE target_class = 'ground_support';")
        
        # Update comprehensive_query table
        cur.execute("UPDATE comprehensive_query SET target_class = 'FR-AF-CGAA-1' WHERE target_class = 'aircraft';")
        cur.execute("UPDATE comprehensive_query SET target_class = 'FR-AP-CGSV-1' WHERE target_class = 'service_vehicle';")
        cur.execute("UPDATE comprehensive_query SET target_class = 'FR-AF-CPA-2' WHERE target_class = 'commercial_airliner';")
        cur.execute("UPDATE comprehensive_query SET target_class = 'FR-AP-CMV-2' WHERE target_class = 'ground_support';")
        
        # Update sql_scat_query2 table
        cur.execute("UPDATE sql_scat_query2 SET target_class = 'FR-AF-CGAA-1' WHERE target_class = 'aircraft';")
        cur.execute("UPDATE sql_scat_query2 SET target_class = 'FR-AP-CGSV-1' WHERE target_class = 'service_vehicle';")
        cur.execute("UPDATE sql_scat_query2 SET target_class = 'FR-AF-CPA-2' WHERE target_class = 'commercial_airliner';")
        cur.execute("UPDATE sql_scat_query2 SET target_class = 'FR-AP-CMV-2' WHERE target_class = 'ground_support';")
        
        conn.commit()
        
        # Verify updates
        print("\n✅ Verification:")
        cur.execute("SELECT target_class, target_name, target_type FROM target_classification ORDER BY target_class;")
        for row in cur.fetchall():
            print(f"   {row[0]} -> {row[1]} ({row[2]})")
            
        print("\n🎉 Target codes updated successfully!")
        print("   - New target_class codes applied (FR-AF-CGAA-1, etc.)")
        print("   - target_type should now display correctly")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        conn.rollback()
    finally:
        cur.close()
        conn.close()

if __name__ == '__main__':
    update_database()