// basemap.js
import Map from "ol/Map.js";
import View from "ol/View.js";
import TileLayer from "ol/layer/Tile.js";
import OSM from "ol/source/OSM.js";
import XYZ from "ol/source/XYZ.js";
import { fromLonLat } from "ol/proj.js";
import { defaults as defaultControls } from "ol/control.js";
import ScaleLine from "ol/control/ScaleLine.js";
import Rotate from "ol/control/Rotate.js";

// Initialize basemap layers
const vectorLayer = new TileLayer({
  source: new XYZ({
    url: "https://{a-c}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attributions: "© OpenStreetMap contributors",
  }),
  visible: true,
});

const satelliteLayer = new TileLayer({
  source: new XYZ({
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attributions: "© Esri, Maxar, Earthstar Geographics",
  }),
  visible: false,
});

const terrainLayer = new TileLayer({
  source: new XYZ({
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Shaded_Relief/MapServer/tile/{z}/{y}/{x}",
    attributions: "© Esri, USGS",
  }),
  visible: false,
});

// Initialize map
const map = new Map({
  target: "basemap",
  layers: [vectorLayer, satelliteLayer, terrainLayer],
  view: new View({
    center: fromLonLat([8.55, 50.04]),
    zoom: 6,
    maxZoom: 18,
  }),
  controls: defaultControls().extend([
    new ScaleLine({ units: "metric" }),
    new Rotate(),
  ]),
});

// Layer control functionality
document.querySelectorAll(".layer-control").forEach((button) => {
  button.addEventListener("click", function () {
    // Update button states
    document
      .querySelectorAll(".layer-control")
      .forEach((btn) => btn.classList.remove("active"));
    this.classList.add("active");

    // Update layer visibility
    const layerType = this.dataset.layer;
    vectorLayer.setVisible(layerType === "vector");
    satelliteLayer.setVisible(layerType === "satellite");
    terrainLayer.setVisible(layerType === "terrain");
  });
});

// Map control buttons
document.getElementById("zoom-in").addEventListener("click", () => {
  const view = map.getView();
  view.animate({
    zoom: view.getZoom() + 1,
    duration: 250,
  });
});

document.getElementById("zoom-out").addEventListener("click", () => {
  const view = map.getView();
  view.animate({
    zoom: view.getZoom() - 1,
    duration: 250,
  });
});

document.getElementById("reset-view").addEventListener("click", () => {
  map.getView().animate({
    center: fromLonLat([8.55, 50.04]),
    zoom: 6,
    duration: 500,
  });
});

// Handle window resize
window.addEventListener("resize", () => {
  setTimeout(() => map.updateSize(), 100);
});
