-- init_db.sql - Complete database schema including ALL tables
CREATE EXTENSION IF NOT EXISTS postgis;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS sql_scat_query2 CASCADE;

DROP TABLE IF EXISTS comprehensive_query CASCADE;

DROP TABLE IF EXISTS findings CASCADE;

DROP TABLE IF EXISTS target CASCADE;

DROP TABLE IF EXISTS target_classification CASCADE;

-- Table: findings (main detection data)
CREATE TABLE findings (
    id INTEGER PRIMARY KEY,
    image_id CHARACTER VARYING(100) NOT NULL,
    image_date DATE,
    target_class CHARACTER VARYING(30),
    score DOUBLE PRECISION,
    target_geom GEOMETRY (POLYGON, 4326)
);

-- Table: target
CREATE TABLE target (
    id INTEGER PRIMARY KEY,
    target_type CHARACTER VARYING(50),
    target_name CHARACTER VARYING(100),
    country_name CHARACTER VARYING(25),
    target_geom GEOMETRY (POLYGON, 4326)
);

-- Table: comprehensive_query
CREATE TABLE comprehensive_query (
    target_name CHARACTER VARYING(100),
    country_name CHARACTER VARYING(25),
    image_id CHARACTER VARYING(100) NOT NULL,
    image_date DATE,
    target_class CHARACTER VARYING(30),
    total_count BIGINT,
    score DOUBLE PRECISION
);

-- Table: sql_scat_query2 (YOUR MAIN TABLE)
CREATE TABLE sql_scat_query2 (
    id SERIAL PRIMARY KEY,
    country_name CHARACTER VARYING(25),
    target_name CHARACTER VARYING(100),
    image_id CHARACTER VARYING(100) NOT NULL,
    image_date DATE,
    target_class CHARACTER VARYING(30),
    score DOUBLE PRECISION,
    st_x DOUBLE PRECISION,
    st_y DOUBLE PRECISION
);

-- Table: target_classification (NEW - for realistic classifications)
CREATE TABLE target_classification (
    target_class VARCHAR(50) PRIMARY KEY,
    target_name VARCHAR(100),
    target_type VARCHAR(50),
    category VARCHAR(50),
    description TEXT
);

-- Create spatial indexes for performance
CREATE INDEX IF NOT EXISTS idx_findings_geom ON findings USING GIST (target_geom);

CREATE INDEX IF NOT EXISTS idx_findings_image_id ON findings (image_id);

CREATE INDEX IF NOT EXISTS idx_target_geom ON target USING GIST (target_geom);

CREATE INDEX IF NOT EXISTS idx_comprehensive_query_image_id ON comprehensive_query (image_id);

CREATE INDEX IF NOT EXISTS idx_sql_scat_query2_image_id ON sql_scat_query2 (image_id);

-- Update target_classification table with new codes
DELETE FROM target_classification;

INSERT INTO
    target_classification (
        target_class,
        target_name,
        target_type,
        category,
        description
    )
VALUES (
        'FR-AF-CGAA-1',
        'Frankfurt_Airport_Aircraft_1',
        'airfield',
        'commercial',
        'General aviation aircraft'
    ),
    (
        'FR-AP-CGSV-1',
        'Frankfurt_Airport_Service_1',
        'airport',
        'commercial',
        'Ground service vehicle'
    ),
    (
        'FR-AF-CPA-2',
        'Frankfurt_Airport_Aircraft_2',
        'airfield',
        'commercial',
        'Passenger aircraft'
    ),
    (
        'FR-AF-CCTA-3',
        'Frankfurt_Airport_Aircraft_3',
        'airfield',
        'commercial',
        'Cargo transport aircraft'
    ),
    (
        'FR-AF-CCA-4',
        'Frankfurt_Airport_Aircraft_4',
        'airfield',
        'commercial',
        'Commercial airliner'
    ),
    (
        'FR-AP-CMV-2',
        'Frankfurt_Airport_Service_2',
        'airport',
        'commercial',
        'Maintenance vehicle'
    );