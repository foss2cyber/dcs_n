# app.py
import os
import sys
import webbrowser
from pathlib import Path
import multiprocessing
import datetime
import json
import platform
import signal
import subprocess
import threading
import time
import uuid
from typing import Dict

import psutil
from flask import Flask, Response, jsonify, render_template_string, request

app = Flask(__name__)

# ===== ENHANCED TASK MANAGEMENT =====
tasks: Dict[str, 'Task'] = {}
app_processes = {}  # Track running Flask apps
lock = threading.Lock()
app_logs = []
log_lock = threading.Lock()

class FlaskAppLauncher:
    def __init__(self, app_name, app_path, port=5001):
        self.app_name = app_name
        self.app_path = app_path
        self.port = port
        self.process = None
        self.status = 'stopped'
        
    def start(self):
        try:
            # Use multiprocessing to avoid file descriptor conflicts
            self.process = multiprocessing.Process(
                target=self._run_flask_app,
                daemon=True
            )
            self.process.start()
            self.status = 'running'
            
            # Wait a bit for the app to start
            time.sleep(2)
            return True
        except Exception as e:
            self.status = 'failed'
            raise e
    
    def _run_flask_app(self):
        """Run the Flask app in a separate process"""
        try:
            # Add apps directory to Python path
            sys.path.insert(0, str(self.app_path.parent))
            
            # Import and run the specific app
            if self.app_name == 'demo':
                from demo import app as flask_app
                flask_app.run(host='0.0.0.0', port=self.port, debug=False, use_reloader=False)
        except Exception as e:
            print(f"Flask app error: {e}")
    
    def stop(self):
        if self.process and self.process.is_alive():
            self.process.terminate()
            self.process.join(timeout=5)
            if self.process.is_alive():
                self.process.kill()
            self.status = 'stopped'
    
    def get_status(self):
        if self.process:
            self.status = 'running' if self.process.is_alive() else 'stopped'
        return self.status

class Task:
    def __init__(self, name, command=None, app_type="simulated"):
        self.id = str(uuid.uuid4())
        self.name = name or f"Task {self.id[:6]}"
        self.command = command
        self.app_type = app_type
        self.progress = 0
        self.status = 'idle'  # idle, running, paused, completed, failed
        self.output = []
        self._pause_event = threading.Event()
        self._stop_event = threading.Event()
        self._pause_event.set()
        self.lock = threading.Lock()
        self.process = None
        self.output_thread = None
        self.progress_thread = None
        self.launcher = None  # For Flask apps
        
        self.log(f"🚀 Created: {self.name}")

    def start(self):
        with self.lock:
            if self.status == 'running':
                return True
            
            self.status = 'running'
            self.progress = 0
            self._stop_event.clear()
            self._pause_event.set()
        
        if self.app_type == "simulated":
            self.thread = threading.Thread(target=self._run_simulated)
            self.thread.daemon = True
            self.thread.start()
        elif self.app_type == "flask_app":
            self.thread = threading.Thread(target=self._run_flask_app_monitor)
            self.thread.daemon = True
            self.thread.start()
        else:
            self.thread = threading.Thread(target=self._run_real_process)
            self.thread.daemon = True
            self.thread.start()
            
        self.log(f"▶️ Started: {self.name}")
        return True

    def _run_simulated(self):
        """Original simulated task - kept for compatibility"""
        try:
            while self.progress < 100 and not self._stop_event.is_set():
                self._pause_event.wait()  # Wait if paused
                
                if self._stop_event.is_set():
                    break
                
                with self.lock:
                    self.progress = min(self.progress + 1, 100)
                    if self.progress % 10 == 0:
                        self.log(f"📊 {self.name}: {self.progress}%")
                    if self.progress >= 100:
                        self.status = 'completed'
                        break
                
                time.sleep(0.1)
        except Exception as e:
            with self.lock:
                self.status = 'failed'
            self.log(f"❌ {self.name} failed: {str(e)}", "error")
        finally:
            self.log(f"🔚 {self.name} ended: {self.status}")

    def _run_real_process(self):
        """Run actual system commands with real output"""
        if not self.command:
            self.log("❌ No command specified", "error")
            return

        try:
            # Start the process
            self.process = subprocess.Popen(
                self.command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True,
                preexec_fn=os.setsid if platform.system() != 'Windows' else None
            )
            
            # Start output reading thread
            self.output_thread = threading.Thread(target=self._read_process_output)
            self.output_thread.daemon = True
            self.output_thread.start()
            
            # Start progress tracking thread
            self.progress_thread = threading.Thread(target=self._track_progress)
            self.progress_thread.daemon = True
            self.progress_thread.start()
            
            # Wait for process completion
            while self.process.poll() is None and not self._stop_event.is_set():
                self._pause_event.wait()  # Respect pause
                if self._stop_event.is_set():
                    self._terminate_process()
                    break
                time.sleep(0.1)
            
            # Process ended
            exit_code = self.process.poll()
            with self.lock:
                if self._stop_event.is_set():
                    self.status = 'failed'
                elif exit_code == 0:
                    self.status = 'completed'
                    self.progress = 100
                else:
                    self.status = 'failed'
                    
            self.log(f"🔚 Process ended with exit code: {exit_code}")
            
        except Exception as e:
            with self.lock:
                self.status = 'failed'
            self.log(f"❌ Process failed: {str(e)}", "error")

    def _run_flask_app_monitor(self):
        """Monitor a Flask app instead of running a command"""
        try:
            start_time = time.time()
            max_wait_time = 30  # Wait up to 30 seconds for app to start
            
            while (hasattr(self, 'launcher') and 
                   self.launcher.get_status() == 'running' and 
                   not self._stop_event.is_set()):
                
                # Simulate progress for Flask apps
                elapsed = time.time() - start_time
                if elapsed < 5:
                    # Starting up phase
                    self.progress = min(30, (elapsed / 5) * 30)
                else:
                    # Running phase - maintain at 95% while running
                    self.progress = 95
                
                self._emit_progress()
                
                # Check if we should stop
                self._pause_event.wait()
                if self._stop_event.is_set():
                    break
                    
                time.sleep(1)
            
            # If we get here, the app stopped or was stopped
            if hasattr(self, 'launcher'):
                if self._stop_event.is_set():
                    self.launcher.stop()
                    self.status = 'failed'
                else:
                    self.status = 'completed'
                    self.progress = 100
            else:
                self.status = 'failed'
                
        except Exception as e:
            self.status = 'failed'
            self.log(f"❌ App monitor failed: {str(e)}", "error")
        finally:
            self._emit_progress()

    def _read_process_output(self):
        """Read and log process output in real-time"""
        if not self.process:
            return
            
        for line in iter(self.process.stdout.readline, ''):
            if self._stop_event.is_set():
                break
                
            line = line.rstrip('\r\n')
            if line:
                self.log(f"{line}", "output")
                
        self.process.stdout.close()

    def _track_progress(self):
        """Track progress for real processes"""
        start_time = time.time()
        max_duration = 300  # 5 minutes max
        
        while (self.process and self.process.poll() is None and 
               not self._stop_event.is_set() and self.status == 'running'):
            
            # Estimate progress based on time for unknown processes
            elapsed = time.time() - start_time
            progress = min(90, (elapsed / max_duration) * 100)
            
            with self.lock:
                self.progress = progress
                
            time.sleep(0.5)
        
        # Set to 100% when process completes
        if self.status == 'completed':
            with self.lock:
                self.progress = 100

    def _terminate_process(self):
        """Terminate the process and its children"""
        if self.process and self.process.poll() is None:
            try:
                if platform.system() == 'Windows':
                    # Windows termination
                    self.process.terminate()
                else:
                    # Unix termination - kill process group
                    os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
                
                # Wait a bit then force kill if needed
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    if platform.system() == 'Windows':
                        self.process.kill()
                    else:
                        os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
            except Exception as e:
                self.log(f"Warning during termination: {str(e)}", "warning")

    def pause(self):
        with self.lock:
            if self.status == 'running':
                self._pause_event.clear()
                self.status = 'paused'
                
                # Also pause the actual process if running
                if self.process and self.process.poll() is None:
                    try:
                        if platform.system() == 'Windows':
                            parent = psutil.Process(self.process.pid)
                            parent.suspend()
                            for child in parent.children(recursive=True):
                                child.suspend()
                        else:
                            os.killpg(os.getpgid(self.process.pid), signal.SIGSTOP)
                    except Exception as e:
                        self.log(f"Warning pausing process: {str(e)}", "warning")
                
                self.log(f"⏸ {self.name} paused")

    def resume(self):
        with self.lock:
            if self.status == 'paused':
                self._pause_event.set()
                self.status = 'running'
                
                # Also resume the actual process if running
                if self.process and self.process.poll() is None:
                    try:
                        if platform.system() == 'Windows':
                            parent = psutil.Process(self.process.pid)
                            parent.resume()
                            for child in parent.children(recursive=True):
                                child.resume()
                        else:
                            os.killpg(os.getpgid(self.process.pid), signal.SIGCONT)
                    except Exception as e:
                        self.log(f"Warning resuming process: {str(e)}", "warning")
                
                self.log(f"▶️ {self.name} resumed")

    def stop(self):
        self._stop_event.set()
        self._pause_event.set()  # Ensure resume if paused
        
        with self.lock:
            self.status = 'failed'
            
        # Stop Flask app if it's a Flask app task
        if hasattr(self, 'launcher'):
            self.launcher.stop()
            
        # Terminate actual process for command tasks
        self._terminate_process()
        self.log(f"⏹ {self.name} stopped")

    def reset(self):
        self.stop()
        # Create new task with same parameters
        new_task = Task(self.name, self.command, self.app_type)
        self.log(f"🔄 {self.name} reset to new task")
        return new_task

    def log(self, message: str, log_type: str = "info"):
        timestamp = datetime.datetime.now().isoformat()
        entry = {
            "timestamp": timestamp,
            "message": message,
            "type": log_type,
            "task_id": self.id,
            "task_name": self.name
        }
        
        # Store in task-specific output
        if log_type == "output":
            self.output.append(message)
            
        # Store in global logs
        with log_lock:
            app_logs.append(entry)

    def _emit_progress(self):
        """Emit progress update to all clients"""
        # This would typically emit via SocketIO, but for SSE we handle it differently
        pass

    def get_state(self):
        with self.lock:
            return {
                'id': self.id,
                'name': self.name,
                'status': self.status,
                'progress': self.progress,
                'command': self.command,
                'app_type': self.app_type,
                'output': self.output[-50:]  # Last 50 lines
            }

# ===== ENHANCED ROUTES =====
@app.route('/')
def index():
    return render_template_string(open("templates/index.html").read())

@app.route('/task/<task_id>')
def task_detail(task_id):
    """Single task view for new tab functionality"""
    return render_template_string(open("templates/task_detail.html").read())

@app.route('/start-task', methods=['POST'])
def start_task():
    data = request.get_json()
    name = data.get('name')
    command = data.get('command')
    app_type = "real" if command else "simulated"
    
    task = Task(name=name, command=command, app_type=app_type)
    with lock:
        tasks[task.id] = task
    
    task.start()
    return jsonify({'task_id': task.id, 'task_name': task.name})

@app.route('/pause-task/<task_id>', methods=['POST'])
def pause_task(task_id):
    with lock:
        task = tasks.get(task_id)
    if task and task.status == 'running':
        task.pause()
        return jsonify({'status': 'paused'})
    return jsonify({'error': 'Task not running or not found'}), 400

@app.route('/resume-task/<task_id>', methods=['POST'])
def resume_task(task_id):
    with lock:
        task = tasks.get(task_id)
    if task and task.status == 'paused':
        task.resume()
        return jsonify({'status': 'running'})
    return jsonify({'error': 'Task not paused or not found'}), 400

@app.route('/stop-task/<task_id>', methods=['POST'])
def stop_task(task_id):
    with lock:
        task = tasks.get(task_id)
    if task:
        task.stop()
        return jsonify({'status': 'stopped'})
    return jsonify({'error': 'Task not found'}), 404

@app.route('/reset-task/<task_id>', methods=['POST'])
def reset_task(task_id):
    with lock:
        task = tasks.get(task_id)
        if not task:
            return jsonify({'error': 'Task not found'}), 404
        
        new_task = task.reset()
        del tasks[task_id]
        tasks[new_task.id] = new_task
        return jsonify({'new_task_id': new_task.id})

@app.route('/remove-task/<task_id>', methods=['POST'])
def remove_task(task_id):
    with lock:
        if task_id in tasks:
            task = tasks[task_id]
            task.stop()  # Ensure clean stop
            del tasks[task_id]
            return jsonify({'status': 'removed'})
        return jsonify({'error': 'Task not found'}), 404

@app.route('/task-progress/<task_id>')
def task_progress(task_id):
    def generate():
        while True:
            with lock:
                task = tasks.get(task_id)
                if not task:
                    yield f"data: {json.dumps({'error': 'Task not found'})}\n\n"
                    break
                
                data = task.get_state()
                yield f"data: {json.dumps(data)}\n\n"
                
                if data['status'] in ['completed', 'failed']:
                    break
            time.sleep(0.5)
    return Response(generate(), mimetype='text/event-stream')

@app.route('/task-output/<task_id>')
def task_output_stream(task_id):
    """Stream task-specific output"""
    def generate():
        last_sent = 0
        while True:
            with lock:
                task = tasks.get(task_id)
                if not task:
                    break
                    
                if len(task.output) > last_sent:
                    for output_line in task.output[last_sent:]:
                        output_data = {
                            'type': 'output',
                            'message': output_line,
                            'task_id': task_id
                        }
                        yield f"data: {json.dumps(output_data)}\n\n"
                    last_sent = len(task.output)
                    
                if task.status in ['completed', 'failed']:
                    break
            time.sleep(0.1)
    return Response(generate(), mimetype='text/event-stream')

@app.route('/app-logs')
def app_logs_stream():
    def generate():
        last_sent = 0
        while True:
            with log_lock:
                if len(app_logs) > last_sent:
                    for log in app_logs[last_sent:]:
                        yield f"data: {json.dumps(log)}\n\n"
                    last_sent = len(app_logs)
            time.sleep(0.5)
    return Response(generate(), mimetype='text/event-stream')

@app.route('/api/tasks')
def get_tasks():
    with lock:
        tasks_data = {task_id: task.get_state() for task_id, task in tasks.items()}
        return jsonify({'tasks': tasks_data})

@app.route('/api/tasks/<task_id>')
def get_task(task_id):
    with lock:
        task = tasks.get(task_id)
        if task:
            return jsonify(task.get_state())
        return jsonify({'error': 'Task not found'}), 404

# Launch demo app
@app.route('/launch-app/<app_name>', methods=['POST'])
def launch_app(app_name):
    """Launch external Flask apps like the demo.py"""
    try:
        apps_dir = Path('./apps')
        app_script = apps_dir / f'{app_name}.py'
        
        if not app_script.exists():
            return jsonify({'error': f'App {app_name} not found'}), 404
        
        # Check if app is already running
        if app_name in app_processes:
            launcher = app_processes[app_name]
            if launcher.get_status() == 'running':
                return jsonify({'error': f'App {app_name} is already running'}), 400
        
        # Create a launcher instance
        port = 5001  # You can make this dynamic if needed
        launcher = FlaskAppLauncher(app_name, app_script, port)
        
        # Start the app
        success = launcher.start()
        
        if success:
            app_processes[app_name] = launcher
            
            # Create a monitoring task in the main task system
            task_name = f"Flask App: {app_name}"
            monitor_task = Task(name=task_name, command=None, app_type="flask_app")
            monitor_task.launcher = launcher
            monitor_task.port = port
            
            with lock:
                tasks[monitor_task.id] = monitor_task
            
            # Start monitoring the app
            monitor_task.start()
            
            # Open browser after a short delay
            def open_browser():
                time.sleep(3)
                webbrowser.open(f'http://localhost:{port}')
            
            threading.Thread(target=open_browser, daemon=True).start()
            
            return jsonify({
                'task_id': monitor_task.id, 
                'task_name': monitor_task.name,
                'url': f'http://localhost:{port}',
                'status': 'started'
            })
        else:
            return jsonify({'error': 'Failed to start app'}), 500
            
    except Exception as e:
        return jsonify({'error': f'Failed to launch app: {str(e)}'}), 500

# Add a route to stop apps
@app.route('/stop-app/<app_name>', methods=['POST'])
def stop_app(app_name):
    """Stop a running Flask app"""
    try:
        if app_name in app_processes:
            launcher = app_processes[app_name]
            launcher.stop()
            del app_processes[app_name]
            return jsonify({'status': 'stopped'})
        return jsonify({'error': 'App not found'}), 404
    except Exception as e:
        return jsonify({'error': f'Failed to stop app: {str(e)}'}), 500

# Predefined commands for quick testing - ADD THIS ROUTE
@app.route('/api/quick-commands')
def get_quick_commands():
    commands = [
        {'name': 'Ping Test', 'command': 'ping -c 4 8.8.8.8' if platform.system() != 'Windows' else 'ping -n 4 8.8.8.8', 'type': 'command'},
        {'name': 'Directory List', 'command': 'ls -la' if platform.system() != 'Windows' else 'dir', 'type': 'command'},
        {'name': 'Python Counter', 'command': 'python -c "for i in range(5): print(f\"Count: {i}\"); import time; time.sleep(1)"', 'type': 'command'},
        {'name': 'System Info', 'command': 'uname -a' if platform.system() != 'Windows' else 'systeminfo', 'type': 'command'},
        {'name': '🚀 Launch Demo App', 'command': 'demo', 'type': 'app'},
    ]
    return jsonify(commands)

if __name__ == '__main__':
    app.run(host='localhost', port=5000, debug=True)