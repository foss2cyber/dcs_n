# apps/demo.py
import os

from flask import Flask

app = Flask(__name__)

@app.route('/')
def results():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Demo App</title>
        <style>
            body { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji",
    "Segoe UI Symbol";
                padding: 2rem;
                color: white;
                text-align: center;
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
                background: rgba(255,255,255,0.1);
                padding: 2rem;
                border-radius: 10px;
                backdrop-filter: blur(10px);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 Demo App Running Successfully!</h1>
            <p>This Flask app was launched from your dashboard.</p>
            <p>Port: 5001 | Status: ✅ Active</p>
        </div>
    </body>
    </html>
    '''

@app.route('/health')
def health():
    return {'status': 'healthy', 'app': 'demo'}

if __name__ == '__main__':
    # Use 0.0.0.0 to allow external connections, debug=False for production
    app.run(host='0.0.0.0', port=5001, debug=False, use_reloader=False)