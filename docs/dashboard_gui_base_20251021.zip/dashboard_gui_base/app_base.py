from flask import Flask, jsonify, request, Response, render_template_string
import threading
import time
import uuid
import json
import datetime
from typing import Dict

app = Flask(__name__)

# ===== TASK MANAGEMENT =====
tasks: Dict[str, 'Task'] = {}
lock = threading.Lock()
app_logs = []
log_lock = threading.Lock()

class Task:
    def __init__(self, name):
        self.id = str(uuid.uuid4())
        self.name = name or f"Task {self.id[:6]}"
        self.progress = 0
        self.status = 'running'
        self._pause_event = threading.Event()
        self._cancel_event = threading.Event()
        self._pause_event.set()
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self.run)
        self.thread.start()
        self.log(f"🚀 Created: {self.name}")

    def run(self):
        try:
            while self.progress < 100:
                if self._cancel_event.is_set():
                    with self.lock:
                        self.status = 'failed'
                    break
                
                self._pause_event.wait()
                
                with self.lock:
                    self.progress = min(self.progress + 1, 100)
                    if self.progress % 10 == 0:
                        self.log(f"📊 {self.name}: {self.progress}%")
                    if self.progress >= 100:
                        self.status = 'completed'
                        break
                
                time.sleep(0.1)
        except Exception as e:
            with self.lock:
                self.status = 'failed'
            self.log(f"❌ {self.name} failed: {str(e)}", "error")
        finally:
            self.log(f"🔚 {self.name} ended: {self.status}")

    def pause(self):
        with self.lock:
            if self.status == 'running':
                self._pause_event.clear()
                self.status = 'paused'
                self.log(f"⏸ {self.name} paused")

    def resume(self):
        with self.lock:
            if self.status == 'paused':
                self._pause_event.set()
                self.status = 'running'
                self.log(f"▶️ {self.name} resumed")

    def cancel(self):
        self._cancel_event.set()
        self._pause_event.set()
        with self.lock:
            self.status = 'failed'
        self.log(f"⏹ {self.name} canceled")

    def reset(self):
        self.cancel()
        new_task = Task(self.name)
        self.log(f"🔄 {self.name} reset to new task")
        return new_task

    def log(self, message: str, log_type: str = "info"):
        timestamp = datetime.datetime.now().isoformat()
        entry = {
            "timestamp": timestamp,
            "message": message,
            "type": log_type
        }
        with log_lock:
            app_logs.append(entry)

# ===== ROUTES =====
@app.route('/')
def index():
    return render_template_string(open("templates/index.html").read())

@app.route('/start-task', methods=['POST'])
def start_task():
    data = request.get_json()
    task = Task(name=data.get('name'))
    with lock:
        tasks[task.id] = task
    return jsonify({'task_id': task.id, 'task_name': task.name})

@app.route('/pause-task/<task_id>', methods=['POST'])
def pause_task(task_id):
    with lock:
        task = tasks.get(task_id)
    if task and task.status == 'running':
        task.pause()
        return jsonify({'status': 'paused'})
    return jsonify({'error': 'Task not running or not found'}), 400

@app.route('/resume-task/<task_id>', methods=['POST'])
def resume_task(task_id):
    with lock:
        task = tasks.get(task_id)
    if task and task.status == 'paused':
        task.resume()
        return jsonify({'status': 'running'})
    return jsonify({'error': 'Task not paused or not found'}), 400

@app.route('/reset-task/<task_id>', methods=['POST'])
def reset_task(task_id):
    with lock:
        task = tasks.get(task_id)
        if not task:
            return jsonify({'error': 'Task not found'}), 404
        
        new_task = task.reset()
        del tasks[task_id]
        tasks[new_task.id] = new_task
        return jsonify({'new_task_id': new_task.id})

@app.route('/remove-task/<task_id>', methods=['POST'])
def remove_task(task_id):
    with lock:
        if task_id in tasks:
            del tasks[task_id]
            return jsonify({'status': 'removed'})
        return jsonify({'error': 'Task not found'}), 404

@app.route('/task-progress/<task_id>')
def task_progress(task_id):
    def generate():
        while True:
            with lock:
                task = tasks.get(task_id)
                if not task:
                    yield f"data: {json.dumps({'error': 'Task not found'})}\n\n"
                    break
                
                with task.lock:
                    data = {
                        'status': task.status,
                        'progress': task.progress,
                        'name': task.name,
                        'id': task.id
                    }
                
                yield f"data: {json.dumps(data)}\n\n"
                
                if data['status'] in ['completed', 'failed']:
                    break
            time.sleep(0.5)
    return Response(generate(), mimetype='text/event-stream')

@app.route('/app-logs')
def app_logs_stream():
    def generate():
        last_sent = 0
        while True:
            with log_lock:
                if len(app_logs) > last_sent:
                    for log in app_logs[last_sent:]:
                        yield f"data: {json.dumps(log)}\n\n"
                    last_sent = len(app_logs)
            time.sleep(0.5)
    return Response(generate(), mimetype='text/event-stream')

if __name__ == '__main__':
    app.run(debug=True)