# flask-db-vite (Flask + Vite frontend)

```Markdown
└── 📁flask-db-vite
    └── 📁__pycache__
    └── 📁public
        └── ol.css
    └── 📁src
        ├── basemap.js
        ├── config.js
        ├── historical.js
        ├── main.js
        ├── reset.css
        └── styles.css
    ├── .gitignore
    ├── api-docs.html
    ├── app.py
    ├── basemap.html
    ├── build_tiles.sh
    ├── config.py
    ├── convert_shp_to_geojson.py
    ├── DOCS.md
    ├── health.html
    ├── historical.html
    ├── index.html
    ├── init_db.sql
    ├── launch-dev.bat
    ├── launch.bat
    ├── launch.sh
    ├── package-lock.json
    ├── package.json
    ├── README.md
    ├── requirements.txt
    ├── run.py
    ├── sample_data.sql
    ├── setup_db_new.py
    ├── setup_db_old.py
    ├── update_target_codes.py
    └── vite.config.js
```
---

# app.py
import os
import re
import json
import datetime
import logging
from flask import Flask, jsonify, request, send_file, send_from_directory
import psycopg2
from psycopg2.extras import RealDictCursor
from config import Config

app = Flask(__name__,
    static_folder='public',
    static_url_path=''
)
app.config.from_object(Config)
os.makedirs(app.config['REPORTS_DIR'], exist_ok=True)

def get_db():
    return psycopg2.connect(
        dsn=app.config['DB_URL'],
        cursor_factory=RealDictCursor
    )

# ==================== HIERARCHICAL DROPDOWN ENDPOINTS ====================
@app.route('/api/countries')
def get_countries():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT country_name 
                    FROM comprehensive_query 
                    WHERE country_name IS NOT NULL 
                    ORDER BY country_name
                """)
                countries = [row['country_name'] for row in cur.fetchall()]
                if not countries:
                    cur.execute("""
                        SELECT DISTINCT country_name 
                        FROM target 
                        WHERE country_name IS NOT NULL 
                        ORDER BY country_name
                    """)
                    countries = [row['country_name'] for row in cur.fetchall()]
        return jsonify(countries)
    except Exception as e:
        app.logger.error(f"Countries query failed: {e}")
        return jsonify([])

@app.route('/api/target-types/<country>')
def get_target_types(country):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.target_name 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name IS NOT NULL 
                    ORDER BY sq.target_name
                """, (country,))
                target_names = [row['target_name'] for row in cur.fetchall()]
        return jsonify(target_names)
    except Exception as e:
        app.logger.error(f"Target names query failed for {country}: {e}")
        return jsonify([])

@app.route('/api/image-ids/<country>/<target_name>')
def get_image_ids(country, target_name):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.image_id 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name = %s 
                    AND sq.image_id IS NOT NULL 
                    ORDER BY sq.image_id
                """, (country, target_name))
                image_ids = [row['image_id'] for row in cur.fetchall()]
        return jsonify(image_ids)
    except Exception as e:
        app.logger.error(f"Image IDs query failed for {country}/{target_name}: {e}")
        return jsonify([])

# ==================== UNIFIED DATA ENDPOINT ====================
@app.route('/api/unified-data/<image_id>')
def get_unified_data(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400

    target_names = request.args.getlist('target_name')
    target_classes = request.args.getlist('target_class')
    min_score = request.args.get('min_score', 0.0, type=float)
    max_score = request.args.get('max_score', 1.0, type=float)

    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # VECTOR DATA — join ONLY with `target` on `target_name`
                vector_query = """
                    SELECT 
                        sq.target_name,
                        sq.country_name,
                        sq.image_id, 
                        sq.image_date,
                        sq.target_class,
                        sq.score,
                        sq.st_x as centroid_lon,
                        sq.st_y as centroid_lat,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.image_id = %s
                """
                vector_params = [image_id]
                vector_conditions = []
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    vector_conditions.append(f"sq.target_name IN ({placeholders})")
                    vector_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    vector_conditions.append(f"sq.target_class IN ({placeholders})")
                    vector_params.extend(target_classes)
                if min_score > 0:
                    vector_conditions.append("sq.score >= %s")
                    vector_params.append(min_score)
                if max_score < 1.0:
                    vector_conditions.append("sq.score <= %s")
                    vector_params.append(max_score)
                if vector_conditions:
                    vector_query += " AND " + " AND ".join(vector_conditions)

                cur.execute(vector_query, vector_params)
                vector_rows = cur.fetchall()

                vector_features = []
                for row in vector_rows:
                    geometry_data = {
                        "type": "Polygon",
                        "coordinates": [[
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001]
                        ]]
                    }
                    vector_features.append({
                        "type": "Feature",
                        "geometry": geometry_data,
                        "properties": {
                            "id": f"{row['image_id']}_{row['target_class']}",
                            "target_class": row["target_class"],
                            "target_name": row["target_name"],
                            "target_type": row["target_type"],
                            "country_name": row["country_name"],
                            "score": float(row["score"]) if row["score"] is not None else None,
                            "centroid": [float(row["centroid_lon"]), float(row["centroid_lat"])]
                        }
                    })

                # CHART DATA — join ONLY with `target` on `target_name`
                chart_query = """
                    SELECT 
                        cq.target_name,
                        cq.target_class, 
                        cq.total_count,
                        cq.score as avg_score,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM comprehensive_query cq
                    LEFT JOIN target t ON cq.target_name = t.target_name
                    WHERE cq.image_id = %s
                """
                chart_params = [image_id]
                chart_conditions = []
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    chart_conditions.append(f"cq.target_name IN ({placeholders})")
                    chart_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    chart_conditions.append(f"cq.target_class IN ({placeholders})")
                    chart_params.extend(target_classes)
                if min_score > 0:
                    chart_conditions.append("cq.score >= %s")
                    chart_params.append(min_score)
                if max_score < 1.0:
                    chart_conditions.append("cq.score <= %s")
                    chart_params.append(max_score)
                if chart_conditions:
                    chart_query += " AND " + " AND ".join(chart_conditions)
                chart_query += " ORDER BY cq.total_count DESC"

                cur.execute(chart_query, chart_params)
                chart_rows = cur.fetchall()
                chart_data = [
                    {
                        'target_name': row['target_name'],
                        'target_class': row['target_class'],
                        'target_type': row['target_type'],
                        'total_count': row['total_count'],
                        'avg_score': float(row['avg_score']) if row['avg_score'] is not None else 0.0
                    }
                    for row in chart_rows
                ]

        return jsonify({
            "vector_data": {
                "type": "FeatureCollection", 
                "features": vector_features
            },
            "chart_data": chart_data
        })
    except Exception as e:
        app.logger.error(f"Unified data query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to retrieve unified data"}), 500

# ==================== FILTER OPTIONS ====================
@app.route('/api/filter-options/<image_id>')
def get_filter_options(image_id):
    country = request.args.get('country')
    target_name = request.args.get('target_name')
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_name
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                names_result = cur.fetchall()
                target_names = [row['target_name'] for row in names_result if row['target_name']]

                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                classes = [row['target_class'] for row in cur.fetchall()]

                if country and target_name:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                score_result = cur.fetchone()

        return jsonify({
            'target_names': target_names or [],
            'target_classes': classes or [],
            'score_range': {
                'min': float(score_result['min_score']) if score_result and score_result['min_score'] is not None else 0.0,
                'max': float(score_result['max_score']) if score_result and score_result['max_score'] is not None else 1.0
            }
        })
    except Exception as e:
        app.logger.error(f"Filter options query failed for {image_id}: {e}")
        return jsonify({
            'target_names': [],
            'target_classes': [],
            'score_range': {'min': 0.0, 'max': 1.0}
        })

# ==================== HISTORICAL TIMELINE ====================
@app.route('/api/historical-timeline')
def get_historical_timeline():
    country = request.args.get('country')
    target_name = request.args.get('target_name')
    if not country:
        return jsonify([])

    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                query = """
                    SELECT 
                        sq.target_name,
                        sq.image_date,
                        COUNT(*) as detection_count,
                        COALESCE(t.target_type, 'N/A') as target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.country_name = %s
                """
                params = [country]
                if target_name and target_name != 'All Targets':
                    query += " AND sq.target_name = %s"
                    params.append(target_name)
                query += """
                    GROUP BY sq.target_name, sq.image_date, t.target_type
                    ORDER BY sq.target_name, sq.image_date
                """
                cur.execute(query, params)
                rows = cur.fetchall()

        timeline_data = {}
        for row in rows:
            name = row['target_name']
            if name not in timeline:
                timeline_data[name] = {
                    'target_name': name,
                    'target_type': row['target_type'],
                    'data_points': []
                }
            timeline_data[name]['data_points'].append({
                'date': row['image_date'].isoformat() if row['image_date'] else None,
                'count': row['detection_count']
            })
        return jsonify(list(timeline_data.values()))
    except Exception as e:
        app.logger.error(f"Historical timeline query failed: {e}")
        return jsonify([])

# ==================== EXISTING ENDPOINTS (UNCHANGED) ====================
@app.route('/api/data/<image_id>')
def get_geospatial_data(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        f.id,
                        f.target_class,
                        f.score,
                        ST_AsGeoJSON(f.target_geom) AS geometry,
                        ST_X(ST_Centroid(f.target_geom)) AS centroid_lon,
                        ST_Y(ST_Centroid(f.target_geom)) AS centroid_lat
                    FROM findings f
                    WHERE f.image_id = %s
                """, (image_id,))
                rows = cur.fetchall()
        features = []
        for row in rows:
            if row["geometry"]:
                geometry_data = json.loads(row["geometry"])
            else:
                geometry_data = {
                    "type": "Point", 
                    "coordinates": [
                        row["centroid_lon"] or 8.55, 
                        row["centroid_lat"] or 50.04
                    ]
                }
            features.append({
                "type": "Feature",
                "geometry": geometry_data,
                "properties": {
                    "id": row["id"],
                    "target_class": row["target_class"],
                    "score": float(row["score"]) if row["score"] is not None else None,
                    "centroid": [
                        float(row["centroid_lon"]) if row["centroid_lon"] is not None else 8.55,
                        float(row["centroid_lat"]) if row["centroid_lat"] is not None else 50.04
                    ]
                }
            })
        return jsonify({"type": "FeatureCollection", "features": features})
    except Exception as e:
        app.logger.error(f"Failed to fetch data for image_id={image_id}: {e}")
        return jsonify({"error": "Failed to retrieve geospatial data"}), 500

@app.route('/api/charts/<image_id>/target_class')
def get_target_class_counts(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT target_class, total_count
                    FROM comprehensive_query
                    WHERE image_id = %s
                """, (image_id,))
                rows = cur.fetchall()
        if not rows:
            with get_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        SELECT target_class, COUNT(*) as total_count
                        FROM findings 
                        WHERE image_id = %s
                        GROUP BY target_class
                    """, (image_id,))
                    rows = cur.fetchall()
        return jsonify([{"label": r["target_class"], "value": r["total_count"]} for r in rows])
    except Exception as e:
        app.logger.error(f"Chart query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to generate chart data"}), 500

@app.route('/api/reports')
def list_reports():
    try:
        files = [f for f in os.listdir(app.config['REPORTS_DIR']) if f.endswith('.txt')]
        return jsonify(sorted(files))
    except Exception as e:
        app.logger.error(f"Failed to list reports: {e}")
        return jsonify({"error": "Cannot list reports"}), 500

@app.route('/api/reports/<filename>')
def get_report(filename):
    if not filename.endswith('.txt'):
        return jsonify({"error": "Only .txt reports are allowed"}), 400
    try:
        return send_from_directory(app.config['REPORTS_DIR'], filename, mimetype='text/plain')
    except FileNotFoundError:
        return jsonify({"error": "Report not found"}), 404

# ==================== LOCAL BASEMAP ENDPOINTS ====================
@app.route('/api/local-basemap')
def get_local_basemap():
    basemap_dir = 'public/basemaps'
    try:
        if not os.path.exists(basemap_dir):
            return get_dynamic_fallback_basemap()
        vector_files = []
        for file in os.listdir(basemap_dir):
            if file.endswith(('.shp', '.geojson', '.json', '.pbf')):
                vector_files.append(os.path.join(basemap_dir, file))
        if not vector_files:
            return get_dynamic_fallback_basemap()
        preferred_order = ['.geojson', '.json', '.shp', '.pbf']
        vector_files.sort(key=lambda x: next((i for i, ext in enumerate(preferred_order) if x.endswith(ext)), len(preferred_order)))
        found_vector_path = vector_files[0]
        if found_vector_path.endswith('.shp'):
            try:
                import geopandas as gpd
                gdf = gpd.read_file(found_vector_path)
                geojson_data = gdf.to_json()
                return jsonify(json.loads(geojson_data))
            except ImportError:
                return get_dynamic_fallback_basemap()
            except Exception as e:
                return get_dynamic_fallback_basemap()
        elif found_vector_path.endswith(('.geojson', '.json')):
            return send_file(found_vector_path, mimetype='application/geo+json')
        elif found_vector_path.endswith('.pbf'):
            return send_file(found_vector_path, mimetype='application/octet-stream')
    except Exception as e:
        return get_hardcoded_fallback_basemap()

def get_dynamic_fallback_basemap():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        ST_XMin(ST_Extent(target_geom)) as min_lon,
                        ST_YMin(ST_Extent(target_geom)) as min_lat, 
                        ST_XMax(ST_Extent(target_geom)) as max_lon,
                        ST_YMax(ST_Extent(target_geom)) as max_lat
                    FROM findings 
                    WHERE target_geom IS NOT NULL
                    LIMIT 1
                """)
                extent_result = cur.fetchone()
                if extent_result and extent_result['min_lon']:
                    min_lon = float(extent_result['min_lon'])
                    min_lat = float(extent_result['min_lat'])
                    max_lon = float(extent_result['max_lon'])
                    max_lat = float(extent_result['max_lat'])
                    lon_buffer = (max_lon - min_lon) * 0.1
                    lat_buffer = (max_lat - min_lat) * 0.1
                    dynamic_geojson = {
                        "type": "FeatureCollection",
                        "features": [{
                            "type": "Feature",
                            "geometry": {
                                "type": "Polygon",
                                "coordinates": [[
                                    [min_lon - lon_buffer, min_lat - lat_buffer],
                                    [max_lon + lon_buffer, min_lat - lat_buffer],
                                    [max_lon + lon_buffer, max_lat + lat_buffer],
                                    [min_lon - lon_buffer, max_lat + lat_buffer],
                                    [min_lon - lon_buffer, min_lat - lat_buffer]
                                ]]
                            },
                            "properties": {
                                "name": "Data Extent Boundary",
                                "type": "extent",
                                "source": "dynamic_fallback"
                            }
                        }]
                    }
                    return jsonify(dynamic_geojson)
    except Exception as e:
        pass
    return get_hardcoded_fallback_basemap()

def get_hardcoded_fallback_basemap():
    sample_geojson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [8.0, 49.5], [9.0, 49.5], [9.0, 50.5], [8.0, 50.5], [8.0, 49.5]
                    ]]
                },
                "properties": {"name": "Sample Region", "type": "administrative"}
            }
        ]
    }
    return jsonify(sample_geojson)

# ==================== PAGE ROUTES ====================
@app.route('/api')
def api_documentation_page():
    return send_from_directory('.', 'api-docs.html')

@app.route('/health-page')
def health_page():
    return send_from_directory('.', 'health.html')

@app.route('/basemap')
def basemap_page():
    return send_from_directory('.', 'basemap.html')

@app.route('/historical-deployment')  
def historical_deployment_page():
    return send_from_directory('.', 'historical.html')

@app.route('/api/historical-data')
def get_historical_data():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT image_date, target_class, COUNT(*) as total_count
                    FROM findings
                    GROUP BY image_date, target_class
                    ORDER BY image_date, total_count DESC
                """)
                rows = cur.fetchall()
        return jsonify([
            {'date': r['image_date'].isoformat() if r['image_date'] else None,
             'target_class': r['target_class'],
             'total_count': r['total_count']}
            for r in rows
        ])
    except Exception as e:
        app.logger.error(f"Historical data query failed: {e}")
        return jsonify({"error": "Failed to retrieve historical data"}), 500

# ==================== STATIC ASSETS (REMOVED COG/TILES) ====================
@app.route('/assets/<path:filename>')
def serve_assets(filename):
    return send_from_directory('dist/assets', filename)

# REMOVED: /cogs/<filename> — now served by NGINX

@app.route('/')
@app.route('/<path:path>')
def serve_frontend(path='index.html'):
    if os.path.exists(f"dist/{path}"):
        return send_from_directory('dist', path)
    else:
        return send_from_directory('dist', 'index.html')

@app.route('/api-list')
def list_endpoints():
    endpoints = []
    for rule in app.url_map.iter_rules():
        endpoints.append({
            "endpoint": rule.endpoint,
            "methods": list(rule.methods),
            "path": str(rule)
        })
    return jsonify(endpoints)

# ==================== HEALTH CHECK ====================
@app.route('/health')
def health_check():
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'version': '1.0.0-rc.4'
    }
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT 1')
        health_status['database'] = 'connected'
    except Exception as e:
        health_status['database'] = 'disconnected'
        health_status['status'] = 'unhealthy'
        health_status['database_error'] = str(e)

    def count_image_id_directories(directory):
        try:
            if not os.path.exists(directory):
                return 0
            items = os.listdir(directory)
            return sum(1 for item in items if os.path.isdir(os.path.join(directory, item)))
        except OSError:
            return 0

    def count_recursive_files(directory, extension):
        count = 0
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith(extension):
                    count += 1
        return count

    essential_dirs = {
        'reports_dir': app.config['REPORTS_DIR'],
        'cogs_dir': 'public/cogs',
        'tiles_dir': 'public/tiles'
    }
    for dir_name, dir_path in essential_dirs.items():
        if os.path.exists(dir_path) and os.path.isdir(dir_path):
            health_status[dir_name] = 'exists'
            try:
                if dir_name == 'tiles_dir':
                    layer_count = count_image_id_directories(dir_path)
                    health_status[f'{dir_name}_layer_count'] = layer_count
                    tile_count = count_recursive_files(dir_path, '.png')
                    health_status[f'{dir_name}_tile_count'] = tile_count
                else:
                    file_count = len([f for f in os.listdir(dir_path) if os.path.isfile(os.path.join(dir_path, f))])
                    health_status[f'{dir_name}_file_count'] = file_count
            except OSError:
                health_status[f'{dir_name}_file_count'] = 'unaccessible'
        else:
            health_status[dir_name] = 'missing'
            health_status['status'] = 'degraded'

    status_code = 200 if health_status['status'] == 'healthy' else 503
    return jsonify(health_status), status_code

# ==================== ERROR HANDLING ====================
@app.errorhandler(500)
def handle_internal_error(e):
    app.logger.error(f"Internal error: {str(e)}")
    return jsonify({"error": "Internal server error"}), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found"}), 404

@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY' 
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    app.run(host='127.0.0.1', port=5000, debug=True)

// vite.config.js
import { defineConfig } from "vite";

export default defineConfig({
  optimizeDeps: {
    include: ["ol", "geotiff", "chart.js", "proj4"],
  },
  root: "./",
  base: "./",
  publicDir: "public",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: "index.html",
        apiDocs: "api-docs.html",
        basemap: "basemap.html",
        historical: "historical.html",
        health: "health.html",
      },
    },
  },
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:5000",
      "/reports": "http://localhost:5000",
      "/health": "http://localhost:5000",
      "/health-page": "http://localhost:5000",
      "/basemap": "http://localhost:5000",
      "/historical-deployment": "http://localhost:5000",
    },
    cors: true,
  },
  define: {
    "import.meta.env.VITE_ASSET_SERVER": JSON.stringify(
      process.env.VITE_ASSET_SERVER || "http://localhost:8082"
    ),
  },
});

// src/config.js
export const CONFIG = {
  ASSET_SERVER: import.meta.env.VITE_ASSET_SERVER || "http://localhost:8082",
  API_BASE: "/api",
  TILES_BASE: "/tiles",
  COGS_BASE: "/cogs",
  REPORTS_BASE: "/reports",
  BASEMAPS_BASE: "/basemaps",
  ICONS_BASE: "/icons",
  IMAGES_BASE: "/images",
};

export function getAssetUrl(path) {
  return `${CONFIG.ASSET_SERVER}/${path}`;
}

export async function checkAssetServer() {
  try {
    const response = await fetch(CONFIG.ASSET_SERVER, { method: "HEAD" });
    return response.ok;
  } catch (error) {
    console.warn("Asset server not accessible, falling back to local assets");
    return false;
  }
}

# .env
VITE_ASSET_SERVER=http://localhost:8082
DB_HOST=localhost
DB_PORT=5432
DB_NAME=postgres
DB_USER=postgres
DB_PASSWORD=postgres
REPORTS_DIR=./reports

# Optional: Connection pooling
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20

# config.py
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    DB_URL = (
        f"postgresql://{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}"
        f"@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '5432')}"
        f"/{os.getenv('DB_NAME')}"
    )
    REPORTS_DIR = os.getenv('REPORTS_DIR', './reports')
    
    
    # Static Asset Server Configuration
    ASSET_SERVER = os.getenv('ASSET_SERVER', 'http://localhost:8082')
    
    # Asset paths on the static server
    TILES_BASE_URL = f"{ASSET_SERVER}/tiles"
    COGS_BASE_URL = f"{ASSET_SERVER}/cogs" 
    REPORTS_BASE_URL = f"{ASSET_SERVER}/reports"
    BASEMAPS_BASE_URL = f"{ASSET_SERVER}/basemaps"
    ICONS_BASE_URL = f"{ASSET_SERVER}/icons"
    IMAGES_BASE_URL = f"{ASSET_SERVER}/images"
    
    # Add for production security
    #SECRET_KEY = os.getenv('SECRET_KEY', 'dev-key-change-in-production')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file upload

// src/main.js
import "open-props/open-props.min.css";
import OlMap from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import XYZ from "ol/source/XYZ";
import WebGLTileLayer from "ol/layer/WebGLTile";
import { fromLonLat, toLonLat } from "ol/proj";
import { defaults as defaultInteractions } from "ol/interaction";
import { defaults as defaultControls } from "ol/control";
import ScaleLine from "ol/control/ScaleLine";
import Rotate from "ol/control/Rotate";
import { Style, Stroke, Fill, Circle as CircleStyle } from "ol/style";
import Overlay from "ol/Overlay";
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);
import { marked } from "marked";
import { CONFIG, getAssetUrl } from "./config.js";

let map, vectorSource, barChart;
let cogLayer, xyzLayer;
let currentSelections = {
  country: null,
  targetType: null,
  imageId: null,
};
let currentFilters = {};
let scoreFilterTimeout;
let abortController = new AbortController(); // For canceling in-flight requests

document.addEventListener("DOMContentLoaded", async () => {
  const requiredElements = [
    "countrySelector",
    "targetTypeSelector",
    "imageIdSelector",
    "map",
    "barChart",
    "reportContent",
  ];
  const missingElements = requiredElements.filter(
    (id) => !document.getElementById(id)
  );
  if (missingElements.length > 0) {
    console.error("Missing DOM elements:", missingElements);
    showErrorToUser(`Required elements missing: ${missingElements.join(", ")}`);
    return;
  }

  const countrySelector = document.getElementById("countrySelector");
  const targetTypeSelector = document.getElementById("targetTypeSelector");
  const imageIdSelector = document.getElementById("imageIdSelector");
  const selectionStatus = document.getElementById("selectionStatus");
  const reportContent = document.getElementById("reportContent");
  const barCanvas = document.getElementById("barChart");
  const opacitySlider = document.getElementById("opacitySlider");
  const fitToDataBtn = document.getElementById("fitToData");
  const clearDataBtn = document.getElementById("clearData");
  const scoreRange = document.getElementById("scoreRange");
  const scoreValue = document.getElementById("scoreValue");

  // Validate critical elements exist
  if (!barCanvas) {
    console.error("Bar chart canvas element not found");
    return;
  }

  // TOOLTIP SETUP
  const tooltipElement = document.createElement("div");
  tooltipElement.className = "map-tooltip";
  tooltipElement.setAttribute("role", "tooltip");
  tooltipElement.setAttribute("aria-live", "polite");
  document.body.appendChild(tooltipElement);
  const tooltipOverlay = new Overlay({
    element: tooltipElement,
    positioning: "bottom-center",
    offset: [0, -15],
    stopEvent: false,
  });

  // MAP SETUP
  vectorSource = new VectorSource();
  const vectorLayer = new VectorLayer({
    source: vectorSource,
    style: function (feature) {
      const geom = feature.getGeometry();
      const isHover = feature.get("hover");
      const props = feature.getProperties();
      const styles = [
        new Style({
          stroke: new Stroke({
            color: isHover ? "#ff4444" : "#3388ff",
            width: isHover ? 4 : 3,
          }),
          fill: new Fill({
            color: isHover ? "rgba(255, 68, 68, 0.3)" : "rgba(51, 136, 255, 0)",
          }),
          zIndex: 2,
        }),
      ];

      if (
        geom &&
        (geom.getType() === "Polygon" || geom.getType() === "Point")
      ) {
        try {
          const centroid =
            geom.getType() === "Polygon" ? geom.getInteriorPoint() : geom;
          styles.push(
            new Style({
              geometry: centroid,
              image: new CircleStyle({
                radius: 6,
                fill: new Fill({
                  color: getColorForClass(props.target_class),
                }),
                stroke: new Stroke({
                  color: "white",
                  width: 1.5,
                }),
              }),
              zIndex: 1,
            })
          );
        } catch (e) {
          console.warn("Could not calculate centroid for feature:", e);
        }
      }
      return styles;
    },
  });

  cogLayer = new WebGLTileLayer({
    visible: false,
    opacity: 1,
    source: null,
  });
  xyzLayer = new TileLayer({
    visible: true,
    opacity: 1,
    source: null,
  });

  map = new OlMap({
    target: "map",
    layers: [cogLayer, xyzLayer, vectorLayer],
    view: new View({
      center: fromLonLat([8.55, 50.04]),
      zoom: 12,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" }),
      new Rotate({ autoHide: false }),
    ]),
    interactions: defaultInteractions(),
  });
  map.addOverlay(tooltipOverlay);

  // Ensure map is properly sized
  setTimeout(() => {
    map.updateSize();
  }, 100);

  // TOOLTIP INTERACTION
  let hoverFeature = null;
  map.on("pointermove", function (evt) {
    const feature = map.forEachFeatureAtPixel(evt.pixel, function (feature) {
      return feature;
    });

    if (feature) {
      if (hoverFeature !== feature) {
        if (hoverFeature) {
          hoverFeature.set("hover", false);
        }
        feature.set("hover", true);
        hoverFeature = feature;
        const props = feature.getProperties();
        const coordinates = evt.coordinate;
        const geometry = feature.getGeometry();

        let centroidCoords = [0, 0];
        if (geometry) {
          try {
            if (geometry.getType() === "Polygon") {
              const centroid = geometry.getInteriorPoint();
              centroidCoords = toLonLat(centroid.getCoordinates());
            } else {
              centroidCoords = toLonLat(geometry.getCoordinates());
            }
          } catch (e) {
            console.warn("Error calculating coordinates for tooltip:", e);
          }
        }

        const displayName =
          props.target_name ||
          (props.target_class
            ? `Target_${props.target_class}`
            : "Unknown Target");

        tooltipElement.innerHTML = `
          <div class="tooltip-content">
            <strong>${escapeHtml(displayName)}</strong>
            <div class="tooltip-details">
              <span class="tooltip-label">Class:</span> ${escapeHtml(
                props.target_class || "N/A"
              )}<br/>
              <span class="tooltip-label">Type:</span> ${escapeHtml(
                props.target_type || "N/A"
              )}<br/>
              <span class="tooltip-label">Score:</span> ${
                props.score ? (props.score * 100).toFixed(1) + "%" : "N/A"
              }<br/>
              <span class="tooltip-label">Centroid:</span> ${centroidCoords[0].toFixed(
                6
              )}, ${centroidCoords[1].toFixed(6)}
            </div>
          </div>
        `;
        tooltipOverlay.setPosition(coordinates);
        tooltipElement.style.display = "block";
      }
    } else {
      if (hoverFeature) {
        hoverFeature.set("hover", false);
        hoverFeature = null;
      }
      tooltipElement.style.display = "none";
    }
  });

  // AUTO-LOAD FUNCTIONALITY
  async function autoLoadData() {
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      await loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  }

  function applyDynamicScoreFilter(scorePercent) {
    if (currentSelections.imageId) {
      currentFilters = getCurrentFilters();
      loadUnifiedData(currentSelections.imageId, currentFilters);
    }
  }

  async function loadFilterOptions(imageId) {
    if (!imageId) return;

    try {
      const params = new URLSearchParams();
      if (currentSelections.country) {
        params.append("country", currentSelections.country);
      }
      if (currentSelections.targetType) {
        params.append("target_name", currentSelections.targetType);
      }

      const res = await fetch(`/api/filter-options/${imageId}?${params}`, {
        signal: abortController.signal,
      });
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

      const options = await res.json();

      // Update class filter
      const classFilter = document.getElementById("classFilter");
      if (classFilter) {
        const currentClassValue = classFilter.value;
        classFilter.innerHTML =
          '<option value="">All Classes</option>' +
          (options.target_classes && Array.isArray(options.target_classes)
            ? options.target_classes
                .map(
                  (cls) =>
                    `<option value="${escapeHtml(cls)}">${escapeHtml(
                      cls
                    )}</option>`
                )
                .join("")
            : "");
        if (
          currentClassValue &&
          options.target_classes.includes(currentClassValue)
        ) {
          classFilter.value = currentClassValue;
        }
      }

      // Update name filter
      const nameFilter = document.getElementById("nameFilter");
      if (nameFilter) {
        const currentNameValue = nameFilter.value;
        nameFilter.innerHTML =
          '<option value="">All Names</option>' +
          (options.target_names && Array.isArray(options.target_names)
            ? options.target_names
                .map(
                  (name) =>
                    `<option value="${escapeHtml(name)}">${escapeHtml(
                      name
                    )}</option>`
                )
                .join("")
            : "");
        if (
          currentNameValue &&
          options.target_names.includes(currentNameValue)
        ) {
          nameFilter.value = currentNameValue;
        }
      }

      // Update score range
      if (scoreRange && scoreValue && options.score_range) {
        const minScorePercent = (options.score_range.min || 0) * 100;
        const maxScorePercent = (options.score_range.max || 1) * 100;
        scoreRange.min = 0;
        scoreRange.max = 100;
        scoreRange.step = 0.1;
        let currentScorePercent = 0;
        if (currentFilters.min_score !== undefined) {
          currentScorePercent = currentFilters.min_score * 100;
        }
        scoreRange.value = currentScorePercent;
        scoreValue.textContent = `${parseFloat(currentScorePercent).toFixed(
          1
        )}%`;
      }

      updateFilterContextDisplay();
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load filter options:", error);
        showErrorToUser("Failed to load filter options");
      }
    }
  }

  function getCurrentFilters() {
    const filters = {};
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");

    if (nameFilter && nameFilter.value) {
      filters.target_name = [nameFilter.value];
    } else if (classFilter && classFilter.value) {
      filters.target_class = [classFilter.value];
    }

    if (scoreRange && parseFloat(scoreRange.value) > 0) {
      filters.min_score = parseFloat(scoreRange.value) / 100;
    }

    return filters;
  }

  function resetFilters() {
    const classFilter = document.getElementById("classFilter");
    const nameFilter = document.getElementById("nameFilter");
    const scoreRange = document.getElementById("scoreRange");
    const scoreValue = document.getElementById("scoreValue");

    if (classFilter) classFilter.value = "";
    if (nameFilter) nameFilter.value = "";
    if (scoreRange && scoreValue) {
      scoreRange.value = scoreRange.min;
      scoreValue.textContent = `${parseFloat(scoreRange.min).toFixed(1)}%`;
    }
    updateFilterContextDisplay();
  }

  // HIERARCHICAL DROPDOWN SYSTEM
  async function loadCountries() {
    try {
      showLoadingState("country", "Loading countries...");
      const response = await fetch("/api/countries", {
        signal: abortController.signal,
      });
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const countries = await response.json();
      countrySelector.innerHTML = '<option value="">Select Country</option>';

      if (countries.length > 0) {
        countries.forEach((country) => {
          const option = document.createElement("option");
          option.value = country;
          option.textContent = country;
          countrySelector.appendChild(option);
        });
        updateSelectionStatus("Select a country to continue");
      } else {
        countrySelector.innerHTML =
          '<option value="">No countries available</option>';
        updateSelectionStatus("No countries found in database");
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load countries:", error);
        countrySelector.innerHTML =
          '<option value="">Error loading countries</option>';
        updateSelectionStatus("Error loading countries");
        showErrorToUser("Failed to load countries");
      }
    } finally {
      hideLoadingState("country");
    }
  }

  async function loadTargetTypes(country) {
    if (!country) return;

    try {
      showLoadingState("targetType", "Loading target names...");
      targetTypeSelector.disabled = true;
      imageIdSelector.disabled = true;

      const response = await fetch(
        `/api/target-types/${encodeURIComponent(country)}`,
        { signal: abortController.signal }
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const targetNames = await response.json();
      targetTypeSelector.innerHTML =
        '<option value="">Select Target Name</option>';

      if (targetNames.length > 0) {
        targetNames.forEach((targetName) => {
          const option = document.createElement("option");
          option.value = targetName;
          option.textContent = targetName;
          targetTypeSelector.appendChild(option);
        });
        targetTypeSelector.disabled = false;
        updateSelectionStatus(`Country: ${country} - Select target name`);

        if (currentSelections.imageId) {
          await loadFilterOptions(currentSelections.imageId);
        }
      } else {
        targetTypeSelector.innerHTML =
          '<option value="">No target names available</option>';
        updateSelectionStatus(`No target names found for ${country}`);
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load target names:", error);
        targetTypeSelector.innerHTML =
          '<option value="">Error loading target names</option>';
        updateSelectionStatus("Error loading target names");
      }
    } finally {
      hideLoadingState("targetType");
    }
  }

  async function loadImageIds(country, targetName) {
    if (!country || !targetName) return;

    try {
      showLoadingState("imageId", "Loading image IDs...");
      imageIdSelector.disabled = true;

      const response = await fetch(
        `/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(
          targetName
        )}`,
        { signal: abortController.signal }
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const imageIds = await response.json();
      imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';

      if (imageIds.length > 0) {
        imageIds.forEach((imageId) => {
          const option = document.createElement("option");
          option.value = imageId;
          option.textContent = imageId;
          imageIdSelector.appendChild(option);
        });
        imageIdSelector.disabled = false;
        updateSelectionStatus(
          `Country: ${country}, Name: ${targetName} - Select image ID`
        );
      } else {
        imageIdSelector.innerHTML =
          '<option value="">No images available</option>';
        updateSelectionStatus(
          `No images found for ${targetName} in ${country}`
        );
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load image IDs:", error);
        imageIdSelector.innerHTML =
          '<option value="">Error loading images</option>';
        updateSelectionStatus("Error loading images");
      }
    } finally {
      hideLoadingState("imageId");
    }
  }

  // UNIFIED DATA LOADING
  async function loadUnifiedData(imageId, filters = {}) {
    if (!imageId) return;

    // Cancel any ongoing requests
    abortController.abort();
    abortController = new AbortController();

    try {
      showMainLoading(true);
      updateSelectionStatus(`Loading data for ${imageId}...`);

      const queryParams = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          value.forEach((v) => queryParams.append(key, v));
        } else if (value) {
          queryParams.append(key, value);
        }
      });

      const url = `/api/unified-data/${imageId}?${queryParams}`;
      const response = await fetch(url, {
        signal: abortController.signal,
      });

      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const unifiedData = await response.json();

      // Load data in parallel for better performance
      await Promise.all([
        loadVectorData(unifiedData.vector_data),
        loadChartData(unifiedData.chart_data),
        loadReportData(imageId),
        updateRasterLayers(imageId),
      ]);

      await loadFilterOptions(imageId);
      updateSelectionStatus(`Data loaded: ${imageId}`);

      if (fitToDataBtn) fitToDataBtn.disabled = false;
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load unified data:", error);
        updateSelectionStatus("Error loading data");
        if (reportContent) {
          reportContent.innerHTML =
            '<div class="error-message">Failed to load data. Please try again.</div>';
        }
        showErrorToUser("Failed to load data");
      }
    } finally {
      showMainLoading(false);
    }
  }

  async function loadVectorData(vectorData) {
    vectorSource.clear();

    if (vectorData && vectorData.features && vectorData.features.length > 0) {
      try {
        const features = new GeoJSON().readFeatures(vectorData, {
          featureProjection: "EPSG:3857",
        });
        vectorSource.addFeatures(features);

        // Fit view to features
        map.getView().fit(vectorSource.getExtent(), {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 1000,
        });

        console.log(`✅ Loaded ${features.length} vector features`);
      } catch (error) {
        console.error("Error reading vector features:", error);
        showErrorToUser("Error loading map data");
      }
    } else {
      console.log("ℹ️ No vector features found");
      // Don't change the view if no features
    }
  }

  async function loadChartData(chartData) {
    // Destroy existing chart
    if (barChart) {
      barChart.destroy();
      barChart = null;
    }

    if (!chartData || chartData.length === 0) {
      console.log("ℹ️ No chart data available");
      barCanvas.innerHTML =
        '<div class="no-data-message">No chart data available</div>';
      return;
    }

    try {
      const accessibleColors = [
        "#3366CC",
        "#DC3912",
        "#FF9900",
        "#109618",
        "#990099",
        "#0099C6",
        "#DD4477",
        "#66AA00",
        "#B82E2E",
        "#316395",
      ];

      // FIXED: Added the missing 'data' property key
      barChart = new Chart(barCanvas, {
        type: "bar",
        data: {
          // This was missing - added the 'data' property
          labels: chartData.map(
            (d) => d.target_name || d.target_class || "Unknown Target"
          ),
          datasets: [
            {
              label: "Total Count",
              data: chartData.map((d) => d.total_count), // Fixed missing data array
              backgroundColor: chartData.map(
                (d, i) => accessibleColors[i % accessibleColors.length]
              ),
              borderColor: chartData.map(
                (d, i) => accessibleColors[i % accessibleColors.length]
              ),
              borderWidth: 1,
              barThickness: 30,
              maxBarThickness: 50,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                title: function (context) {
                  const dataPoint = chartData[context[0].dataIndex];
                  return (
                    dataPoint.target_name ||
                    dataPoint.target_class ||
                    "Unknown Target"
                  );
                },
                label: function (context) {
                  const dataPoint = chartData[context.dataIndex];
                  return [
                    `Class: ${dataPoint.target_class || "N/A"}`,
                    `Type: ${dataPoint.target_type || "N/A"}`,
                    `Total Count: ${context.parsed.y}`,
                    `Avg Score: ${
                      dataPoint.avg_score
                        ? (dataPoint.avg_score * 100).toFixed(1) + "%"
                        : "N/A"
                    }`,
                  ];
                },
              },
            },
          },
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: "Total Count",
                font: { size: 12, weight: "bold" },
              },
            },
            x: {
              title: {
                display: true,
                text: "Target Name",
                font: { size: 12, weight: "bold" },
              },
            },
          },
        },
      });

      console.log("✅ Chart loaded with", chartData.length, "data points");
    } catch (error) {
      console.error("Error creating chart:", error);
      barCanvas.innerHTML =
        '<div class="error-message">Error loading chart</div>';
    }
  }

  // RASTER LAYER MANAGEMENT
  async function updateRasterLayers(imageId) {
    console.log(`🔄 Updating raster layers for: ${imageId}`);

    try {
      const xyzSource = new XYZ({
        url: `${getAssetUrl(`tiles/${imageId}/{z}/{x}/{y}.png`)}`,
        crossOrigin: "anonymous",
        transition: 250,
        minZoom: 12,
        maxZoom: 20,
      });

      xyzLayer.setSource(xyzSource);
      xyzLayer.setVisible(true);

      if (opacitySlider) {
        xyzLayer.setOpacity(parseFloat(opacitySlider.value || 1));
      }
    } catch (error) {
      console.error("Error updating raster layers:", error);
    }
  }

  // REPORT LOADING WITH ASSET SERVER FALLBACK
  async function loadReportData(imageId) {
    try {
      showReportLoading(true);
      const reportUrl = `${getAssetUrl(`reports/${imageId}.txt`)}`;
      const res = await fetch(reportUrl, {
        signal: abortController.signal,
      });

      if (!res.ok) throw new Error("Report not found");

      const reportText = await res.text();
      if (reportContent) {
        reportContent.innerHTML = await marked.parse(reportText);
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Failed to load report from asset server:", error);
        try {
          const localRes = await fetch(`/api/reports/${imageId}.txt`, {
            signal: abortController.signal,
          });
          if (localRes.ok) {
            const localReportText = await localRes.text();
            if (reportContent) {
              reportContent.innerHTML = await marked.parse(localReportText);
            }
            return;
          }
        } catch (fallbackError) {
          if (fallbackError.name !== "AbortError") {
            if (reportContent) {
              reportContent.innerHTML =
                '<div class="error-message">Report not available for this image.</div>';
            }
          }
        }
      }
    } finally {
      showReportLoading(false);
    }
  }

  function updateFilterContextDisplay() {
    const contextElement = document.querySelector(".filter-context");
    if (!contextElement) {
      const filterSection = document.querySelector(".filter-section");
      if (filterSection) {
        const newContextElement = document.createElement("div");
        newContextElement.className = "filter-context";
        filterSection.insertBefore(newContextElement, filterSection.firstChild);
      }
      return;
    }

    let contextText = "";
    if (currentSelections.country && currentSelections.targetType) {
      contextText = `Filtering: ${currentSelections.country} → ${currentSelections.targetType}`;
    } else if (currentSelections.country) {
      contextText = `Filtering: ${currentSelections.country}`;
    } else {
      contextText = "No context - showing all data";
    }

    contextElement.innerHTML = `
      <span>Context:</span>
      <span class="context-value">${escapeHtml(contextText)}</span>
    `;
  }

  // UI STATE MANAGEMENT
  function updateSelectionStatus(message) {
    if (selectionStatus) {
      selectionStatus.textContent = message;
      selectionStatus.title = message;
      selectionStatus.setAttribute("aria-live", "polite");
    }
  }

  function showLoadingState(selectorType, message) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = true;
      selector.innerHTML = `<option value="">${message}</option>`;
    }
  }

  function hideLoadingState(selectorType) {
    const selectors = {
      country: countrySelector,
      targetType: targetTypeSelector,
      imageId: imageIdSelector,
    };
    const selector = selectors[selectorType];
    if (selector) {
      selector.disabled = false;
    }
  }

  function showMainLoading(show) {
    const mapLoading = document.getElementById("mapLoading");
    const chartLoading = document.getElementById("chartLoading");
    if (mapLoading) mapLoading.style.display = show ? "flex" : "none";
    if (chartLoading) chartLoading.style.display = show ? "flex" : "none";
  }

  function showReportLoading(show) {
    const reportLoading = document.getElementById("reportLoading");
    if (reportLoading) reportLoading.style.display = show ? "flex" : "none";
  }

  function showErrorToUser(message) {
    // You could implement a toast notification system here
    console.error("User-facing error:", message);
    // Simple alert for now - consider a better UI in production
    alert(`Error: ${message}`);
  }

  function clearAllData() {
    // Cancel any ongoing requests
    abortController.abort();
    abortController = new AbortController();

    currentSelections = { country: null, targetType: null, imageId: null };
    currentFilters = {};
    countrySelector.value = "";
    targetTypeSelector.innerHTML =
      '<option value="">Select Country First</option>';
    targetTypeSelector.disabled = true;
    imageIdSelector.innerHTML =
      '<option value="">Select Target Type First</option>';
    imageIdSelector.disabled = true;
    vectorSource.clear();

    if (barChart) {
      barChart.destroy();
      barChart = null;
    }

    if (reportContent) {
      reportContent.innerHTML = `
        <div class="report-placeholder">
          <div class="placeholder-icon">📊</div>
          <p>Select a country, target type, and image ID to view the analysis report.</p>
        </div>
      `;
    }

    // Clear raster layers
    xyzLayer.setSource(null);
    cogLayer.setSource(null);

    map.getView().setCenter(fromLonLat([8.55, 50.04]));
    map.getView().setZoom(12);
    resetFilters();

    if (fitToDataBtn) fitToDataBtn.disabled = true;
    updateSelectionStatus("Ready to load data");
  }

  function getColorForClass(targetClass) {
    const colorMap = {
      "FR-AF-CGAA-1": "#3366CC",
      "FR-AP-CGSV-1": "#DC3912",
      "FR-AF-CPA-2": "#FF9900",
      "FR-AF-CCTA-3": "#109618",
      "FR-AF-CCA-4": "#990099",
      "FR-AP-CMV-2": "#0099C6",
    };
    return colorMap[targetClass] || "#666666";
  }

  // Utility function to escape HTML
  function escapeHtml(unsafe) {
    if (typeof unsafe !== "string") return unsafe;
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // EVENT HANDLERS
  countrySelector.addEventListener("change", async (e) => {
    const country = e.target.value;
    currentSelections.country = country;
    currentSelections.targetType = null;
    currentSelections.imageId = null;
    targetTypeSelector.innerHTML =
      '<option value="">Select Target Name</option>';
    targetTypeSelector.disabled = !country;
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = true;
    resetFilters();

    if (country) {
      await loadTargetTypes(country);
    } else {
      updateSelectionStatus("Select a country to continue");
    }
  });

  targetTypeSelector.addEventListener("change", async (e) => {
    const targetName = e.target.value;
    currentSelections.targetType = targetName;
    currentSelections.imageId = null;
    imageIdSelector.innerHTML = '<option value="">Select Image ID</option>';
    imageIdSelector.disabled = !targetName;
    resetFilters();

    if (targetName && currentSelections.country) {
      await loadImageIds(currentSelections.country, targetName);
    }
  });

  imageIdSelector.addEventListener("change", async (e) => {
    currentSelections.imageId = e.target.value;
    if (currentSelections.imageId) {
      await loadFilterOptions(currentSelections.imageId);
      await autoLoadData();
    }
  });

  if (scoreRange && scoreValue) {
    scoreRange.addEventListener("input", function () {
      const scorePercent = parseFloat(this.value);
      scoreValue.textContent = `${scorePercent.toFixed(1)}%`;
      clearTimeout(scoreFilterTimeout);
      scoreFilterTimeout = setTimeout(() => {
        applyDynamicScoreFilter(scorePercent);
      }, 150);
    });
  }

  if (fitToDataBtn) {
    fitToDataBtn.addEventListener("click", () => {
      if (vectorSource.getFeatures().length > 0) {
        map.getView().fit(vectorSource.getExtent(), {
          padding: [50, 50, 50, 50],
          maxZoom: 16,
          duration: 1000,
        });
      }
    });
  }

  if (clearDataBtn) {
    clearDataBtn.addEventListener("click", clearAllData);
  }

  if (opacitySlider) {
    opacitySlider.addEventListener("input", () => {
      const opacity = parseFloat(opacitySlider.value);
      cogLayer.setOpacity(opacity);
      xyzLayer.setOpacity(opacity);
    });
  }

  // Clean up on page unload
  window.addEventListener("beforeunload", () => {
    abortController.abort();
    if (barChart) {
      barChart.destroy();
    }
  });

  // INITIALIZATION
  await loadCountries();
});

{
  "name": "geospatial-frontend",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "VITE_ASSET_SERVER=http://localhost:8082 vite",
    "build": "vite build",
    "preview": "vite preview",
    "build:prod": "VITE_ASSET_SERVER=http://localhost:8082 vite build",
    "deploy:assets": "node scripts/deploy-assets.js"
  },
  "dependencies": {
    "chart.js": "^4.4.0",
    "chartjs-adapter-date-fns": "^3.0.0",
    "date-fns": "^4.1.0",
    "geotiff": "^2.1.3",
    "marked": "^12.0.0",
    "ol": "^7.4.0",
    "open-props": "^1.7.0",
    "proj4": "^2.9.0"
  },
  "devDependencies": {
    "vite": "^5.0.0"
  }
}

