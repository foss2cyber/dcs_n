# static-asset-server (Static asset server with both Traefik and NGINX configs)

```Markdown
└── 📁static-asset-server
    └── 📁assets
        └── 📁basemaps
            ├── gis_osm_natural_free_1.cpg
            ├── gis_osm_natural_free_1.dbf
            ├── gis_osm_natural_free_1.geojson
            ├── gis_osm_natural_free_1.pbf
            ├── gis_osm_natural_free_1.prj
            ├── gis_osm_natural_free_1.shp
            └── gis_osm_natural_free_1.shx
        └── 📁cogs
            ├── IX200925XPESSCX1X77G7X_gcr.tiff
            ├── IX251024XPESSCX1X77G7X_gcr.tif
            ├── IX261024XPESSCX1X77G7X_gcr.tif
            └── IX271024XPESSCX1X77G7X_gcr.tif
        └── 📁icons
            ├── favicon.ico
            └── vite.svg
        └── 📁images
        └── 📁reports
            ├── IX200925XPESSCX1X77G7X_gcr.txt
            ├── IX251024XPESSCX1X77G7X_gcr.txt
            ├── IX261024XPESSCX1X77G7X_gcr.txt
            ├── IX271024XPESSCX1X77G7X_gcr.txt
            └── IX281024XPESSCX1X77G7X_gcr.txt
        └── 📁tiles
            └── IX200925XPESSCX1X77G7X_gcr (XYZ structure)
    └── 📁nginx-1.28.0
        └── 📁auto
        └── 📁conf
            └── nginx.conf
        └── 📁contrib
        └── 📁html
        └── 📁man
        └── 📁src
        ├── CHANGES
        ├── CHANGES.ru
        ├── CODE_OF_CONDUCT.md
        ├── configure
        ├── CONTRIBUTING.md
        ├── LICENSE
        ├── nginx_signing.key
        ├── nginx-1.28.0.tar.gz.asc
        ├── README.md
        └── SECURITY.md
    └── 📁scripts
        └── deploy-assets.js
    └── traefik
        ├── CHANGELOG.md
        ├── config.yml
        ├── LICENSE.md
        ├── traefik
        └── traefik.yml
```

---

# nginx.conf
worker_processes  1;
error_log  logs/error.log;
events {
    worker_connections  1024;
}
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;

    server {
        listen       8080;
        server_name  localhost;

        location / {
            alias /home/cheekudev/mywork/static-asset-server/flask-db-vite/assets;
            autoindex on;
            add_header 'Access-Control-Allow-Origin' '*' always;
            add_header 'Access-Control-Allow-Methods' 'GET, HEAD, OPTIONS' always;
            add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range' always;
            add_header 'Access-Control-Expose-Headers' 'Content-Length,Content-Range' always;

            if ($request_method = 'OPTIONS') {
                add_header 'Access-Control-Allow-Origin' '*';
                add_header 'Access-Control-Allow-Methods' 'GET, HEAD, OPTIONS';
                add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
                add_header 'Access-Control-Max-Age' 1728000;
                add_header 'Content-Type' 'text/plain; charset=utf-8';
                add_header 'Content-Length' 0;
                return 204;
            }
        }
    }
}

// scripts/deploy-assets.js
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Windows: Use D:/geodata/assets
// Linux: Use /home/user/geodata/assets
const ASSET_BASE =
  process.platform === "win32"
    ? "F:/nginx-backend/flask-db-vite/assets"
    : "/home/cheekudev/mywork/static-asset-server/flask-db-vite/assets";

const assetDirs = [
  { source: "public/tiles", target: path.join(ASSET_BASE, "tiles") },
  { source: "public/cogs", target: path.join(ASSET_BASE, "cogs") },
  { source: "public/basemaps", target: path.join(ASSET_BASE, "basemaps") },
  { source: "public/icons", target: path.join(ASSET_BASE, "icons") },
  { source: "public/images", target: path.join(ASSET_BASE, "images") },
  { source: "reports", target: path.join(ASSET_BASE, "reports") },
];

function copyDir(source, target) {
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target, { recursive: true });
  }
  const files = fs.readdirSync(source);
  files.forEach((file) => {
    const sourcePath = path.join(source, file);
    const targetPath = path.join(target, file);
    if (fs.statSync(sourcePath).isDirectory()) {
      copyDir(sourcePath, targetPath);
    } else {
      fs.copyFileSync(sourcePath, targetPath);
      console.log(`📁 Copied: ${file}`);
    }
  });
}

console.log("🚀 Deploying assets to static server location...");
assetDirs.forEach(({ source, target }) => {
  if (fs.existsSync(source)) {
    console.log(`\n📂 Copying ${source} to ${target}`);
    copyDir(source, target);
  } else {
    console.log(`⚠️  Source directory not found: ${source}`);
  }
});
console.log("\n✅ Assets deployed!");

# traefik/config.yml
http:
  routers:
    assets:
      rule: "PathPrefix(`/`)"
      service: file-server
      middlewares:
        - cors

  middlewares:
    cors:
      headers:
        accessControlAllowOriginList: ["*"]
        accessControlAllowMethods: ["GET", "HEAD", "OPTIONS"]
        accessControlMaxAge: 1728000

  services:
    file-server:
      static:
        directory: "/home/cheekudev/mywork/static-asset-server/assets" # ← UPDATE TO YOUR ASSET PATH
        browse: true

# traefik/traefik.yml
global:
  checkNewVersion: false
  sendAnonymousUsage: false

entryPoints:
  web:
    address: ":8082"

api:
  dashboard: false

providers:
  file:
    filename: "config.yml"
    watch: true

log:
  level: INFO

