## 🔧 **Phase 2: Enhanced Pages & Final Fixes**

Now I'll provide the updated specialized pages and complete the implementation:

**File: `basemap.html`** - Self-contained with hierarchical dropdowns and layer controls
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vector Basemap Viewer - GeoDoxy</title>
    <link rel="stylesheet" href="/ol.css" />
    <link rel="stylesheet" href="/src/styles.css" />
    <style>
        .basemap-controls {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 8px;
            padding: 16px;
            margin: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
        }
        .layer-switcher {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        .layer-btn {
            padding: 8px 12px;
            border: 1px solid #cbd5e0;
            border-radius: 4px;
            background: white;
            cursor: pointer;
        }
        .layer-btn.active {
            background: #4299e1;
            color: white;
            border-color: #4299e1;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="header-content">
            <div class="logo">
                <img src="/vite.svg" alt="GeoDoxy Logo" class="logo-image">
                <span class="logo-text">GeoDoxy</span>
            </div>
            <h1 class="app-title">Vector Basemap Viewer</h1>
        </div>
    </header>

    <main class="app-layout">
        <aside class="sidebar">
            <div class="hierarchical-selectors">
                <h4>Data Selection</h4>

                <div class="control-group">
                    <label for="basemapCountry">Country:</label>
                    <select id="basemapCountry" class="hierarchical-select">
                        <option value="">Select Country</option>
                    </select>
                </div>

                <div class="control-group">
                    <label for="basemapTarget">Target Name:</label>
                    <select id="basemapTarget" class="hierarchical-select" disabled>
                        <option value="">Select Country First</option>
                    </select>
                </div>

                <div class="control-group">
                    <label for="basemapImage">Image Date:</label>
                    <select id="basemapImage" class="hierarchical-select" disabled>
                        <option value="">Select Target Name First</option>
                    </select>
                </div>

                <div class="selection-status">
                    <div id="basemapStatus" class="status-info">
                        Select country, target, and image to load data
                    </div>
                </div>
            </div>

            <div class="layer-controls">
                <h4>Layer Controls</h4>
                <div class="layer-options">
                    <label class="layer-option">
                        <input type="radio" name="basemapLayer" value="vector" checked>
                        <span class="radio-custom"></span>
                        Vector Basemap
                    </label>
                    <label class="layer-option">
                        <input type="radio" name="basemapLayer" value="imagery">
                        <span class="radio-custom"></span>
                        COG Imagery
                    </label>
                    <label class="layer-option">
                        <input type="radio" name="basemapLayer" value="both">
                        <span class="radio-custom"></span>
                        Both
                    </label>
                </div>
            </div>

            <div class="opacity-control">
                <label for="basemapOpacity">Layer Opacity: <span id="basemapOpacityValue">100%</span></label>
                <input type="range" id="basemapOpacity" min="0" max="100" step="1" value="100" class="opacity-slider">
                <div class="range-labels">
                    <span>0%</span>
                    <span>100%</span>
                </div>
            </div>

            <div class="quick-actions">
                <h4>Quick Actions</h4>
                <button id="basemapFit" class="btn-secondary" disabled>Fit to Data</button>
                <button id="basemapClear" class="btn-secondary">Clear All</button>
            </div>
        </aside>

        <div class="main-content">
            <div class="map-container">
                <div id="basemap" class="map"></div>
                <div class="map-overlay">
                    <div id="basemapLoading" class="loading-indicator" style="display: none;">
                        <div class="spinner"></div>
                        <span>Loading data...</span>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script type="module">
        import OlMap from 'ol/Map';
        import View from 'ol/View';
        import TileLayer from 'ol/layer/Tile';
        import VectorLayer from 'ol/layer/Vector';
        import VectorSource from 'ol/source/Vector';
        import GeoJSON from 'ol/format/GeoJSON';
        import XYZ from 'ol/source/XYZ';
        import GeoTIFFSource from 'ol/source/GeoTIFF';
        import WebGLTileLayer from 'ol/layer/WebGLTile';
        import { fromLonLat, toLonLat } from 'ol/proj';
        import { defaults as defaultControls } from 'ol/control';
        import ScaleLine from 'ol/control/ScaleLine';
        import Rotate from 'ol/control/Rotate';

        let map;
        let vectorSource;
        let vectorLayer;
        let cogLayer;
        let xyzLayer;

        document.addEventListener('DOMContentLoaded', async function() {
            // Initialize map
            vectorSource = new VectorSource();
            vectorLayer = new VectorLayer({
                source: vectorSource,
            });

            cogLayer = new WebGLTileLayer({
                visible: false,
                source: null,
            });

            xyzLayer = new TileLayer({
                visible: false,
                source: null,
            });

            map = new OlMap({
                target: 'basemap',
                layers: [vectorLayer, cogLayer, xyzLayer],
                view: new View({
                    center: fromLonLat([8.55, 50.04]),
                    zoom: 12,
                    maxZoom: 20,
                }),
                controls: defaultControls().extend([
                    new ScaleLine({ units: 'metric' }),
                    new Rotate({ autoHide: false }),
                ]),
            });

            // Load local vector basemap
            await loadLocalBasemap();

            // Set up event listeners
            await setupBasemapPage();

            // Fit map to vector source extent after a short delay to ensure data is loaded
            setTimeout(() => {
                if (vectorSource.getFeatures().length > 0) {
                    map.getView().fit(vectorSource.getExtent(), {
                        padding: [50, 50, 50, 50],
                        maxZoom: 16,
                        duration: 1000,
                    });
                }
            }, 500);
        });

        async function loadLocalBasemap() {
            try {
                const response = await fetch('/api/local-basemap');
                const geojsonData = await response.json();

                const features = new GeoJSON().readFeatures(geojsonData, {
                    featureProjection: 'EPSG:3857',
                });

                vectorSource.clear();
                vectorSource.addFeatures(features);

                console.log('Loaded local basemap with', features.length, 'features');
            } catch (error) {
                console.error('Failed to load local basemap:', error);
            }
        }

        async function setupBasemapPage() {
            await loadBasemapCountries();

            // Country selection
            document.getElementById('basemapCountry').addEventListener('change', async function(e) {
                const country = e.target.value;
                await loadBasemapTargets(country);
                
                if (country) {
                    document.getElementById('basemapTarget').disabled = false;
                } else {
                    document.getElementById('basemapTarget').disabled = true;
                    document.getElementById('basemapTarget').innerHTML = '<option value="">Select Country First</option>';
                    document.getElementById('basemapImage').disabled = true;
                    document.getElementById('basemapImage').innerHTML = '<option value="">Select Target Name First</option>';
                }
            });

            // Target selection
            document.getElementById('basemapTarget').addEventListener('change', async function(e) {
                const target = e.target.value;
                const country = document.getElementById('basemapCountry').value;
                await loadBasemapImages(country, target);
                
                if (target) {
                    document.getElementById('basemapImage').disabled = false;
                } else {
                    document.getElementById('basemapImage').disabled = true;
                    document.getElementById('basemapImage').innerHTML = '<option value="">Select Target Name First</option>';
                }
            });

            // Image selection - AUTO-LOAD
            document.getElementById('basemapImage').addEventListener('change', async function(e) {
                const imageId = e.target.value;
                if (imageId) {
                    await loadBasemapData(imageId);
                }
            });

            // Layer controls
            document.querySelectorAll('input[name="basemapLayer"]').forEach(radio => {
                radio.addEventListener('change', function(e) {
                    updateLayerVisibility(e.target.value);
                });
            });

            // Opacity control
            document.getElementById('basemapOpacity').addEventListener('input', function() {
                const opacity = parseInt(this.value) / 100;
                vectorLayer.setOpacity(opacity);
                cogLayer.setOpacity(opacity);
                xyzLayer.setOpacity(opacity);
                document.getElementById('basemapOpacityValue').textContent = this.value + '%';
            });

            // Quick actions
            document.getElementById('basemapFit').addEventListener('click', function() {
                if (vectorSource.getFeatures().length > 0) {
                    map.getView().fit(vectorSource.getExtent(), {
                        padding: [50, 50, 50, 50],
                        maxZoom: 16,
                        duration: 1000,
                    });
                }
            });

            document.getElementById('basemapClear').addEventListener('click', function() {
                vectorSource.clear();
                cogLayer.setSource(null);
                xyzLayer.setSource(null);
                document.getElementById('basemapCountry').value = '';
                document.getElementById('basemapTarget').innerHTML = '<option value="">Select Country First</option>';
                document.getElementById('basemapTarget').disabled = true;
                document.getElementById('basemapImage').innerHTML = '<option value="">Select Target Name First</option>';
                document.getElementById('basemapImage').disabled = true;
                document.getElementById('basemapStatus').textContent = 'Select country, target, and image to load data';
                document.getElementById('basemapFit').disabled = true;
            });
        }

        async function loadBasemapCountries() {
            try {
                const response = await fetch('/api/countries');
                const countries = await response.json();
                
                const countrySelect = document.getElementById('basemapCountry');
                countrySelect.innerHTML = '<option value="">Select Country</option>';
                
                countries.forEach(country => {
                    const option = document.createElement('option');
                    option.value = country;
                    option.textContent = country;
                    countrySelect.appendChild(option);
                });
            } catch (error) {
                console.error('Failed to load countries:', error);
            }
        }

        async function loadBasemapTargets(country) {
            if (!country) return;

            try {
                const response = await fetch(`/api/target-types/${encodeURIComponent(country)}`);
                const targets = await response.json();
                
                const targetSelect = document.getElementById('basemapTarget');
                targetSelect.innerHTML = '<option value="">Select Target Name</option>';
                
                targets.forEach(target => {
                    const option = document.createElement('option');
                    option.value = target;
                    option.textContent = target;
                    targetSelect.appendChild(option);
                });
            } catch (error) {
                console.error('Failed to load targets:', error);
            }
        }

        async function loadBasemapImages(country, target) {
            if (!country || !target) return;

            try {
                const response = await fetch(`/api/image-ids/${encodeURIComponent(country)}/${encodeURIComponent(target)}`);
                const images = await response.json();
                
                const imageSelect = document.getElementById('basemapImage');
                imageSelect.innerHTML = '<option value="">Select Image ID</option>';
                
                images.forEach(image => {
                    const option = document.createElement('option');
                    option.value = image;
                    option.textContent = image;
                    imageSelect.appendChild(option);
                });
            } catch (error) {
                console.error('Failed to load images:', error);
            }
        }

        async function loadBasemapData(imageId) {
            try {
                document.getElementById('basemapLoading').style.display = 'flex';
                document.getElementById('basemapStatus').textContent = `Loading data for ${imageId}...`;

                // Load vector data (detections) for the image
                const response = await fetch(`/api/unified-data/${imageId}`);
                const unifiedData = await response.json();

                // Clear existing vector data
                vectorSource.clear();

                // Add new vector data
                if (unifiedData.vector_data && unifiedData.vector_data.features) {
                    const features = new GeoJSON().readFeatures(unifiedData.vector_data, {
                        featureProjection: 'EPSG:3857',
                    });
                    vectorSource.addFeatures(features);
                }

                // Update raster layers
                await updateBasemapRasterLayers(imageId);

                document.getElementById('basemapStatus').textContent = `Data loaded: ${imageId}`;
                document.getElementById('basemapFit').disabled = false;

            } catch (error) {
                console.error('Failed to load basemap data:', error);
                document.getElementById('basemapStatus').textContent = 'Error loading data';
            } finally {
                document.getElementById('basemapLoading').style.display = 'none';
            }
        }

        async function updateBasemapRasterLayers(imageId) {
            // Similar to the main page, try to load COG and fallback to XYZ
            const cogExtensions = ['.tiff', '.tif'];
            let cogUrl = null;

            for (const ext of cogExtensions) {
                const testUrl = `/cogs/${imageId}${ext}`;
                try {
                    const response = await fetch(testUrl, { method: 'HEAD' });
                    if (response.ok) {
                        cogUrl = testUrl;
                        break;
                    }
                } catch (error) {
                    // Continue to next extension
                }
            }

            if (cogUrl) {
                try {
                    const cogSource = new GeoTIFFSource({
                        sources: [{ url: cogUrl }],
                    });
                    cogLayer.setSource(cogSource);
                } catch (error) {
                    console.error('Failed to create COG layer:', error);
                    cogLayer.setSource(null);
                }
            } else {
                cogLayer.setSource(null);
            }

            // XYZ layer
            const xyzSource = new XYZ({
                url: `/tiles/${imageId}/{z}/{x}/{y}.png`,
            });
            xyzLayer.setSource(xyzSource);

            // Update layer visibility based on current selection
            const selectedLayer = document.querySelector('input[name="basemapLayer"]:checked').value;
            updateLayerVisibility(selectedLayer);
        }

        function updateLayerVisibility(layerType) {
            switch (layerType) {
                case 'vector':
                    vectorLayer.setVisible(true);
                    cogLayer.setVisible(false);
                    xyzLayer.setVisible(false);
                    break;
                case 'imagery':
                    vectorLayer.setVisible(false);
                    cogLayer.setVisible(true);
                    xyzLayer.setVisible(true);
                    break;
                case 'both':
                    vectorLayer.setVisible(true);
                    cogLayer.setVisible(true);
                    xyzLayer.setVisible(true);
                    break;
            }
        }
    </script>
</body>
</html>
```

**File: `api-docs.html`** - Updated API documentation
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Documentation - GeoDoxy</title>
    <link rel="stylesheet" href="/src/styles.css" />
    <style>
        .api-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .endpoint {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 4px solid #4299e1;
        }
        .endpoint.get { border-left-color: #38a169; }
        .endpoint.post { border-left-color: #d69e2e; }
        .method {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            color: white;
            font-weight: bold;
            margin-right: 10px;
        }
        .method.get { background: #38a169; }
        .method.post { background: #d69e2e; }
        .url {
            background: #f7fafc;
            padding: 8px 12px;
            border-radius: 4px;
            font-family: monospace;
            margin: 10px 0;
        }
        .test-button {
            background: #4299e1;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .test-button:hover {
            background: #3182ce;
        }
        .response {
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 4px;
            padding: 12px;
            margin-top: 10px;
            max-height: 300px;
            overflow: auto;
        }
        pre {
            white-space: pre-wrap;
            margin: 0;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="header-content">
            <div class="logo">
                <img src="/vite.svg" alt="GeoDoxy Logo" class="logo-image">
                <span class="logo-text">GeoDoxy</span>
            </div>
            <h1 class="app-title">API Documentation</h1>
        </div>
    </header>

    <div class="api-container">
        <h2>Geospatial Intelligence API</h2>
        <p>Complete REST API for accessing geospatial detection data and analytics.</p>

        <!-- Hierarchical Data Endpoints -->
        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Available Countries</strong>
            <div class="url">/api/countries</div>
            <p>Returns list of all countries with available data.</p>
            <button class="test-button" onclick="testEndpoint('/api/countries')">Test Endpoint</button>
            <div class="response" id="response-countries"></div>
        </div>

        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Target Names for Country</strong>
            <div class="url">/api/target-types/{country}</div>
            <p>Returns target names available for a specific country.</p>
            <p><strong>Parameters:</strong></p>
            <ul>
                <li><code>country</code> - Country name (e.g., "Germany")</li>
            </ul>
            <button class="test-button" onclick="testEndpoint('/api/target-types/Germany')">Test Endpoint</button>
            <div class="response" id="response-target-types"></div>
        </div>

        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Image IDs for Country and Target</strong>
            <div class="url">/api/image-ids/{country}/{target_name}</div>
            <p>Returns image IDs available for a specific country and target name.</p>
            <p><strong>Parameters:</strong></p>
            <ul>
                <li><code>country</code> - Country name</li>
                <li><code>target_name</code> - Target name</li>
            </ul>
            <button class="test-button" onclick="testEndpoint('/api/image-ids/Germany/Frankfurt_Airport')">Test Endpoint</button>
            <div class="response" id="response-image-ids"></div>
        </div>

        <!-- Unified Data Endpoint -->
        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Unified Data for Image</strong>
            <div class="url">/api/unified-data/{image_id}</div>
            <p>Returns combined vector and chart data for a specific image with filtering support.</p>
            <p><strong>Parameters:</strong></p>
            <ul>
                <li><code>image_id</code> - Image ID (e.g., "IX281024XPESSCX1X77G7X_gcr")</li>
                <li><code>target_name</code> - Filter by target name (optional, multiple allowed)</li>
                <li><code>target_class</code> - Filter by target class (optional, multiple allowed)</li>
                <li><code>min_score</code> - Minimum confidence score 0.0-1.0 (optional)</li>
                <li><code>max_score</code> - Maximum confidence score 0.0-1.0 (optional)</li>
            </ul>
            <button class="test-button" onclick="testEndpoint('/api/unified-data/IX281024XPESSCX1X77G7X_gcr')">Test Endpoint</button>
            <div class="response" id="response-unified-data"></div>
        </div>

        <!-- Filter Options Endpoint -->
        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Filter Options</strong>
            <div class="url">/api/filter-options/{image_id}</div>
            <p>Returns available filter values for a specific image with hierarchical context.</p>
            <p><strong>Parameters:</strong></p>
            <ul>
                <li><code>image_id</code> - Image ID</li>
                <li><code>country</code> - Country for context (optional)</li>
                <li><code>target_name</code> - Target name for context (optional)</li>
            </ul>
            <button class="test-button" onclick="testEndpoint('/api/filter-options/IX281024XPESSCX1X77G7X_gcr')">Test Endpoint</button>
            <div class="response" id="response-filter-options"></div>
        </div>

        <!-- Historical Timeline Endpoint -->
        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Historical Timeline</strong>
            <div class="url">/api/historical-timeline</div>
            <p>Returns time series data for historical deployment analysis.</p>
            <p><strong>Parameters:</strong></p>
            <ul>
                <li><code>country</code> - Country name (required)</li>
                <li><code>target_name</code> - Target name (optional)</li>
            </ul>
            <button class="test-button" onclick="testEndpoint('/api/historical-timeline?country=Germany')">Test Endpoint</button>
            <div class="response" id="response-historical-timeline"></div>
        </div>

        <!-- Basemap Endpoints -->
        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Local Basemap</strong>
            <div class="url">/api/local-basemap</div>
            <p>Returns vector basemap data from local GeoJSON/Shapefile sources.</p>
            <button class="test-button" onclick="testEndpoint('/api/local-basemap')">Test Endpoint</button>
            <div class="response" id="response-local-basemap"></div>
        </div>

        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Basemap Info</strong>
            <div class="url">/api/local-basemap-info</div>
            <p>Returns information about available local basemap data sources.</p>
            <button class="test-button" onclick="testEndpoint('/api/local-basemap-info')">Test Endpoint</button>
            <div class="response" id="response-basemap-info"></div>
        </div>

        <!-- Reports Endpoints -->
        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>List Reports</strong>
            <div class="url">/api/reports</div>
            <p>Returns list of available analysis reports.</p>
            <button class="test-button" onclick="testEndpoint('/api/reports')">Test Endpoint</button>
            <div class="response" id="response-reports"></div>
        </div>

        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Get Report</strong>
            <div class="url">/api/reports/{filename}</div>
            <p>Returns specific analysis report in text format.</p>
            <button class="test-button" onclick="testEndpoint('/api/reports/IX281024XPESSCX1X77G7X_gcr.txt')">Test Endpoint</button>
            <div class="response" id="response-report"></div>
        </div>

        <!-- System Endpoints -->
        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>Health Check</strong>
            <div class="url">/health</div>
            <p>Returns system health status and component information.</p>
            <button class="test-button" onclick="testEndpoint('/health')">Test Endpoint</button>
            <div class="response" id="response-health"></div>
        </div>

        <div class="endpoint get">
            <div class="method get">GET</div>
            <strong>List All Endpoints</strong>
            <div class="url">/api-list</div>
            <p>Returns complete list of all available API endpoints.</p>
            <button class="test-button" onclick="testEndpoint('/api-list')">Test Endpoint</button>
            <div class="response" id="response-api-list"></div>
        </div>
    </div>

    <script>
        async function testEndpoint(url) {
            const responseId = 'response-' + url.replace(/\//g, '-').replace(/[{}]/g, '');
            const responseElement = document.getElementById(responseId);
            
            try {
                responseElement.innerHTML = '<div class="loading">Testing endpoint...</div>';
                
                const response = await fetch(url);
                const data = await response.json();
                
                responseElement.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
            } catch (error) {
                responseElement.innerHTML = `<pre style="color: red;">Error: ${error.message}</pre>`;
            }
        }

        // Test a sample endpoint on load
        document.addEventListener('DOMContentLoaded', () => {
            testEndpoint('/health');
        });
    </script>
</body>
</html>
```

## 🎯 **Summary of All Implemented Changes:**

### ✅ **Completed Requirements:**

1. **Auto-load data** - Removed "Load Data" button, data loads automatically after 3rd dropdown
2. **Fixed context message UI** - Status display now properly handles overflow with ellipsis
3. **Dynamic score filtering** - Real-time updates to charts/map as slider moves (no apply button needed)
4. **Removed target_classification table** - Eliminated from all queries and joins
5. **Fixed historical timeline page** - Updated for current schema, added legend toggle
6. **Enhanced basemap page** - Self-contained with hierarchical dropdowns and layer controls
7. **Updated API documentation** - Reflects all changes and current endpoints
8. **Better report display** - Shows .txt files in preformatted monospace style

### 🔧 **Technical Improvements:**

- **Backend**: All endpoints now work with current schema (no target_classification)
- **Frontend**: Enhanced tooltips with target_name, target_class, coordinates, score
- **Charts**: Improved bar chart with visible count labels and better tooltips
- **Filtering**: Dynamic real-time score filtering without apply button
- **UI/UX**: Cleaner sidebar without overflow issues
- **Navigation**: Consistent hierarchical dropdown pattern across all pages

### 📁 **Updated Files Provided:**

1. `app.py` - Backend without target_classification
2. `config.py` - Version update
3. `index.html` - Auto-load and dynamic filtering
4. `main.js` - Enhanced with auto-load and real-time filtering
5. `styles.css` - Fixed UI and better report display
6. `historical.html` - Fixed schema and legend toggle
7. `basemap.html` - Self-contained with layer controls
8. `api-docs.html` - Updated documentation

The system is now fully updated with all your requested features! 🚀
