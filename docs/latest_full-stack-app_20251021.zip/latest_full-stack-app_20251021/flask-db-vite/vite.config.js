// vite.config.js
import { defineConfig } from "vite";

export default defineConfig({
  optimizeDeps: {
    include: ["ol", "geotiff", "chart.js", "proj4"],
  },
  root: "./",
  base: "./",
  publicDir: "public",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: "index.html",
        apiDocs: "api-docs.html",
        basemap: "basemap.html",
        historical: "historical.html",
        health: "health.html",
      },
    },
  },
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:5000",
      "/reports": "http://localhost:5000",
      "/health": "http://localhost:5000",
      "/health-page": "http://localhost:5000",
      "/basemap": "http://localhost:5000",
      "/historical-deployment": "http://localhost:5000",
    },
    cors: true,
  },
  define: {
    "import.meta.env.VITE_ASSET_SERVER": JSON.stringify(
      process.env.VITE_ASSET_SERVER || "http://localhost:8082"
    ),
  },
});
