#!/bin/bash
set -e

echo "========================================"
echo " Starting GeoDoxy Development Mode (Linux)"
echo "========================================"

# Start Traefik (static assets)
echo "🚀 Starting Traefik asset server..."
cd static-asset-server/traefik
./traefik --configFile=traefik.yml &
TRAEFIK_PID=$!

# Start Flask backend
echo "🐍 Starting Flask backend..."
cd ../../
python app.py &
FLASK_PID=$!

# Start Vite dev server
echo "⚡ Starting Vite frontend..."
npm run dev &
VITE_PID=$!

# Open browser
sleep 5
xdg-open "http://localhost:5173" 2>/dev/null || echo "Open http://localhost:5173 manually"

echo ""
echo "✅ Development servers running!"
echo "  Traefik (assets): http://localhost:8082"
echo "  Flask (API): http://localhost:5000"
echo "  Vite (frontend): http://localhost:5173"
echo ""
echo "Press Ctrl+C to stop all servers"

trap "kill $TRAEFIK_PID $FLASK_PID $VITE_PID 2>/dev/null; exit" SIGINT SIGTERM
wait