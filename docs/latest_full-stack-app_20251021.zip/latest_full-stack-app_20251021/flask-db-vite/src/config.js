// src/config.js
export const CONFIG = {
  ASSET_SERVER: import.meta.env.VITE_ASSET_SERVER || "http://localhost:8082",
  API_BASE: "/api",
  TILES_BASE: "/tiles",
  COGS_BASE: "/cogs",
  REPORTS_BASE: "/reports",
  BASEMAPS_BASE: "/basemaps",
  ICONS_BASE: "/icons",
  IMAGES_BASE: "/images",
};

export function getAssetUrl(path) {
  return `${CONFIG.ASSET_SERVER}/${path}`;
}

export async function checkAssetServer() {
  try {
    const response = await fetch(CONFIG.ASSET_SERVER, { method: "HEAD" });
    return response.ok;
  } catch (error) {
    console.warn("Asset server not accessible, falling back to local assets");
    return false;
  }
}
