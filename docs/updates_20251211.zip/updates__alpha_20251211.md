> ### _A central app manager for Flask/Python apps that can be activated and launched in new browser tabs in their respective Conda envs in diiferent locations on an air-gapped Windows 10/11 Pro system with their respective real-time progress bar, console logs, & control menu UIs (Socket.io) _

```html
<!--Frontend code-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flask App Manager</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #1a2a6c, #b21f1f, #1a2a6c);
            color: #fff;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }
        h1 {
            font-size: 2.5rem;
            margin: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }
        .app-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
            max-width: 1400px;
            margin: 0 auto;
        }
        .app-card {
            background: rgba(255, 255, 255, 0.08);
            border-radius: 12px;
            padding: 25px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .app-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }
        .app-title {
            font-size: 1.4rem;
            margin-bottom: 15px;
            color: #4fc3f7;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .status {
            font-weight: bold;
            margin-bottom: 15px;
            padding: 8px 15px;
            background: rgba(79, 195, 247, 0.2);
            border-radius: 20px;
            display: inline-block;
        }
        .progress-container {
            margin: 15px 0;
        }
        .progress-bar {
            height: 12px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            overflow: hidden;
        }
        .progress {
            height: 100%;
            background: linear-gradient(90deg, #4fc3f7, #29b6f6);
            border-radius: 6px;
            transition: width 0.4s ease;
        }
        .console-log {
            height: 150px;
            overflow-y: auto;
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px;
            font-family: monospace;
            font-size: 0.9rem;
            line-height: 1.5;
            margin-top: 15px;
            color: #e0f7fa;
        }
        .console-log::-webkit-scrollbar {
            width: 6px;
        }
        .console-log::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.1);
        }
        .console-log::-webkit-scrollbar-thumb {
            background: rgba(79, 195, 247, 0.5);
            border-radius: 3px;
        }
        .controls {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
        button {
            flex: 1;
            padding: 10px 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .start-btn {
            background: linear-gradient(135deg, #4caf50, #66bb6a);
            color: white;
        }
        .start-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(76, 175, 80, 0.4);
        }
        .stop-btn {
            background: linear-gradient(135deg, #f44336, #e57373);
            color: white;
        }
        .stop-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(244, 67, 54, 0.4);
        }
        .view-btn {
            background: linear-gradient(135deg, #2196f3, #64b5f6);
            color: white;
        }
        .view-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(33, 150, 243, 0.4);
        }
        .icon {
            width: 18px;
            height: 18px;
        }
        @media (max-width: 768px) {
            .app-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Flask Application Manager</h1>
        <p>Control and monitor your Flask applications running in Conda environments</p>
    </div>
    <div class="app-container" id="app-container"></div>

    <script src="/src/index.js"></script>
    <script>
        const socket = io();

        // Fetch initial app list
        fetch('/api/apps')
            .then(response => response.json())
            .then(apps => {
                const container = document.getElementById('app-container');
                apps.forEach(app => {
                    const card = document.createElement('div');
                    card.className = 'app-card';
                    card.innerHTML = `
                        <div class="app-title">
                            <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2z"/>
                            </svg>
                            ${app.name}
                        </div>
                        <div class="status">${app.status === 'running' ? '✅ Running' : app.status === 'starting' ? '⏳ Starting' : '❌ Stopped'}</div>
                        <div class="progress-container">
                            <div class="progress-bar">
                                <div class="progress" id="progress-${app.id}" style="width: ${app.progress}%"></div>
                            </div>
                        </div>
                        <div class="console-log" id="console-${app.id}"></div>
                        <div class="controls">
                            <button class="start-btn" onclick="startApp('${app.id}')">
                                <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M8 5v14l11-7z"/>
                                </svg>
                                Start
                            </button>
                            <button class="stop-btn" onclick="stopApp('${app.id}')">
                                <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M6 6h12v12H6z"/>
                                </svg>
                                Stop
                            </button>
                            <button class="view-btn" onclick="viewLogs('${app.id}')">
                                <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14z"/>
                                </svg>
                                View Logs
                            </button>
                        </div>
                    `;
                    container.appendChild(card);
                });
            });

        // Socket.io event listeners
        socket.on('log', (data) => {
            const consoleElement = document.getElementById(`console-${data.appId}`);
            if (consoleElement) {
                consoleElement.innerHTML += `${data.message}<br>`;
                consoleElement.scrollTop = consoleElement.scrollHeight;
            }
        });

        socket.on('progress', (data) => {
            const progressElement = document.getElementById(`progress-${data.appId}`);
            if (progressElement) {
                progressElement.style.width = `${data.progress}%`;
            }
        });

        function startApp(appId) {
            fetch(`/api/apps/${appId}/start`, { method: 'POST' });
        }

        function stopApp(appId) {
            fetch(`/api/apps/${appId}/stop`, { method: 'POST' });
        }

        function viewLogs(appId) {
            // In a real implementation, this might open a dedicated log viewer
            console.log(`Viewing logs for app ${appId}`);
            // For production: window.open(`/logs/${appId}`, '_blank');
        }
    </script>
</body>
</html>
```

> ### _Now I need this to be ready in a test prod env. Give me the rest of the backend codebase and the complete setup._

---

```python
import os
import subprocess
import json
import time
from flask import Flask, request, jsonify
from flask_socketio import SocketIO, emit
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import threading
from datetime import datetime

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# Database setup
DATABASE_URL = "postgresql://postgres:password@localhost:5432/flask_manager"
engine = create_engine(DATABASE_URL)
Base = declarative_base()

class App(Base):
    __tablename__ = 'apps'
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    path = Column(String(500), nullable=False)
    conda_env = Column(String(255), nullable=False)
    status = Column(String(50), default='stopped')
    progress = Column(Integer, default=0)
    port = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

# Store running processes
running_processes = {}

@app.route('/api/apps', methods=['GET'])
def get_apps():
    apps = session.query(App).all()
    return jsonify([{
        'id': app.id,
        'name': app.name,
        'status': app.status,
        'progress': app.progress
    } for app in apps])

@app.route('/api/apps/<int:app_id>/start', methods=['POST'])
def start_app(app_id):
    app = session.query(App).get(app_id)
    if not app:
        return jsonify({'error': 'App not found'}), 404

    if app.status == 'running':
        return jsonify({'message': 'App is already running'}), 200

    conda_exe = r"C:\Anaconda3\Scripts\conda.exe"  # Adjust path as needed
    command = [conda_exe, "run", "-n", app.conda_env, "python", app.path]

    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        running_processes[app_id] = process
        app.status = 'starting'
        session.commit()

        def capture_logs():
            for line in process.stdout:
                socketio.emit('log', {'appId': app_id, 'message': line.strip()})
            process.wait()
            app.status = 'stopped' if process.returncode != 0 else 'running'
            session.commit()
            if app_id in running_processes:
                del running_processes[app_id]

        threading.Thread(target=capture_logs, daemon=True).start()
        return jsonify({'message': 'App started'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/apps/<int:app_id>/stop', methods=['POST'])
def stop_app(app_id):
    if app_id in running_processes:
        process = running_processes[app_id]
        try:
            process.terminate()
            process.wait(timeout=5)
        except:
            process.kill()
        del running_processes[app_id]
        
        app = session.query(App).get(app_id)
        app.status = 'stopped'
        session.commit()
        return jsonify({'message': 'App stopped'})
    return jsonify({'error': 'App not running'}), 400

# SocketIO events
@socketio.on('connect')
def handle_connect():
    print('Client connected')

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
```

**Complete Setup Instructions for Air-Gapped Windows System:**

1. **Database Setup:**
   - Install PostgreSQL locally (pre-downloaded installer)
   - Create database: `createdb -U postgres flask_manager`
   - Create user: `CREATE USER postgres WITH PASSWORD 'password';`
   - Grant privileges: `GRANT ALL PRIVILEGES ON DATABASE flask_manager TO postgres;`

2. **Backend Dependencies:**
   ```powershell
   pip install flask flask-socketio eventlet sqlalchemy psycopg2-binary
   ```

3. **Backend Service:**
   - Save code as `C:\backend\app.py`
   - Create service: 
     ```powershell
     sc create FlaskManager binPath= "C:\Python39\python.exe C:\backend\app.py" start= auto
     sc start FlaskManager
     ```

4. **NGINX Configuration (Z:\nginx\conf\nginx.conf):**
   ```nginx
   events {}
   http {
       server {
           listen 80;
           server_name localhost;
           
           location / {
               root Z:/static/frontend;
               try_files $uri $uri/ /index.html;
           }
           
           location /api/ {
               proxy_pass http://localhost:5000;
               proxy_set_header Host $host;
               proxy_set_header X-Real-IP $remote_addr;
               proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
               proxy_set_header X-Forwarded-Proto $scheme;
           }
           
           location /socket.io/ {
               proxy_pass http://localhost:5000;
               proxy_http_version 1.1;
               proxy_set_header Upgrade $http_upgrade;
               proxy_set_header Connection "upgrade";
               proxy_set_header Host $host;
           }
       }
   }
   ```

5. **Frontend Setup:**
   - Place provided HTML file at `Z:\static\frontend\index.html`
   - Ensure NGINX service is running

6. **Sample App Registration:**
   ```python
   # Run in Python shell
   from app import session, App
   app = App(
       name="My Flask App",
       path="C:\\apps\\myapp\\main.py",
       conda_env="myenv",
       port=5001
   )
   session.add(app)
   session.commit()
   ```

7. **Traefik Configuration (if needed):**
   ```toml
   [http.routers]
     [http.routers.flask-api]
       rule = "Host(`localhost`) && PathPrefix(`/api`)"
       service = "flask-service"
   
   [http.services]
     [http.services.flask-service.loadBalancer]
       [[http.services.flask-service.loadBalancer.servers]]
         url = "http://localhost:5000"
   ```

**Critical Notes for Air-Gapped Environment:**
- All dependencies must be pre-downloaded (PostgreSQL installer, Python packages, NGINX)
- Conda path must match actual installation location (check via `where conda` in cmd)
- Firewall rules must allow localhost traffic on ports 80, 5000
- NGINX and Traefik services must run as SYSTEM account with proper permissions
- For Windows services, use `nssm` to wrap Python processes for reliable startup

**Security Considerations:**
- Use Windows credentials for PostgreSQL instead of plain password
- Restrict NGINX to only allow localhost connections
- Disable unnecessary Flask debug mode in production
- Regularly audit process permissions for Conda environments
- Isolate backend service using Windows Firewall rules
