# app.py - Include target_type from target table
import os
import re
import json
import datetime
import logging
from flask import Flask, jsonify, request, send_file, send_from_directory
import psycopg2
from psycopg2.extras import RealDictCursor
from config import Config

app = Flask(__name__,
    static_folder='public',
    static_url_path=''
)
app.config.from_object(Config)
os.makedirs(app.config['REPORTS_DIR'], exist_ok=True)

def get_db():
    return psycopg2.connect(
        dsn=app.config['DB_URL'],
        cursor_factory=RealDictCursor
    )

# ==================== HIERARCHICAL DROPDOWN ENDPOINTS ====================

@app.route('/api/countries')
def get_countries():
    """Get distinct countries available in the database"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT country_name 
                    FROM comprehensive_query 
                    WHERE country_name IS NOT NULL 
                    ORDER BY country_name
                """)
                countries = [row['country_name'] for row in cur.fetchall()]
                
                if not countries:
                    cur.execute("""
                        SELECT DISTINCT country_name 
                        FROM target 
                        WHERE country_name IS NOT NULL 
                        ORDER BY country_name
                    """)
                    countries = [row['country_name'] for row in cur.fetchall()]
                
        return jsonify(countries)
        
    except Exception as e:
        app.logger.error(f"Countries query failed: {e}")
        return jsonify([])

@app.route('/api/target-types/<country>')
def get_target_types(country):
    """Get distinct target NAMES for a specific country"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.target_name 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name IS NOT NULL 
                    ORDER BY sq.target_name
                """, (country,))
                target_names = [row['target_name'] for row in cur.fetchall()]
                
        return jsonify(target_names)
        
    except Exception as e:
        app.logger.error(f"Target names query failed for {country}: {e}")
        return jsonify([])

@app.route('/api/image-ids/<country>/<target_name>')
def get_image_ids(country, target_name):
    """Get distinct image IDs for a specific country and target NAME"""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT DISTINCT sq.image_id 
                    FROM sql_scat_query2 sq
                    WHERE sq.country_name = %s 
                    AND sq.target_name = %s 
                    AND sq.image_id IS NOT NULL 
                    ORDER BY sq.image_id
                """, (country, target_name))
                image_ids = [row['image_id'] for row in cur.fetchall()]
                
        return jsonify(image_ids)
        
    except Exception as e:
        app.logger.error(f"Image IDs query failed for {country}/{target_name}: {e}")
        return jsonify([])

# ==================== UNIFIED FILTERING ENDPOINT ====================

@app.route('/api/unified-data/<image_id>')
def get_unified_data(image_id):
    """Unified endpoint with target_type from target table"""
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    
    target_names = request.args.getlist('target_name')
    target_classes = request.args.getlist('target_class')
    min_score = request.args.get('min_score', 0.0, type=float)
    max_score = request.args.get('max_score', 1.0, type=float)
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # VECTOR DATA - Include target_type from target table
                vector_query = """
                    SELECT 
                        sq.target_name,
                        sq.country_name,
                        sq.image_id, 
                        sq.image_date,
                        sq.target_class,
                        sq.score,
                        sq.st_x as centroid_lon,
                        sq.st_y as centroid_lat,
                        t.target_type
                    FROM sql_scat_query2 sq
                    LEFT JOIN target t ON sq.target_name = t.target_name
                    WHERE sq.image_id = %s
                """
                vector_params = [image_id]
                vector_conditions = []
                
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    vector_conditions.append(f"sq.target_name IN ({placeholders})")
                    vector_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    vector_conditions.append(f"sq.target_class IN ({placeholders})")
                    vector_params.extend(target_classes)
                    
                if min_score > 0:
                    vector_conditions.append("sq.score >= %s")
                    vector_params.append(min_score)
                    
                if max_score < 1.0:
                    vector_conditions.append("sq.score <= %s")
                    vector_params.append(max_score)
                
                if vector_conditions:
                    vector_query += " AND " + " AND ".join(vector_conditions)
                
                cur.execute(vector_query, vector_params)
                vector_rows = cur.fetchall()
                
                # Format vector features
                vector_features = []
                for row in vector_rows:
                    geometry_data = {
                        "type": "Polygon",
                        "coordinates": [[
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] - 0.001],
                            [row["centroid_lon"] + 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] + 0.001],
                            [row["centroid_lon"] - 0.001, row["centroid_lat"] - 0.001]
                        ]]
                    }
                    
                    vector_features.append({
                        "type": "Feature",
                        "geometry": geometry_data,
                        "properties": {
                            "id": f"{row['image_id']}_{row['target_class']}",
                            "target_class": row["target_class"],
                            "target_name": row["target_name"],
                            "target_type": row["target_type"],
                            "country_name": row["country_name"],
                            "score": float(row["score"]) if row["score"] is not None else None,
                            "centroid": [float(row["centroid_lon"]), float(row["centroid_lat"])]
                        }
                    })
                
                # CHART DATA - Include target_type from target table
                chart_query = """
                    SELECT 
                        cq.target_name,
                        cq.target_class, 
                        cq.total_count,
                        cq.score as avg_score,
                        t.target_type
                    FROM comprehensive_query cq
                    LEFT JOIN target t ON cq.target_name = t.target_name
                    WHERE cq.image_id = %s
                """
                chart_params = [image_id]
                chart_conditions = []
                
                if target_names:
                    placeholders = ','.join(['%s'] * len(target_names))
                    chart_conditions.append(f"cq.target_name IN ({placeholders})")
                    chart_params.extend(target_names)
                elif target_classes:
                    placeholders = ','.join(['%s'] * len(target_classes))
                    chart_conditions.append(f"cq.target_class IN ({placeholders})")
                    chart_params.extend(target_classes)
                    
                if min_score > 0:
                    chart_conditions.append("cq.score >= %s")
                    chart_params.append(min_score)
                    
                if max_score < 1.0:
                    chart_conditions.append("cq.score <= %s")
                    chart_params.append(max_score)
                
                if chart_conditions:
                    chart_query += " AND " + " AND ".join(chart_conditions)
                
                chart_query += " ORDER BY cq.total_count DESC"
                
                cur.execute(chart_query, chart_params)
                chart_rows = cur.fetchall()
                
                chart_data = [
                    {
                        'target_name': row['target_name'],
                        'target_class': row['target_class'],
                        'target_type': row['target_type'],
                        'total_count': row['total_count'],
                        'avg_score': float(row['avg_score']) if row['avg_score'] is not None else 0.0
                    }
                    for row in chart_rows
                ]
        
        return jsonify({
            "vector_data": {
                "type": "FeatureCollection", 
                "features": vector_features
            },
            "chart_data": chart_data
        })
        
    except Exception as e:
        app.logger.error(f"Unified data query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to retrieve unified data"}), 500

@app.route('/api/filter-options/<image_id>')
def get_filter_options(image_id):
    """Get available filter values with hierarchical context"""
    country = request.args.get('country')
    target_name = request.args.get('target_name')
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                # Get target names based on current hierarchy
                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                        ORDER BY sq.target_name
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_name 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                        ORDER BY sq.target_name
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_name
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s 
                        ORDER BY sq.target_name
                    """, (image_id,))
                
                names_result = cur.fetchall()
                target_names = [row['target_name'] for row in names_result if row['target_name']]
                
                # Get target classes with the same hierarchical context
                if country and target_name:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                        ORDER BY sq.target_class
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                        ORDER BY sq.target_class
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT DISTINCT sq.target_class 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s 
                        ORDER BY sq.target_class
                    """, (image_id,))
                
                classes = [row['target_class'] for row in cur.fetchall()]
                
                # Get score range with the same hierarchical context
                if country and target_name:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s AND sq.target_name = %s
                    """
                    cur.execute(query, (image_id, country, target_name))
                elif country:
                    query = """
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s AND sq.country_name = %s
                    """
                    cur.execute(query, (image_id, country))
                else:
                    cur.execute("""
                        SELECT MIN(sq.score) as min_score, MAX(sq.score) as max_score 
                        FROM sql_scat_query2 sq
                        WHERE sq.image_id = %s
                    """, (image_id,))
                
                score_result = cur.fetchone()
                
        return jsonify({
            'target_names': target_names or [],
            'target_classes': classes or [],
            'score_range': {
                'min': float(score_result['min_score']) if score_result and score_result['min_score'] is not None else 0.0,
                'max': float(score_result['max_score']) if score_result and score_result['max_score'] is not None else 1.0
            }
        })
        
    except Exception as e:
        app.logger.error(f"Filter options query failed for {image_id}: {e}")
        return jsonify({
            'target_names': [],
            'target_classes': [],
            'score_range': {'min': 0.0, 'max': 1.0}
        })

# ==================== SIMPLE LOCAL BASEMAP ENDPOINT ====================

@app.route('/api/local-basemap')
def get_local_basemap():
    """Simple local basemap data - serves fallback data"""
    try:
        # Always return simple fallback data for now
        return get_simple_fallback_basemap()
    except Exception as e:
        app.logger.error(f"Failed to load local basemap: {e}")
        return get_simple_fallback_basemap()

def get_simple_fallback_basemap():
    """Simple fallback basemap data"""
    simple_geojson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [8.0, 49.5], [9.0, 49.5], [9.0, 50.5], [8.0, 50.5], [8.0, 49.5]
                    ]]
                },
                "properties": {
                    "name": "Sample Region",
                    "type": "administrative"
                }
            }
        ]
    }
    return jsonify(simple_geojson)

# ==================== HEALTH CHECK =====================
@app.route('/health')
def health_check():
    health_status = {
        'status': 'healthy',
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'version': '1.0.0'
    }
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT 1')
        health_status['database'] = 'connected'
    except Exception as e:
        health_status['database'] = 'disconnected'
        health_status['status'] = 'unhealthy'
        health_status['database_error'] = str(e)

    return jsonify(health_status), 200 if health_status['status'] == 'healthy' else 503

# ==================== EXISTING ENDPOINTS ====================

@app.route('/api/data/<image_id>')
def get_geospatial_data(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
    
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        f.id,
                        f.target_class,
                        f.score,
                        ST_AsGeoJSON(f.target_geom) AS geometry,
                        ST_X(ST_Centroid(f.target_geom)) AS centroid_lon,
                        ST_Y(ST_Centroid(f.target_geom)) AS centroid_lat
                    FROM findings f
                    WHERE f.image_id = %s
                """, (image_id,))
                rows = cur.fetchall()

        if not rows:
            return jsonify({
                "type": "FeatureCollection",
                "features": []
            })

        features = []
        for row in rows:
            if row["geometry"]:
                geometry_data = json.loads(row["geometry"])
            else:
                geometry_data = {
                    "type": "Point", 
                    "coordinates": [
                        row["centroid_lon"] or 8.55, 
                        row["centroid_lat"] or 50.04
                    ]
                }
            
            features.append({
                "type": "Feature",
                "geometry": geometry_data,
                "properties": {
                    "id": row["id"],
                    "target_class": row["target_class"],
                    "score": float(row["score"]) if row["score"] is not None else None,
                    "centroid": [
                        float(row["centroid_lon"]) if row["centroid_lon"] is not None else 8.55,
                        float(row["centroid_lat"]) if row["centroid_lat"] is not None else 50.04
                    ]
                }
            })

        return jsonify({
            "type": "FeatureCollection",
            "features": features
        })
    except Exception as e:
        app.logger.error(f"Failed to fetch data for image_id={image_id}: {e}")
        return jsonify({"error": "Failed to retrieve geospatial data"}), 500

@app.route('/api/charts/<image_id>/target_class')
def get_target_class_counts(image_id):
    if not re.match(r'^IX[a-zA-Z0-9_]+$', image_id):
        return jsonify({"error": "Invalid image ID format"}), 400
        
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        target_class,
                        total_count
                    FROM comprehensive_query
                    WHERE image_id = %s
                """, (image_id,))
                rows = cur.fetchall()
                
        if not rows:
            return jsonify([])

        return jsonify([
            {
                "label": r["target_class"],
                "value": r["total_count"]
            }
            for r in rows
        ])
    except Exception as e:
        app.logger.error(f"Chart query failed for {image_id}: {e}")
        return jsonify({"error": "Failed to generate chart data"}), 500

@app.route('/api/reports')
def list_reports():
    try:
        files = [f for f in os.listdir(app.config['REPORTS_DIR']) if f.endswith('.txt')]
        return jsonify(sorted(files))
    except Exception as e:
        app.logger.error(f"Failed to list reports: {e}")
        return jsonify({"error": "Cannot list reports"}), 500

@app.route('/api/reports/<filename>')
def get_report(filename):
    if not filename.endswith('.txt'):
        return jsonify({"error": "Only .txt reports are allowed"}), 400
    try:
        return send_from_directory(app.config['REPORTS_DIR'], filename, mimetype='text/plain')
    except FileNotFoundError:
        return jsonify({"error": "Report not found"}), 404

# ==================== PAGE ROUTES ====================

@app.route('/api')
def api_documentation_page():
    return send_from_directory('.', 'api-docs.html')

@app.route('/health-page')
def health_page():
    return send_from_directory('.', 'health.html')

@app.route('/basemap')
def basemap_page():
    return send_from_directory('.', 'basemap.html')

@app.route('/historical-deployment')  
def historical_deployment_page():
    return send_from_directory('.', 'historical.html')

@app.route('/assets/<path:filename>')
def serve_assets(filename):
    return send_from_directory('dist/assets', filename)

@app.route('/cogs/<filename>')
def serve_cog(filename):
    if not filename.endswith(('.tiff', '.tif')):
        return jsonify({"error": "Invalid file type"}), 400
    return send_from_directory('public/cogs', filename, mimetype='image/tiff')

@app.route('/')
@app.route('/<path:path>')
def serve_frontend(path='index.html'):
    if os.path.exists(f"dist/{path}"):
        return send_from_directory('dist', path)
    else:
        return send_from_directory('dist', 'index.html')

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    app.run(host='127.0.0.1', port=5000, debug=True)
