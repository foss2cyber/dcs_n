# convert_shp_to_geojson.py
import geopandas as gpd
import os
import json

def convert_shp_to_geojson(shp_path, output_dir='public/basemaps/'):
    """Convert Shapefile to GeoJSON for web use"""
    try:
        print(f"📁 Converting {shp_path} to GeoJSON...")
        
        # Read Shapefile
        gdf = gpd.read_file(shp_path)
        
        # Get filename without extension
        base_name = os.path.splitext(os.path.basename(shp_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}.geojson")
        
        # Convert to GeoJSON
        gdf.to_file(output_path, driver='GeoJSON')
        
        print(f"✅ Successfully converted to: {output_path}")
        print(f"📊 Features: {len(gdf)}, CRS: {gdf.crs}")
        
        return output_path
        
    except Exception as e:
        print(f"❌ Error converting {shp_path}: {e}")
        return None

if __name__ == "__main__":
    # Example usage
    shp_file = "public/basemaps/gis_osm_natural_free_1.shp"  # Update with your actual file
    convert_shp_to_geojson(shp_file)