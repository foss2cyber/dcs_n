# setup_database.py
import psycopg2
import sys

def setup_database():
    """Complete database setup with all tables"""
    try:
        conn = psycopg2.connect("postgresql://postgres:postgres@localhost:5432/postgres")
        conn.autocommit = True
        cur = conn.cursor()
        
        print("🔧 Setting up complete database...")
        
        # Read and execute init_db.sql
        with open('init_db.sql', 'r') as f:
            sql_commands = f.read()
            cur.execute(sql_commands)
        print("✅ Database schema created")
        
        # Read and execute sample_data.sql  
        with open('sample_data.sql', 'r') as f:
            sql_commands = f.read()
            cur.execute(sql_commands)
        print("✅ Sample data inserted")
        
        # Verify the setup
        cur.execute("""
            SELECT 'findings' AS table_name, COUNT(*) AS row_count FROM findings
            UNION ALL SELECT 'target', COUNT(*) FROM target
            UNION ALL SELECT 'comprehensive_query', COUNT(*) FROM comprehensive_query  
            UNION ALL SELECT 'sql_scat_query2', COUNT(*) FROM sql_scat_query2
            UNION ALL SELECT 'target_classification', COUNT(*) FROM target_classification
        """)
        
        print("\n📊 Database Verification:")
        for row in cur.fetchall():
            print(f"   ✅ {row[0]}: {row[1]} rows")
        
        print("\n🎉 Database setup completed successfully!")
        print("   - All tables created (including sql_scat_query2)")
        print("   - Target classifications added")
        print("   - Sample data with Frankfurt_Airport names inserted")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

if __name__ == '__main__':
    setup_database()