// historical.js - Enhanced with hierarchical filtering
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

let timelineChart;
let currentSelections = {
  country: null,
  targetType: null,
  targetName: null,
};

document.addEventListener("DOMContentLoaded", async () => {
  console.log("📊 Enhanced Historical Page Loaded");

  // ==================== DOM ELEMENTS ====================
  const countrySelector = document.getElementById("countrySelector");
  const targetTypeSelector = document.getElementById("targetTypeSelector");
  const targetNameSelector = document.getElementById("targetNameSelector");
  const generateTimelineBtn = document.getElementById("generateTimeline");
  const timelineCtx = document.getElementById("timelineChart").getContext("2d");
  const chartLoading = document.getElementById("chartLoading");

  // ==================== HIERARCHICAL DROPDOWN SYSTEM ====================

  async function loadCountries() {
    try {
      console.log("🌍 Loading countries for historical analysis...");
      const response = await fetch("/api/countries");
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const countries = await response.json();
      console.log("🌍 Countries loaded:", countries);

      countrySelector.innerHTML = '<option value="">Select Country</option>';
      countries.forEach((country) => {
        const option = document.createElement("option");
        option.value = country;
        option.textContent = country;
        countrySelector.appendChild(option);
      });
    } catch (error) {
      console.error("Failed to load countries:", error);
      countrySelector.innerHTML =
        '<option value="">Error loading countries</option>';
    }
  }

  async function loadTargetTypes(country) {
    if (!country) return;

    try {
      console.log(`🎯 Loading target types for country: ${country}`);
      targetTypeSelector.disabled = true;
      targetNameSelector.disabled = true;

      const response = await fetch(
        `/api/target-types/${encodeURIComponent(country)}`
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const targetNames = await response.json();
      console.log(`🎯 Target names loaded:`, targetNames);

      // Extract unique target types from target names
      const targetTypes = [
        ...new Set(
          targetNames.map((name) => {
            if (name.includes("Airport")) return "airport";
            if (name.includes("Airfield")) return "airfield";
            if (name.includes("Helipad")) return "helipad";
            if (name.includes("Service")) return "service";
            return "other";
          })
        ),
      ].filter((type) => type); // Remove any undefined values

      targetTypeSelector.innerHTML = '<option value="">All Types</option>';
      targetTypes.forEach((type) => {
        const option = document.createElement("option");
        option.value = type;
        option.textContent = type.charAt(0).toUpperCase() + type.slice(1);
        targetTypeSelector.appendChild(option);
      });
      targetTypeSelector.disabled = false;

      // Reset target name selector
      targetNameSelector.innerHTML = '<option value="">All Targets</option>';
      targetNameSelector.disabled = false;

      console.log(`🎯 Target types extracted:`, targetTypes);
    } catch (error) {
      console.error("Failed to load target types:", error);
      targetTypeSelector.innerHTML =
        '<option value="">Error loading types</option>';
    }
  }

  async function loadTargetNames(country, targetType) {
    if (!country) return;

    try {
      console.log(
        `🎯 Loading target names for ${country}, type: ${targetType}`
      );
      targetNameSelector.disabled = true;

      const response = await fetch(
        `/api/target-types/${encodeURIComponent(country)}`
      );
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      let targetNames = await response.json();
      console.log(`🎯 All target names:`, targetNames);

      // Filter by target type if selected
      if (targetType && targetType !== "All Types") {
        targetNames = targetNames.filter((name) => {
          if (targetType === "airport") return name.includes("Airport");
          if (targetType === "airfield") return name.includes("Airfield");
          if (targetType === "helipad") return name.includes("Helipad");
          if (targetType === "service") return name.includes("Service");
          return true; // For 'other' or no filter
        });
      }

      targetNameSelector.innerHTML = '<option value="">All Targets</option>';
      targetNames.forEach((name) => {
        const option = document.createElement("option");
        option.value = name;
        option.textContent = name;
        targetNameSelector.appendChild(option);
      });
      targetNameSelector.disabled = false;

      console.log(`🎯 Filtered target names:`, targetNames);
    } catch (error) {
      console.error("Failed to load target names:", error);
      targetNameSelector.innerHTML =
        '<option value="">Error loading names</option>';
    }
  }

  // ==================== TIMELINE CHART ====================

  function initializeTimelineChart() {
    console.log("📈 Initializing timeline chart...");
    timelineChart = new Chart(timelineCtx, {
      type: "line",
      data: {
        datasets: [],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: "Target Deployments Over Time",
            font: {
              size: 16,
              weight: "bold",
            },
          },
          legend: {
            position: "top",
            labels: {
              font: {
                family: "var(--font-neo-grotesque)",
              },
            },
          },
          tooltip: {
            mode: "index",
            intersect: false,
            callbacks: {
              title: function (context) {
                const date = new Date(context[0].parsed.x);
                return date.toLocaleDateString();
              },
              label: function (context) {
                return `${context.dataset.label}: ${context.parsed.y} detections`;
              },
            },
          },
        },
        scales: {
          x: {
            type: "time",
            time: {
              unit: "month",
              displayFormats: {
                month: "MMM YYYY",
              },
            },
            title: {
              display: true,
              text: "Date",
              font: {
                family: "var(--font-neo-grotesque)",
                weight: "bold",
              },
            },
            grid: {
              color: "rgba(0, 0, 0, 0.1)",
            },
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Detection Count",
              font: {
                family: "var(--font-neo-grotesque)",
                weight: "bold",
              },
            },
            grid: {
              color: "rgba(0, 0, 0, 0.1)",
            },
          },
        },
        interaction: {
          mode: "nearest",
          axis: "x",
          intersect: false,
        },
        elements: {
          line: {
            tension: 0.4,
          },
          point: {
            radius: 4,
            hoverRadius: 6,
          },
        },
      },
    });
    console.log("✅ Timeline chart initialized");
  }

  async function generateTimeline() {
    const country = countrySelector.value;
    const targetType = targetTypeSelector.value;
    const targetName = targetNameSelector.value;

    if (!country) {
      alert("Please select a country first");
      return;
    }

    try {
      console.log("🔄 Generating timeline with filters:", {
        country,
        targetType,
        targetName,
      });
      showChartLoading(true);

      // Build query parameters
      const params = new URLSearchParams();
      params.append("country", country);
      if (targetType && targetType !== "All Types")
        params.append("target_type", targetType);
      if (targetName && targetName !== "All Targets")
        params.append("target_name", targetName);

      const response = await fetch(`/api/historical-timeline?${params}`);
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);

      const timelineData = await response.json();
      console.log("📊 Timeline data received:", timelineData);

      updateTimelineChart(timelineData);
      updateStatistics(timelineData);
    } catch (error) {
      console.error("Failed to generate timeline:", error);
      showError("Failed to load timeline data. Please try again.");
    } finally {
      showChartLoading(false);
    }
  }

  function updateTimelineChart(timelineData) {
    if (!timelineChart) {
      console.error("Timeline chart not initialized");
      return;
    }

    if (!timelineData || timelineData.length === 0) {
      console.log("No timeline data available");
      timelineChart.data.datasets = [];
      timelineChart.update();
      return;
    }

    // Prepare datasets for chart
    const datasets = [];
    const colors = [
      "#3366CC",
      "#DC3912",
      "#FF9900",
      "#109618",
      "#990099",
      "#0099C6",
      "#DD4477",
      "#66AA00",
      "#B82E2E",
      "#316395",
      "#994499",
      "#22AA99",
    ];

    timelineData.forEach((item, index) => {
      if (!item.data_points || item.data_points.length === 0) return;

      // Sort data points by date
      const sortedData = item.data_points
        .filter((point) => point.date && point.count)
        .sort((a, b) => new Date(a.date) - new Date(b.date));

      if (sortedData.length === 0) return;

      datasets.push({
        label: item.target_name,
        data: sortedData.map((point) => ({
          x: point.date,
          y: point.count,
        })),
        borderColor: colors[index % colors.length],
        backgroundColor: colors[index % colors.length] + "20",
        tension: 0.4,
        fill: false,
        borderWidth: 2,
      });
    });

    timelineChart.data.datasets = datasets;
    timelineChart.update();

    console.log(`✅ Updated chart with ${datasets.length} datasets`);
  }

  function updateStatistics(timelineData) {
    if (!timelineData || timelineData.length === 0) {
      document.getElementById("totalDetections").textContent = "0";
      document.getElementById("uniqueTargets").textContent = "0";
      document.getElementById("avgPerTarget").textContent = "0";
      document.getElementById("peakDay").textContent = "-";
      return;
    }

    let totalDetections = 0;
    let peakCount = 0;
    let peakDate = "";
    const uniqueTargets = new Set();

    timelineData.forEach((item) => {
      uniqueTargets.add(item.target_name);
      item.data_points.forEach((point) => {
        totalDetections += point.count || 0;
        if (point.count > peakCount) {
          peakCount = point.count;
          peakDate = point.date;
        }
      });
    });

    document.getElementById("totalDetections").textContent =
      totalDetections.toLocaleString();
    document.getElementById("uniqueTargets").textContent = uniqueTargets.size;

    // Calculate average per target
    const avgPerTarget =
      uniqueTargets.size > 0
        ? (totalDetections / uniqueTargets.size).toFixed(1)
        : 0;
    document.getElementById("avgPerTarget").textContent = avgPerTarget;

    // Format peak date
    document.getElementById("peakDay").textContent = peakDate
      ? new Date(peakDate).toLocaleDateString()
      : "-";

    console.log("📊 Statistics updated:", {
      totalDetections,
      uniqueTargets: uniqueTargets.size,
      avgPerTarget,
      peakDate,
    });
  }

  function showChartLoading(show) {
    if (chartLoading) {
      chartLoading.style.display = show ? "flex" : "none";
    }
  }

  function showError(message) {
    // Remove any existing error messages
    const existingError = document.querySelector(".error-message");
    if (existingError) {
      existingError.remove();
    }

    const errorElement = document.createElement("div");
    errorElement.className = "error-message";
    errorElement.textContent = message;

    const chartContainer = document.querySelector(".chart-container");
    if (chartContainer) {
      chartContainer.appendChild(errorElement);
    }
  }

  function updateGenerateButtonState() {
    const hasCountry = !!countrySelector.value;
    generateTimelineBtn.disabled = !hasCountry;
  }

  // ==================== EVENT HANDLERS ====================

  countrySelector.addEventListener("change", async (e) => {
    currentSelections.country = e.target.value;
    currentSelections.targetType = null;
    currentSelections.targetName = null;

    targetTypeSelector.innerHTML = '<option value="">Select Type</option>';
    targetTypeSelector.disabled = !currentSelections.country;
    targetNameSelector.innerHTML = '<option value="">Select Name</option>';
    targetNameSelector.disabled = true;

    if (currentSelections.country) {
      await loadTargetTypes(currentSelections.country);
    }
    updateGenerateButtonState();
  });

  targetTypeSelector.addEventListener("change", async (e) => {
    currentSelections.targetType = e.target.value;
    currentSelections.targetName = null;

    targetNameSelector.innerHTML = '<option value="">Select Name</option>';
    targetNameSelector.disabled = !currentSelections.targetType;

    if (currentSelections.targetType && currentSelections.country) {
      await loadTargetNames(
        currentSelections.country,
        currentSelections.targetType
      );
    }
  });

  targetNameSelector.addEventListener("change", (e) => {
    currentSelections.targetName = e.target.value;
  });

  generateTimelineBtn.addEventListener("click", generateTimeline);

  // ==================== INITIALIZATION ====================
  console.log("🚀 Initializing historical page...");
  initializeTimelineChart();
  await loadCountries();
  updateGenerateButtonState();
  console.log("✅ Historical page initialized successfully");
});
