Manually installing Node.js packages offline requires first downloading them as a tarball on a machine with internet access and then using npm install on the offline machine to install from the local file. 
Method 1: Using npm pack
This method is suitable for single packages and creates a compressed tarball (.tgz) that includes all the package's code. 
On the online machine
Navigate to a temporary directory in your terminal.
Run the following command to download the package into a tarball file:
npm pack <package-name>
For example: npm pack express.
Transfer the resulting .tgz file (e.g., express-4.18.2.tgz) to your offline machine using a USB drive or other offline method. 
On the offline machine
Navigate to your project directory.
Run the following command to install from the local tarball:
npm install /path/to/express-4.18.2.tgz. 
Method 2: For projects with multiple dependencies
If your project uses a package.json file with many dependencies, you can bundle them all at once into a single tarball. 
On the online machine
Inside your project directory, ensure all your dependencies are listed in the dependencies array of your package.json.
Add a bundledDependencies array to your package.json and list all the packages you need for the offline machine.
json
"bundledDependencies": [
  "express",
  "lodash"
]


Install all the dependencies so they are present in your node_modules folder:
npm install.
Create the tarball with all bundled dependencies:
npm pack.
Transfer the resulting project tarball (.tgz) to your offline machine. 
On the offline machine
Transfer the .tgz file to your offline machine.
Navigate to the directory where you want to install the project.
Use the following command to install the project and its bundled dependencies:
Method 3: Using a local npm cache
This method involves copying the entire npm cache from an online machine to an offline one. This can be less reliable than the tarball method since the cache is not guaranteed to be complete or valid. 
On the online machine
Clear the npm cache:
npm cache clean --force
Install the package you need to ensure it's in the cache:
npm install -g <package-name>.
Locate the npm cache folder by running npm config get cache.
Copy the entire cache folder to your offline machine. 
On the offline machine
Run the following command to install the package, pointing to the local cache:
npm install --cache /path/to/copied-cache <package-name>. 
Method 4: Offline installation with Yarn
For Yarn users, the Offline Mirror feature provides a robust way to handle offline installations by caching packages locally. 
On the online machine
Set the offline mirror directory:
yarn config set yarn-offline-mirror ./yarn-offline-mirror.
Add your dependencies and install them, which will populate the offline mirror:
yarn add <package-name>.
Copy the yarn.lock file and the yarn-offline-mirror directory to your offline machine. 
On the offline machine
Copy the yarn.lock and yarn-offline-mirror to your project directory.
Set the offline mirror path:
yarn config set yarn-offline-mirror ./yarn-offline-mirror.
Install using the --offline flag to force Yarn to use the local cache:
yarn install --offline. 


sh
npm install -g --verbose /path/to/your-package.tgz


This should show you exactly which dependency it's failing to fetch from the npm registry. 
2. Repackage the package and its dependencies
The most reliable method is to bundle all dependencies with the package.
On the online machine, navigate to a clean, temporary directory.
Create a package.json file that lists the package you need in its dependencies. For example:
json
{
  "dependencies": {
    "your-package-name": "version"
  }
}


Run npm install to download all the dependencies.
Use a tool like npm-pack-all to create a tarball that includes all dependencies.
sh
npm install -g npm-pack-all
cd node_modules/your-package-name
npm-pack-all


Alternatively, you can manually list the dependencies in a bundledDependencies array in your package.json file before running npm pack, as mentioned in the previous response. 
3. Run the installer with administrative privileges
Sometimes, installation hangs on Windows due to permission errors. On the offline machine, try running your command prompt or PowerShell as an administrator. 
4. Clear the npm cache
A corrupted cache on the offline machine can cause the installation to stall. 
sh
npm cache clean --force
npm cache verify


Then, try the installation again.
5. Exclude antivirus scanning
Antivirus software on Windows can sometimes interfere with npm's file operations, causing it to freeze. Temporarily disable your antivirus or add an exclusion for the Node.js installation directory. 
Long path limitations on Windows
Installing packages with very deep dependency trees can also cause issues on Windows due to a limitation on file path lengths. You can enable long path support in Windows 10 Pro:
Open the Group Policy Editor (gpedit.msc).
Navigate to Computer Configuration > Administrative Templates > System > Filesystem.
Double-click Enable Win32 long paths and set it to Enabled.
Alternatively, you can modify the registry. Run regedit.exe and navigate to HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem.
Set LongPathsEnabled to 1. 



