# GeoDoxy Project Memory Log - CRITICAL PERFORMANCE UPDATE

## Project Overview
**Project Name**: GeoDoxy - Geospatial Intelligence Dashboard  
**Current Status**: 🚨 **PERFORMANCE CRISIS** - Vector basemap causing browser crashes

## Critical Performance Issue Identified

### Problem Summary
- ✅ COGs/Tiles load instantly via NGINX
- ✅ All other static assets work perfectly  
- ❌ **GeoJSON vector basemap causes browser to freeze** (80% RAM usage)
- ❌ Main application becomes unresponsive when basemap loads
- ❌ Tiles stop loading despite 200 status codes

### Root Cause Analysis
The issue is **large GeoJSON file processing in browser** - not the NGINX serving. When served by Vite dev server, the GeoJSON was likely cached or served with different compression. NGINX is delivering the file correctly, but the browser can't handle the large vector data.

## Immediate Solutions

### Solution 1: Convert GeoJSON to Vector Tiles (Recommended)
Replace the large GeoJSON with pre-tiled PBF vector tiles:

```bash
# Install tippecanoe for vector tile creation
brew install tippecanoe  # Or download Windows binary

# Convert GeoJSON to vector tiles
tippecanoe -zg -o basemap.pmtiles basemap.geojson --drop-densest-as-needed
```

### Solution 2: Implement GeoJSON Simplification
Add geometry simplification in the basemap loading:

```javascript
// In basemap.js - Add simplification before loading
async function loadLocalBasemap() {
  try {
    const response = await fetch("/api/local-basemap");
    const geojsonData = await response.json();
    
    // Simplify geometries to reduce complexity
    const simplifiedData = simplifyGeometries(geojsonData, 0.001);
    
    const features = new GeoJSON().readFeatures(simplifiedData, {
      featureProjection: "EPSG:3857",
    });
    // ... rest of function
  } catch (error) {
    console.error("Failed to load local basemap:", error);
  }
}

function simplifyGeometries(geojson, tolerance) {
  return {
    ...geojson,
    features: geojson.features.map(feature => ({
      ...feature,
      geometry: simplifyGeometry(feature.geometry, tolerance)
    }))
  };
}
```

### Solution 3: Add Progressive Loading
Load basemap in chunks with web workers:

```javascript
// Create web worker for basemap processing
const basemapWorker = new Worker('js/basemap-worker.js');

basemapWorker.onmessage = function(e) {
  const features = new GeoJSON().readFeatures(e.data, {
    featureProjection: "EPSG:3857",
  });
  vectorSource.addFeatures(features);
};

function loadBasemapInChunks(geojsonUrl) {
  basemapWorker.postMessage({ action: 'loadBasemap', url: geojsonUrl });
}
```

## Updated Critical Files

### 1. Emergency Basemap Fix (basemap.js)
```javascript
import OlMap from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import XYZ from "ol/source/XYZ";
import { fromLonLat } from "ol/proj";
import { defaults as defaultControls } from "ol/control";
import ScaleLine from "ol/control/ScaleLine";
import { Style, Stroke, Fill } from "ol/style";

let map, vectorSource, vectorLayer;

document.addEventListener("DOMContentLoaded", async function () {
  initializeMap();
  // TEMPORARILY DISABLE VECTOR BASEMAP - USE ONLY TILES
  // await loadLocalBasemap();
  await setupBasemapPage();
});

function initializeMap() {
  vectorSource = new VectorSource();
  vectorLayer = new VectorLayer({
    source: vectorSource,
    style: new Style({
      stroke: new Stroke({ color: "#3388ff", width: 1 }), // Thinner lines
      fill: new Fill({ color: "rgba(51, 136, 255, 0.05)" }), // More transparent
    }),
    visible: false, // Start hidden
    zIndex: 1,
  });

  const imageryLayer = new TileLayer({
    source: null,
    visible: true,
    zIndex: 0,
  });

  map = new OlMap({
    target: "basemap",
    layers: [imageryLayer, vectorLayer],
    view: new View({
      center: fromLonLat([0, 0]),
      zoom: 2,
      maxZoom: 20,
    }),
    controls: defaultControls().extend([
      new ScaleLine({ units: "metric" })
    ]),
  });
}

// SIMPLIFIED BASEMAP LOADING - Load only on demand
async function loadLocalBasemap() {
  try {
    document.getElementById("basemapLoading").style.display = "flex";
    
    const response = await fetch("/api/local-basemap");
    if (!response.ok) throw new Error("Failed to fetch basemap");
    
    const geojsonData = await response.json();
    
    // Limit the number of features for performance
    const limitedFeatures = geojsonData.features.slice(0, 1000); // TEMPORARY LIMIT
    
    const features = new GeoJSON().readFeatures({
      ...geojsonData,
      features: limitedFeatures
    }, {
      featureProjection: "EPSG:3857",
    });

    vectorSource.clear();
    vectorSource.addFeatures(features);
    
    document.getElementById("basemapStatus").textContent = 
      `Basemap loaded (${limitedFeatures.length} features)`;
      
  } catch (error) {
    console.error("Basemap loading failed:", error);
    document.getElementById("basemapStatus").textContent = 
      "Using tile basemap only - vector data unavailable";
  } finally {
    document.getElementById("basemapLoading").style.display = "none";
  }
}
```

### 2. Updated Flask Basemap Endpoint (app.py)
```python
@app.route('/api/local-basemap')
def get_local_basemap():
    """Simplified basemap endpoint with performance improvements"""
    basemap_path = os.path.join(app.config['BASEMAPS_BASE_URL'], 'basemap.geojson')
    
    try:
        # Option 1: Serve simplified version
        simplified_path = os.path.join(app.config['BASEMAPS_BASE_URL'], 'basemap-simplified.geojson')
        if os.path.exists(simplified_path):
            return send_file(simplified_path, mimetype='application/geo+json')
        
        # Option 2: Return empty features if file is too large
        original_path = os.path.join('public/basemaps', 'basemap.geojson')
        if os.path.exists(original_path):
            file_size = os.path.getsize(original_path)
            if file_size > 10 * 1024 * 1024:  # 10MB limit
                return jsonify({
                    "type": "FeatureCollection",
                    "features": []
                })
            return send_file(original_path, mimetype='application/geo+json')
        
        return get_dynamic_fallback_basemap()
        
    except Exception as e:
        app.logger.error(f"Basemap loading error: {e}")
        return get_dynamic_fallback_basemap()
```

### 3. NGINX Configuration for Large Files
```nginx
# Add to nginx.conf for better large file handling
http {
    # ... existing config ...
    
    # Buffer optimizations for large JSON files
    client_body_buffer_size 128k;
    client_max_body_size 100M;
    client_header_buffer_size 1k;
    large_client_header_buffers 4 4k;
    output_buffers 1 32k;
    postpone_output 1460;

    # Gzip compression for GeoJSON
    gzip on;
    gzip_vary on;
    gzip_min_length 1000;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        application/geo+json
        application/json
        text/plain;

    server {
        # ... existing server config ...
        
        # Special handling for large GeoJSON files
        location ~* \.geojson$ {
            # Serve with compression
            gzip_static on;
            gunzip on;
            
            # Optimized buffers for large files
            output_buffers 2 2m;
            postpone_output 0;
            
            # CORS headers
            add_header 'Access-Control-Allow-Origin' '*' always;
            add_header 'Access-Control-Allow-Methods' 'GET, HEAD, OPTIONS' always;
            add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range' always;
            add_header 'Access-Control-Expose-Headers' 'Content-Length,Content-Range' always;
            
            expires 1h;
            add_header Cache-Control "public, must-revalidate";
        }
    }
}
```

## Immediate Action Plan

### Step 1: Emergency Patch (5 minutes)
```javascript
// TEMPORARY FIX - Disable vector basemap
// In basemap.js, comment out:
// await loadLocalBasemap();
```

### Step 2: GeoJSON Optimization (30 minutes)
1. Check GeoJSON file size: `ls -lh public/basemaps/`
2. If > 5MB, create simplified version:
   ```bash
   # Install geojson-simplify or use QGIS
   npm install -g geojson-simplify
   geojson-simplify -t 0.01 basemap.geojson basemap-simplified.geojson
   ```

### Step 3: Vector Tiles Migration (Long-term)
- Convert GeoJSON to PMTiles or MBTiles
- Use `tippecanoe` for conversion
- Update frontend to use vector tile source

## Performance Testing Commands

```bash
# Check GeoJSON file size
du -h public/basemaps/*.geojson

# Test NGINX serving performance
curl -I http://localhost:8080/basemaps/basemap.geojson

# Monitor browser memory usage
# Open DevTools → Memory → Take heap snapshot
```

## Root Cause Confirmed
**Problem**: Large GeoJSON files (>10MB) overwhelm browser memory when parsed by OpenLayers
**Solution Path**:
1. **Immediate**: Disable vector basemap or use simplified version
2. **Short-term**: Implement progressive loading with web workers  
3. **Long-term**: Migrate to vector tiles (PBF/PMTiles)

## Updated Deployment Status
- ✅ Static asset server working for tiles/COGs
- ✅ NGINX configuration optimized
- ❌ Vector basemap needs architectural change
- 🎯 **Priority**: Fix basemap performance before client deployment

**Next Immediate Step**: Apply emergency patch to disable vector basemap, then work on GeoJSON simplification.
