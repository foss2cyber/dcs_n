#!/usr/bin/env python3
"""
Generate TinyRequest collections from Flask/Express.js route files
Outputs directly to ~/.config/tinyrequest/collections/
"""

import os
import re
import json
import uuid
from pathlib import Path
import argparse

class TinyRequestGenerator:
    def __init__(self, output_dir=None):
        self.output_dir = output_dir or Path.home() / '.config' / 'tinyrequest' / 'collections'
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def generate_collection_id(self):
        return f"col_{uuid.uuid4().hex[:8]}"
    
    def generate_request_id(self):
        return f"req_{uuid.uuid4().hex[:8]}"
    
    def parse_flask_routes(self, file_path):
        """Parse Flask route files"""
        routes = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Match Flask route decorators
            flask_pattern = r'@(?:app|bp|blueprint)\.route\([\'"]([^\'"]+)[\'"](?:,\s*methods=\[([^\]]+)\])?\)'
            
            for match in re.finditer(flask_pattern, content):
                path = match.group(1)
                methods = match.group(2) if match.group(2) else "['GET']"
                
                # Extract HTTP methods
                http_methods = re.findall(r"['\"](GET|POST|PUT|DELETE|PATCH|OPTIONS|HEAD)['\"]", methods)
                if not http_methods:
                    http_methods = ['GET']
                
                # Get function name
                func_pattern = rf'{re.escape(match.group(0))}\s*\n\s*def\s+(\w+)'
                func_match = re.search(func_pattern, content[match.start():match.start()+500])
                func_name = func_match.group(1) if func_match else "endpoint"
                
                for method in http_methods:
                    routes.append({
                        "name": f"{method} {path}",
                        "method": method,
                        "path": path,
                        "description": f"Auto-generated from {func_name}"
                    })
                    
        except Exception as e:
            print(f"Error parsing {file_path}: {e}")
            
        return routes
    
    def parse_express_routes(self, file_path):
        """Parse Express.js route files"""
        routes = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Match Express route patterns
            express_patterns = [
                r'(?:app|router)\.(get|post|put|delete|patch)\([\'"]([^\'"]+)[\'"]',
                r'(?:app|router)\.route\([\'"]([^\'"]+)[\'"]\)\.(get|post|put|delete)'
            ]
            
            for pattern in express_patterns:
                for match in re.finditer(pattern, content):
                    if 'route' in pattern:
                        method = match.group(2).upper()
                        path = match.group(1)
                    else:
                        method = match.group(1).upper()
                        path = match.group(2)
                    
                    routes.append({
                        "name": f"{method} {path}",
                        "method": method,
                        "path": path,
                        "description": "Auto-generated from Express routes"
                    })
                    
        except Exception as e:
            print(f"Error parsing {file_path}: {e}")
            
        return routes
    
    def create_tinyrequest_request(self, route, base_url):
        """Create a TinyRequest request object"""
        
        # Determine if this needs auth (heuristic)
        needs_auth = any(keyword in route['path'].lower() for keyword in 
                        ['user', 'auth', 'admin', 'profile', 'account'])
        
        # Determine if this needs body (heuristic)
        needs_body = route['method'] in ['POST', 'PUT', 'PATCH']
        
        headers = [
            {"key": "Content-Type", "value": "application/json"}
        ]
        
        if needs_auth:
            headers.append({"key": "Authorization", "value": "Bearer {{authToken}}"})
        
        body = ""
        if needs_body:
            body = json.dumps({
                "example": "data",
                "timestamp": "{{$timestamp}}"
            }, indent=2)
        
        # Extract path parameters
        parameters = []
        path_params = re.findall(r'<([^>]+)>', route['path'])  # Flask style
        path_params.extend(re.findall(r':(\w+)', route['path']))  # Express style
        
        for param in path_params:
            parameters.append({
                "key": param,
                "value": "example_value",
                "enabled": True
            })
        
        return {
            "id": self.generate_request_id(),
            "name": route['name'],
            "method": route['method'],
            "url": f"{base_url}{route['path']}",
            "headers": headers,
            "body": body,
            "parameters": parameters,
            "preRequestScript": "",
            "tests": ""
        }
    
    def generate_collection(self, project_name, routes, base_url="http://localhost:3000"):
        """Generate a TinyRequest collection"""
        
        requests = []
        for route in routes:
            requests.append(self.create_tinyrequest_request(route, base_url))
        
        collection = {
            "id": self.generate_collection_id(),
            "name": project_name,
            "description": f"Auto-generated collection for {project_name}",
            "created": "2024-01-15T10:30:00Z",
            "modified": "2024-01-15T10:30:00Z",
            "requests": requests,
            "variables": [
                {
                    "key": "baseUrl",
                    "value": base_url
                },
                {
                    "key": "authToken",
                    "value": ""
                },
                {
                    "key": "timestamp",
                    "value": "{{$timestamp}}"
                }
            ]
        }
        
        return collection
    
    def find_project_files(self, directory):
        """Find Flask and Express route files"""
        flask_files = []
        express_files = []
        
        for root, dirs, files in os.walk(directory):
            # Skip common directories
            dirs[:] = [d for d in dirs if d not in ['node_modules', 'venv', '.git', '__pycache__']]
            
            for file in files:
                file_path = os.path.join(root, file)
                
                # Flask files
                if file.endswith('.py') and any(keyword in file.lower() for keyword in ['route', 'app', 'view', 'api']):
                    flask_files.append(file_path)
                
                # Express files
                elif file.endswith(('.js', '.ts')) and any(keyword in file.lower() for keyword in ['route', 'app', 'api']):
                    express_files.append(file_path)
        
        return flask_files, express_files
    
    def process_directory(self, directory):
        """Process directory and generate TinyRequest collections"""
        print(f"🔍 Scanning directory: {directory}")
        
        flask_files, express_files = self.find_project_files(directory)
        all_routes = []
        
        # Process Flask files
        flask_routes = []
        for flask_file in flask_files:
            project_name = os.path.basename(os.path.dirname(flask_file))
            print(f"📄 Processing Flask: {flask_file}")
            routes = self.parse_flask_routes(flask_file)
            flask_routes.extend(routes)
            print(f"   Found {len(routes)} routes")
        
        # Process Express files
        express_routes = []
        for express_file in express_files:
            project_name = os.path.basename(os.path.dirname(express_file))
            print(f"📄 Processing Express: {express_file}")
            routes = self.parse_express_routes(express_file)
            express_routes.extend(routes)
            print(f"   Found {len(routes)} routes")
        
        print(f"\n🎯 Total routes found: {len(flask_routes)} Flask, {len(express_routes)} Express")
        
        # Generate collections
        if flask_routes:
            flask_collection = self.generate_collection(
                "Flask APIs", 
                flask_routes, 
                "http://localhost:5000"
            )
            self.save_collection(flask_collection, "flask_apis.json")
        
        if express_routes:
            express_collection = self.generate_collection(
                "Express APIs",
                express_routes,
                "http://localhost:3000" 
            )
            self.save_collection(express_collection, "express_apis.json")
        
        # Create a combined collection for all routes
        if flask_routes or express_routes:
            all_routes = flask_routes + express_routes
            combined_collection = self.generate_collection(
                "All APIs",
                all_routes,
                "http://localhost:3000"
            )
            self.save_collection(combined_collection, "all_apis.json")
            
        self.generate_import_instructions()
    
    def save_collection(self, collection, filename):
        """Save collection to file"""
        output_path = self.output_dir / filename
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(collection, f, indent=2)
        
        print(f"💾 Saved: {output_path}")
        print(f"   - {len(collection['requests'])} requests")
        print(f"   - {len(collection['variables'])} variables")
    
    def generate_import_instructions(self):
        """Generate instructions for using the collections"""
        instructions = f"""
📋 TINYREQUEST COLLECTIONS GENERATED SUCCESSFALLY!

Your collections have been saved to:
{self.output_dir}

TinyRequest should automatically detect these collections on next launch.

If not:
1. Open TinyRequest
2. Go to Collections tab  
3. Collections should appear automatically due to auto-save
4. If needed, use 'Import Collection' and select the JSON files

Generated collections:
- flask_apis.json → Flask backend APIs (localhost:5000)
- express_apis.json → Express.js APIs (localhost:3000) 
- all_apis.json → Combined all APIs

Next steps:
1. Launch TinyRequest: tinyrequest
2. Set your actual auth tokens in collection variables
3. Adjust base URLs as needed for your environments
4. Start testing your APIs! 🚀
"""
        print(instructions)

def main():
    parser = argparse.ArgumentParser(description='Generate TinyRequest collections from Flask/Express routes')
    parser.add_argument('directory', help='Path to your project directory')
    parser.add_argument('--output', help='Custom output directory', default=None)
    
    args = parser.parse_args()
    
    if not os.path.exists(args.directory):
        print(f"❌ Directory not found: {args.directory}")
        return
    
    generator = TinyRequestGenerator(args.output)
    generator.process_directory(args.directory)

if __name__ == "__main__":
    main()