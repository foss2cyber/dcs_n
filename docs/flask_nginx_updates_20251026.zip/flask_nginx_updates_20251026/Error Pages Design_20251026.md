
# Error Pages Design

Based on your existing UI/UX, here are comprehensive error pages that maintain the GeoDoxy design system across both Vite (Flask) and NGINX routes.

## 1. Flask/Vite Error Pages

### 404 Page (`404.html`)
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Not Found - GeoDoxy</title>
    <link rel="stylesheet" href="/src/styles.css">
    <style>
        .error-container {
            max-width: 600px;
            margin: 100px auto;
            padding: 40px;
            text-align: center;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .error-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            color: var(--indigo-6);
        }

        .error-code {
            font-size: 3rem;
            font-weight: 800;
            color: var(--gray-12);
            margin-bottom: 10px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .error-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-12);
            margin-bottom: 16px;
        }

        .error-description {
            color: var(--gray-11);
            line-height: 1.6;
            margin-bottom: 30px;
            font-size: 1.1rem;
        }

        .error-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-error-primary {
            padding: 12px 24px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-error-secondary {
            padding: 12px 24px;
            background: var(--gray-3);
            color: var(--gray-12);
            border: 1px solid var(--gray-6);
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-error-primary:hover,
        .btn-error-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
        }

        .search-suggestions {
            margin-top: 30px;
            padding: 20px;
            background: var(--gray-1);
            border-radius: 8px;
            text-align: left;
        }

        .suggestions-title {
            font-weight: 600;
            color: var(--gray-12);
            margin-bottom: 12px;
        }

        .suggestions-list {
            list-style: none;
        }

        .suggestions-list li {
            margin-bottom: 8px;
        }

        .suggestions-list a {
            color: var(--indigo-7);
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .suggestions-list a:hover {
            color: var(--indigo-9);
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="header-content">
            <div class="logo">
                <img src="/icons/vite.svg" alt="GeoDoxy Logo" class="logo-image">
                <span class="logo-text">GeoDoxy</span>
            </div>
            <h1 class="app-title">Geospatial Intelligence Dashboard</h1>
        </div>
    </header>

    <main style="padding: 20px; min-height: calc(100vh - 200px); display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);">
        <div class="error-container">
            <div class="error-icon">🗺️</div>
            <div class="error-code">404</div>
            <div class="error-title">Page Not Found</div>
            <div class="error-description">
                The geospatial data or page you're looking for seems to have drifted off the map. 
                It might have been moved, deleted, or perhaps it never existed in this coordinate system.
            </div>
            
            <div class="error-actions">
                <a href="/" class="btn-error-primary">
                    <span>🏠</span> Return to Dashboard
                </a>
                <a href="/basemap" class="btn-error-secondary">
                    <span>🗺️</span> Explore Basemap
                </a>
                <a href="/api" class="btn-error-secondary">
                    <span>📚</span> API Documentation
                </a>
            </div>

            <div class="search-suggestions">
                <div class="suggestions-title">Popular Destinations:</div>
                <ul class="suggestions-list">
                    <li><a href="/">Main Dashboard</a> - Geospatial intelligence overview</li>
                    <li><a href="/basemap">Vector Basemap</a> - Interactive map viewer</li>
                    <li><a href="/historical-deployment">Historical Analysis</a> - Timeline data</li>
                    <li><a href="/api">API Documentation</a> - Developer resources</li>
                    <li><a href="/health-page">System Health</a> - Service status</li>
                </ul>
            </div>
        </div>
    </main>

    <footer class="app-footer">
        <div class="footer-content">
            <div class="footer-info">
                <span class="version">v1.0.0-rc.4</span>
                <span class="copyright">© 2025 GeoDoxy - Geospatial Intelligence Platform</span>
            </div>
        </div>
    </footer>
</body>
</html>
```

### 500 Page (`500.html`)
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server Error - GeoDoxy</title>
    <link rel="stylesheet" href="/src/styles.css">
    <style>
        .error-container {
            max-width: 600px;
            margin: 80px auto;
            padding: 40px;
            text-align: center;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .error-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            color: var(--red-6);
        }

        .error-code {
            font-size: 3rem;
            font-weight: 800;
            color: var(--gray-12);
            margin-bottom: 10px;
            background: linear-gradient(135deg, #dc2626, #ef4444);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .error-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-12);
            margin-bottom: 16px;
        }

        .error-description {
            color: var(--gray-11);
            line-height: 1.6;
            margin-bottom: 30px;
            font-size: 1.1rem;
        }

        .technical-details {
            background: var(--red-0);
            border: 1px solid var(--red-3);
            border-radius: 8px;
            padding: 16px;
            margin: 20px 0;
            text-align: left;
            font-family: 'Monaco', 'Menlo', monospace;
            font-size: 0.9rem;
            color: var(--red-11);
        }

        .system-status {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 12px;
            margin: 25px 0;
        }

        .status-item {
            padding: 12px;
            background: var(--gray-1);
            border-radius: 6px;
            text-align: center;
        }

        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }

        .status-ok { background: var(--green-6); }
        .status-error { background: var(--red-6); }
        .status-warning { background: var(--orange-6); }

        .btn-error-primary {
            padding: 12px 24px;
            background: linear-gradient(135deg, #dc2626, #ef4444);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin: 0 8px;
        }

        .btn-error-secondary {
            padding: 12px 24px;
            background: var(--gray-3);
            color: var(--gray-12);
            border: 1px solid var(--gray-6);
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin: 0 8px;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="header-content">
            <div class="logo">
                <img src="/icons/vite.svg" alt="GeoDoxy Logo" class="logo-image">
                <span class="logo-text">GeoDoxy</span>
            </div>
            <h1 class="app-title">Geospatial Intelligence Dashboard</h1>
        </div>
    </header>

    <main style="padding: 20px; min-height: calc(100vh - 200px); display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #fef2f2 0%, #fecaca 100%);">
        <div class="error-container">
            <div class="error-icon">🚨</div>
            <div class="error-code">500</div>
            <div class="error-title">Internal Server Error</div>
            <div class="error-description">
                Our geospatial servers are experiencing some turbulence. The system encountered an unexpected 
                error while processing your request. Our team has been notified and is working to restore service.
            </div>

            <div class="system-status">
                <div class="status-item">
                    <span class="status-indicator status-error"></span>
                    API Service
                </div>
                <div class="status-item">
                    <span class="status-indicator status-ok"></span>
                    Database
                </div>
                <div class="status-item">
                    <span class="status-indicator status-ok"></span>
                    Static Assets
                </div>
                <div class="status-item">
                    <span class="status-indicator status-warning"></span>
                    Tile Service
                </div>
            </div>

            <div class="technical-details">
                <strong>Error Reference:</strong> GDX-{{timestamp}}<br>
                <strong>Service:</strong> Geospatial Processing Engine<br>
                <strong>Recommended Action:</strong> Retry in a few moments
            </div>
            
            <div style="margin-top: 30px;">
                <a href="/" class="btn-error-primary">
                    <span>🔄</span> Retry Dashboard
                </a>
                <a href="/health-page" class="btn-error-secondary">
                    <span>🌱</span> Check System Health
                </a>
            </div>
        </div>
    </main>

    <footer class="app-footer">
        <div class="footer-content">
            <div class="footer-info">
                <span class="version">v1.0.0-rc.4</span>
                <span class="copyright">© 2025 GeoDoxy - Geospatial Intelligence Platform</span>
            </div>
        </div>
    </footer>

    <script>
        // Add current timestamp for error reference
        document.addEventListener('DOMContentLoaded', function() {
            const timestamp = Math.floor(Date.now() / 1000);
            document.body.innerHTML = document.body.innerHTML.replace('{{timestamp}}', timestamp);
        });
    </script>
</body>
</html>
```

## 2. NGINX Error Pages

### NGINX 404 Page (`nginx-404.html`)
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Not Found - GeoDoxy</title>
    <style>
        :root {
            --indigo-7: #4338ca;
            --gray-12: #1f2937;
            --gray-11: #374151;
            --gray-3: #f3f4f6;
            --gray-6: #d1d5db;
            --gray-1: #f9fafb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .nginx-error-container {
            max-width: 500px;
            width: 100%;
            padding: 40px;
            text-align: center;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nginx-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 24px;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--indigo-7);
        }

        .nginx-error-icon {
            font-size: 3rem;
            margin-bottom: 16px;
            color: var(--indigo-7);
        }

        .nginx-error-code {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--gray-12);
            margin-bottom: 8px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nginx-error-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--gray-12);
            margin-bottom: 12px;
        }

        .nginx-error-description {
            color: var(--gray-11);
            line-height: 1.5;
            margin-bottom: 24px;
        }

        .asset-path {
            background: var(--gray-1);
            padding: 12px;
            border-radius: 6px;
            font-family: 'Monaco', 'Menlo', monospace;
            font-size: 0.9rem;
            color: var(--gray-11);
            margin: 16px 0;
            word-break: break-all;
        }

        .nginx-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-nginx-primary {
            padding: 10px 20px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.9rem;
        }

        .btn-nginx-secondary {
            padding: 10px 20px;
            background: var(--gray-3);
            color: var(--gray-12);
            border: 1px solid var(--gray-6);
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.9rem;
        }

        .btn-nginx-primary:hover,
        .btn-nginx-secondary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .nginx-footer {
            margin-top: 24px;
            padding-top: 16px;
            border-top: 1px solid var(--gray-6);
            font-size: 0.8rem;
            color: var(--gray-11);
        }
    </style>
</head>
<body>
    <div class="nginx-error-container">
        <div class="nginx-logo">
            <span>🗂️</span>
            <span>GeoDoxy Assets</span>
        </div>
        
        <div class="nginx-error-icon">🔍</div>
        <div class="nginx-error-code">404</div>
        <div class="nginx-error-title">Static Asset Not Found</div>
        <div class="nginx-error-description">
            The requested geospatial asset could not be found in our static file repository. 
            This might be a temporary issue or the asset may have been relocated.
        </div>

        <div class="asset-path" id="assetPath">
            Loading asset path...
        </div>

        <div class="nginx-actions">
            <a href="/" class="btn-nginx-primary">Main Application</a>
            <button onclick="location.reload()" class="btn-nginx-secondary">Retry Request</button>
        </div>

        <div class="nginx-footer">
            GeoDoxy Static Asset Server • NGINX
        </div>
    </div>

    <script>
        // Show the requested asset path
        document.addEventListener('DOMContentLoaded', function() {
            const path = window.location.pathname;
            document.getElementById('assetPath').textContent = path;
        });
    </script>
</body>
</html>
```

### NGINX 50x Page (`nginx-50x.html`)
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Unavailable - GeoDoxy</title>
    <style>
        :root {
            --red-7: #dc2626;
            --gray-12: #1f2937;
            --gray-11: #374151;
            --gray-3: #f3f4f6;
            --gray-6: #d1d5db;
            --gray-1: #f9fafb;
            --orange-6: #ea580c;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #fef2f2 0%, #fecaca 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .nginx-error-container {
            max-width: 500px;
            width: 100%;
            padding: 40px;
            text-align: center;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nginx-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 24px;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--red-7);
        }

        .nginx-error-icon {
            font-size: 3rem;
            margin-bottom: 16px;
            color: var(--red-7);
        }

        .nginx-error-code {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--gray-12);
            margin-bottom: 8px;
            background: linear-gradient(135deg, #dc2626, #ef4444);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nginx-error-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--gray-12);
            margin-bottom: 12px;
        }

        .nginx-error-description {
            color: var(--gray-11);
            line-height: 1.5;
            margin-bottom: 20px;
        }

        .service-status {
            background: var(--gray-1);
            padding: 16px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: left;
        }

        .status-item {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .status-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
        }

        .status-down { background: var(--red-7); }
        .status-up { background: #10b981; }

        .nginx-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .btn-nginx-primary {
            padding: 10px 20px;
            background: linear-gradient(135deg, #dc2626, #ef4444);
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.9rem;
        }

        .btn-nginx-secondary {
            padding: 10px 20px;
            background: var(--gray-3);
            color: var(--gray-12);
            border: 1px solid var(--gray-6);
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.9rem;
        }

        .btn-nginx-primary:hover,
        .btn-nginx-secondary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .nginx-footer {
            margin-top: 24px;
            padding-top: 16px;
            border-top: 1px solid var(--gray-6);
            font-size: 0.8rem;
            color: var(--gray-11);
        }
    </style>
</head>
<body>
    <div class="nginx-error-container">
        <div class="nginx-logo">
            <span>🚨</span>
            <span>GeoDoxy Assets</span>
        </div>
        
        <div class="nginx-error-icon">⚡</div>
        <div class="nginx-error-code">503</div>
        <div class="nginx-error-title">Service Temporarily Unavailable</div>
        <div class="nginx-error-description">
            The static asset server is currently undergoing maintenance or experiencing high load. 
            Geospatial assets may be temporarily unavailable.
        </div>

        <div class="service-status">
            <div class="status-item">
                <span class="status-indicator status-down"></span>
                <span>Static File Server: OFFLINE</span>
            </div>
            <div class="status-item">
                <span class="status-indicator status-up"></span>
                <span>Main Application: ONLINE</span>
            </div>
            <div class="status-item">
                <span class="status-indicator status-up"></span>
                <span>Database Services: ONLINE</span>
            </div>
        </div>

        <div class="nginx-actions">
            <button onclick="location.reload()" class="btn-nginx-primary">Retry Connection</button>
            <a href="/" class="btn-nginx-secondary">Go to Application</a>
            <a href="/health-page" class="btn-nginx-secondary">System Status</a>
        </div>

        <div class="nginx-footer">
            GeoDoxy Static Asset Server • NGINX • Auto-retry in <span id="countdown">30</span>s
        </div>
    </div>

    <script>
        // Auto-retry countdown
        let countdown = 30;
        const countdownElement = document.getElementById('countdown');
        
        const timer = setInterval(() => {
            countdown--;
            countdownElement.textContent = countdown;
            
            if (countdown <= 0) {
                clearInterval(timer);
                location.reload();
            }
        }, 1000);
    </script>
</body>
</html>
```

## 3. Flask Error Handler Integration

Add to your `app.py`:

```python
from flask import render_template

# Custom error handlers
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

@app.errorhandler(403)
def forbidden(error):
    return render_template('403.html'), 403

# Create a simple 403 page similar to 404
```

## 4. NGINX Configuration Update

Update your `nginx.conf`:

```nginx
server {
    listen 8080;
    server_name localhost;
    
    # ... existing config ...
    
    # Error pages
    error_page 404 /404.html;
    error_page 500 502 503 504 /50x.html;
    
    location = /404.html {
        root /path/to/error/pages;
        internal;
    }
    
    location = /50x.html {
        root /path/to/error/pages;
        internal;
    }
}
```

## 5. File Structure

```
geodoxy-app/
├── app.py
├── templates/
│   ├── 404.html
│   ├── 500.html
│   └── 403.html
├── static-asset-server/
│   ├── assets/
│   └── error-pages/
│       ├── nginx-404.html
│       └── nginx-50x.html
└── nginx.conf
```

## Key Design Features

1. **Consistent Branding**: Matches GeoDoxy color scheme and styling
2. **Geospatial Theme**: Map and location-related icons/metaphors
3. **Helpful Actions**: Relevant navigation options for each context
4. **Technical Details**: Appropriate technical info without overwhelming users
5. **Responsive Design**: Works on all device sizes
6. **Performance**: Lightweight with minimal external dependencies

These error pages maintain your application's professional appearance while providing clear, helpful error information to users across both Flask/Vite and NGINX routes.

---

# GeoDoxy 403 Forbidden Page (`403.html`)

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied - GeoDoxy</title>
    <link rel="stylesheet" href="/src/styles.css">
    <style>
        .error-container {
            max-width: 600px;
            margin: 100px auto;
            padding: 40px;
            text-align: center;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .error-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            color: var(--orange-6);
        }

        .error-code {
            font-size: 3rem;
            font-weight: 800;
            color: var(--gray-12);
            margin-bottom: 10px;
            background: linear-gradient(135deg, #ea580c, #f97316);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .error-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-12);
            margin-bottom: 16px;
        }

        .error-description {
            color: var(--gray-11);
            line-height: 1.6;
            margin-bottom: 30px;
            font-size: 1.1rem;
        }

        .access-warning {
            background: var(--orange-0);
            border: 1px solid var(--orange-3);
            border-radius: 8px;
            padding: 16px;
            margin: 20px 0;
            text-align: left;
        }

        .warning-title {
            font-weight: 600;
            color: var(--orange-11);
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .permission-list {
            list-style: none;
            margin: 15px 0;
        }

        .permission-list li {
            padding: 8px 0;
            border-bottom: 1px solid var(--orange-2);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .permission-list li:last-child {
            border-bottom: none;
        }

        .permission-icon {
            width: 20px;
            text-align: center;
        }

        .btn-error-primary {
            padding: 12px 24px;
            background: linear-gradient(135deg, #ea580c, #f97316);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-error-secondary {
            padding: 12px 24px;
            background: var(--gray-3);
            color: var(--gray-12);
            border: 1px solid var(--gray-6);
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-error-primary:hover,
        .btn-error-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
        }

        .error-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 25px;
        }

        .security-info {
            margin-top: 30px;
            padding: 20px;
            background: var(--gray-1);
            border-radius: 8px;
            text-align: left;
        }

        .security-title {
            font-weight: 600;
            color: var(--gray-12);
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .contact-support {
            background: var(--blue-0);
            border: 1px solid var(--blue-3);
            border-radius: 6px;
            padding: 12px;
            margin-top: 15px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="header-content">
            <div class="logo">
                <img src="/icons/vite.svg" alt="GeoDoxy Logo" class="logo-image">
                <span class="logo-text">GeoDoxy</span>
            </div>
            <h1 class="app-title">Geospatial Intelligence Dashboard</h1>
        </div>
    </header>

    <main style="padding: 20px; min-height: calc(100vh - 200px); display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #fff7ed 0%, #fed7aa 100%);">
        <div class="error-container">
            <div class="error-icon">🚫</div>
            <div class="error-code">403</div>
            <div class="error-title">Access Forbidden</div>
            <div class="error-description">
                Your current credentials don't grant you access to this geospatial resource. 
                This area requires specific permissions or may be restricted to certain user roles.
            </div>

            <div class="access-warning">
                <div class="warning-title">
                    <span>⚠️</span>
                    Restricted Access Area
                </div>
                <p>You attempted to access:</p>
                <div style="background: var(--orange-1); padding: 8px 12px; border-radius: 4px; margin: 10px 0; font-family: 'Monaco', 'Menlo', monospace; font-size: 0.9rem;">
                    <span id="restrictedPath">Loading...</span>
                </div>
            </div>

            <div class="error-actions">
                <a href="/" class="btn-error-primary">
                    <span>🏠</span> Return to Dashboard
                </a>
                <a href="/api" class="btn-error-secondary">
                    <span>📚</span> API Documentation
                </a>
                <a href="/health-page" class="btn-error-secondary">
                    <span>🌱</span> System Status
                </a>
            </div>

            <div class="security-info">
                <div class="security-title">
                    <span>🔒</span>
                    Access Requirements
                </div>
                <ul class="permission-list">
                    <li>
                        <span class="permission-icon">👤</span>
                        <span>Valid user authentication</span>
                    </li>
                    <li>
                        <span class="permission-icon">🎯</span>
                        <span>Appropriate security clearance level</span>
                    </li>
                    <li>
                        <span class="permission-icon">📍</span>
                        <span>Geospatial data access permissions</span>
                    </li>
                    <li>
                        <span class="permission-icon">⚙️</span>
                        <span>Role-based authorization</span>
                    </li>
                </ul>

                <div class="contact-support">
                    <strong>Need access?</strong> Contact your system administrator or the GeoDoxy support team 
                    to request the appropriate permissions for this resource.
                </div>
            </div>
        </div>
    </main>

    <footer class="app-footer">
        <div class="footer-content">
            <div class="footer-info">
                <span class="version">v1.0.0-rc.4</span>
                <span class="copyright">© 2025 GeoDoxy - Secure Geospatial Intelligence Platform</span>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Show the restricted path
            const path = window.location.pathname;
            document.getElementById('restrictedPath').textContent = path;
            
            // Add timestamp for security logging
            const timestamp = new Date().toISOString();
            console.warn(`GeoDoxy 403 Access Denied: ${path} at ${timestamp}`);
        });
    </script>
</body>
</html>
```

## Additional: NGINX 403 Page (`nginx-403.html`)

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied - GeoDoxy Assets</title>
    <style>
        :root {
            --orange-7: #ea580c;
            --gray-12: #1f2937;
            --gray-11: #374151;
            --gray-3: #f3f4f6;
            --gray-6: #d1d5db;
            --gray-1: #f9fafb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #fff7ed 0%, #fed7aa 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .nginx-error-container {
            max-width: 500px;
            width: 100%;
            padding: 40px;
            text-align: center;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nginx-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 24px;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--orange-7);
        }

        .nginx-error-icon {
            font-size: 3rem;
            margin-bottom: 16px;
            color: var(--orange-7);
        }

        .nginx-error-code {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--gray-12);
            margin-bottom: 8px;
            background: linear-gradient(135deg, #ea580c, #f97316);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nginx-error-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--gray-12);
            margin-bottom: 12px;
        }

        .nginx-error-description {
            color: var(--gray-11);
            line-height: 1.5;
            margin-bottom: 20px;
        }

        .restricted-asset {
            background: var(--orange-1);
            border: 1px solid var(--orange-3);
            border-radius: 6px;
            padding: 12px;
            margin: 16px 0;
            font-family: 'Monaco', 'Menlo', monospace;
            font-size: 0.9rem;
            color: var(--orange-11);
            word-break: break-all;
        }

        .access-policy {
            background: var(--gray-1);
            padding: 16px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: left;
            font-size: 0.9rem;
        }

        .policy-item {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 8px;
        }

        .nginx-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .btn-nginx-primary {
            padding: 10px 20px;
            background: linear-gradient(135deg, #ea580c, #f97316);
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.9rem;
        }

        .btn-nginx-secondary {
            padding: 10px 20px;
            background: var(--gray-3);
            color: var(--gray-12);
            border: 1px solid var(--gray-6);
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.9rem;
        }

        .btn-nginx-primary:hover,
        .btn-nginx-secondary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .nginx-footer {
            margin-top: 24px;
            padding-top: 16px;
            border-top: 1px solid var(--gray-6);
            font-size: 0.8rem;
            color: var(--gray-11);
        }
    </style>
</head>
<body>
    <div class="nginx-error-container">
        <div class="nginx-logo">
            <span>🔒</span>
            <span>GeoDoxy Assets</span>
        </div>
        
        <div class="nginx-error-icon">🚫</div>
        <div class="nginx-error-code">403</div>
        <div class="nginx-error-title">Asset Access Forbidden</div>
        <div class="nginx-error-description">
            You don't have permission to access this geospatial asset. The file exists 
            but your current access level doesn't permit viewing or downloading it.
        </div>

        <div class="restricted-asset" id="restrictedAsset">
            Loading asset path...
        </div>

        <div class="access-policy">
            <div class="policy-item">
                <span>📁</span>
                <span><strong>Asset Type:</strong> Restricted Geospatial Data</span>
            </div>
            <div class="policy-item">
                <span>👤</span>
                <span><strong>Access Level:</strong> Elevated Clearance Required</span>
            </div>
            <div class="policy-item">
                <span>🛡️</span>
                <span><strong>Security:</strong> Protected by NGINX Access Controls</span>
            </div>
        </div>

        <div class="nginx-actions">
            <a href="/" class="btn-nginx-primary">Main Application</a>
            <button onclick="history.back()" class="btn-nginx-secondary">Go Back</button>
        </div>

        <div class="nginx-footer">
            GeoDoxy Static Asset Server • NGINX • Secure Access Control
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const path = window.location.pathname;
            document.getElementById('restrictedAsset').textContent = path;
        });
    </script>
</body>
</html>
```

## Flask Error Handler Update

Add to your `app.py`:

```python
@app.errorhandler(403)
def forbidden(error):
    return render_template('403.html'), 403
```

## NGINX Configuration Update

Add to your `nginx.conf`:

```nginx
server {
    listen 8080;
    server_name localhost;
    
    # ... existing config ...
    
    # Error pages
    error_page 403 /403.html;
    error_page 404 /404.html;
    error_page 500 502 503 504 /50x.html;
    
    location = /403.html {
        root /path/to/error/pages;
        internal;
    }
    
    # ... other error page locations
}
```

## Key Features of the 403 Pages:

1. **Security-Focused Design**: Orange/amber color scheme indicating caution
2. **Clear Access Information**: Shows what resource was blocked and why
3. **Helpful Guidance**: Explains permission requirements and next steps
4. **Consistent Branding**: Matches GeoDoxy design language
5. **Appropriate Actions**: Provides relevant navigation options
6. **Security Logging**: Client-side logging for troubleshooting
7. **Responsive Layout**: Works on all device sizes

The 403 pages maintain your application's professional security posture while providing clear, helpful information to users who encounter access restrictions.

---
