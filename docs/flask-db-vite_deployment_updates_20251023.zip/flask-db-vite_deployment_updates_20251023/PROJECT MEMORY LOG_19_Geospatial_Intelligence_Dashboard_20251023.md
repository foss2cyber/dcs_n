# GeoDoxy Project Memory Log

## Project Overview
**Project Name**: GeoDoxy - Geospatial Intelligence Dashboard  
**Core Goal**: Develop a robust Flask + Vite web application with PostgreSQL/PostGIS backend for geospatial intelligence analysis, deployed in air-gapped Windows environments with dedicated static asset server architecture.

## Current Status - ✅ COMPLETED INTEGRATION
**Latest Achievement**: Successfully integrated standalone NGINX static asset server with Traefik reverse proxy. All components are working:
- ✅ Flask API serving on port 5000
- ✅ Traefik reverse proxy on port 8081
- ✅ NGINX static asset server on port 8082
- ✅ PostgreSQL with PostGIS extensions
- ✅ Vite frontend building correctly with asset server URLs

## Key Technical Decisions & Architecture

### 1. Static Asset Server Architecture
**Decision**: Separate static assets from dynamic Flask application
**Why**: Performance, scalability, and air-gapped deployment requirements
**Implementation**:
- NGINX serves: tiles, COGs, reports, icons, basemaps, images
- Flask serves: API endpoints, HTML pages
- Traefik routes: `/api/*` → Flask, `/*` → NGINX

### 2. Database Schema (PostgreSQL + PostGIS)
```sql
-- Core tables
findings (id, image_id, target_class, score, target_geom)
target (id, target_type, target_name, country_name, target_geom)  
sql_scat_query2 (precomputed results with scores)
comprehensive_query (aggregation view)
```

### 3. Frontend Stack
- **Vite** + vanilla JavaScript (no React/Vue)
- **OpenLayers** for maps
- **Chart.js** for analytics
- **Open Props** for CSS utilities

## Critical Code Snippets & Configurations

### Asset Server Integration (Latest)
**config.js** - Centralized asset URL management:
```javascript
export const CONFIG = {
  ASSET_SERVER: import.meta.env.VITE_ASSET_SERVER || "http://localhost:8082",
  // ... other base URLs
};

export function getAssetUrl(path) {
  return `${CONFIG.ASSET_SERVER}/${path}`;
}
```

**Tile Loading** in basemap.js:
```javascript
const xyzSource = new XYZ({
  url: `${getAssetUrl(`tiles/${imageId}/{z}/{x}/{y}.png`)}`,
  crossOrigin: "anonymous",
});
```

### NGINX Configuration
```nginx
server {
    listen       8082;
    location / {
        root /path/to/assets;
        autoindex on;
        # CORS headers for all asset types
        add_header 'Access-Control-Allow-Origin' '*' always;
        # ... other CORS headers
    }
}
```

### Traefik Routing
```yaml
http:
  routers:
    assets:
      rule: "PathPrefix(`/`)"
      service: nginx-static
      entryPoints: [web]
  services:
    nginx-static:
      loadBalancer:
        servers:
          - url: "http://localhost:8082"
```

## Current Problem & Next Immediate Step

### Just Completed ✅
**Problem**: HTML files contained hardcoded local asset paths breaking external asset server integration  
**Solution**: Updated all HTML files to use absolute URLs to asset server:
- `index.html`, `basemap.html`, `historical.html`, `api-docs.html`, `health.html`
- CSS import statements in `styles.css`
- All icon and script references

### Next Immediate Step 🚀
**Action**: Test the complete integrated system  
**Commands to run**:
```bash
# Terminal 1 - Start NGINX
cd /path/to/nginx-build
./sbin/nginx -p $(pwd) -c conf/nginx.conf

# Terminal 2 - Start Flask
cd /path/to/flask-db-vite
python app.py

# Terminal 3 - Start Traefik  
cd /path/to/traefik
./traefik --configFile=traefik.yml

# Terminal 4 - Build and deploy frontend
cd /path/to/flask-db-vite
VITE_ASSET_SERVER=http://localhost:8082 npm run build
cp -r dist/* /path/to/static-asset-server/assets/
```

## Open Questions & Considerations

### 1. Windows Deployment
- Need Windows binaries for Traefik and NGINX
- Path adjustments in configurations (forward slashes)
- Firewall configuration for ports 8081, 8082

### 2. Asset Synchronization
- Current manual copy process for assets
- Could implement automated sync script
- Consider versioning for different asset sets

### 3. Production Security
- Basic auth for Traefik dashboard
- Environment-based configuration
- Secret management for database credentials

## Deployment Checklist for Air-Gapped Windows

### Prerequisites
- [ ] Windows-compatible Traefik binary
- [ ] Windows-compatible NGINX binary  
- [ ] PostgreSQL with PostGIS installed
- [ ] Python 3.8+ with required packages
- [ ] Node.js for build process

### Configuration Files Needed
- `traefik.yml` (Traefik configuration)
- `nginx.conf` (NGINX configuration) 
- `.env` (Environment variables)
- Updated HTML files with Windows paths

### Startup Sequence
1. Start PostgreSQL service
2. Start NGINX static asset server
3. Start Flask application  
4. Start Traefik reverse proxy
5. Access via `http://localhost:8081`

## Recent Breakthroughs & Solutions

### 1. NGINX Build Issue Resolved
**Problem**: `make install` failing in source directory  
**Solution**: Used pre-built binary directly from `./objs/nginx`

### 2. Asset Path Integration
**Problem**: JavaScript files needed asset server URLs  
**Solution**: Implemented `getAssetUrl()` function with environment variable support

### 3. CORS Configuration
**Problem**: Cross-origin requests blocked  
**Solution**: Comprehensive CORS headers in NGINX config

## Quick Resume Commands
To continue development from current state:
```bash
# Build and deploy
VITE_ASSET_SERVER=http://localhost:8082 npm run build
cp -r dist/* public/* /path/to/static-asset-server/assets/

# Start services (Linux)
./start-services.sh

# Start services (Windows)  
start-services.bat
```

## Architecture Summary
```
Client → Traefik:8081 → { Flask:5000 (API), NGINX:8082 (Assets) } → PostgreSQL
```

**Status**: READY FOR DEPLOYMENT TESTING 🎯
